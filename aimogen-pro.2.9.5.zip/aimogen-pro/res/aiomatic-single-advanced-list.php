<?php
defined('ABSPATH') or die(); 
function aiomatic_single_advanced_panel()
{
   $aiomatic_Main_Settings = get_option('aiomatic_Main_Settings', false);
   if (!aiomatic_check_api_keys($aiomatic_Main_Settings)) 
   {
      ?>
<h1><?php echo esc_html__("You must add an AI service API Key into the plugin's 'Settings' -> 'API Keys' tab before you can use this feature!", 'aiomatic-automatic-ai-content-writer');?></h1>
<?php
return;
   }
   $cat_arr = array();
   $cat_arr["mainCategoryId=1253"] = esc_html__("Arts &amp; Entertainment", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1253&amp;subCategoryId=1265"] = esc_html__("-- Architecture", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1253&amp;subCategoryId=1259"] = esc_html__("-- Art", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1253&amp;subCategoryId=1254"] = esc_html__("-- Body Art", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1253&amp;subCategoryId=1261"] = esc_html__("-- Dance", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1253&amp;subCategoryId=1263"] = esc_html__("-- Fashion", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1253&amp;subCategoryId=1255"] = esc_html__("-- Film &amp; Television", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1253&amp;subCategoryId=1260"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1253&amp;subCategoryId=1262"] = esc_html__("-- Humor", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1253&amp;subCategoryId=1519"] = esc_html__("-- Magic Tricks", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1253&amp;subCategoryId=1256"] = esc_html__("-- Music", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1253&amp;subCategoryId=1257"] = esc_html__("-- Photography", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1253&amp;subCategoryId=1258"] = esc_html__("-- Radio", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1253&amp;subCategoryId=1264"] = esc_html__("-- Theater", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1510"] = esc_html__("Betting Systems", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1510&amp;subCategoryId=1515"] = esc_html__("-- Casino Table Games", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1510&amp;subCategoryId=1517"] = esc_html__("-- Football", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1510&amp;subCategoryId=1511"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1510&amp;subCategoryId=1512"] = esc_html__("-- Horse Racing", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1510&amp;subCategoryId=1514"] = esc_html__("-- Lottery", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1510&amp;subCategoryId=1513"] = esc_html__("-- Poker", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1510&amp;subCategoryId=1516"] = esc_html__("-- Soccer", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266"] = esc_html__("Business / Investing", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266&amp;subCategoryId=1275"] = esc_html__("-- Careers, Industries &amp; Professions", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266&amp;subCategoryId=1520"] = esc_html__("-- Commodities", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266&amp;subCategoryId=1277"] = esc_html__("-- Debt", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266&amp;subCategoryId=1271"] = esc_html__("-- Derivatives", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266&amp;subCategoryId=1280"] = esc_html__("-- Economics", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266&amp;subCategoryId=1268"] = esc_html__("-- Equities &amp; Stocks", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266&amp;subCategoryId=1267"] = esc_html__("-- Foreign Exchange", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266&amp;subCategoryId=1270"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266&amp;subCategoryId=1276"] = esc_html__("-- International Business", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266&amp;subCategoryId=1278"] = esc_html__("-- Management &amp; Leadership", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266&amp;subCategoryId=1273"] = esc_html__("-- Marketing &amp; Sales", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266&amp;subCategoryId=1279"] = esc_html__("-- Outsourcing", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266&amp;subCategoryId=1274"] = esc_html__("-- Personal Finance", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266&amp;subCategoryId=1269"] = esc_html__("-- Real Estate", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1266&amp;subCategoryId=1272"] = esc_html__("-- Small Biz / Entrepreneurship", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1283"] = esc_html__("Computers / Internet", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1283&amp;subCategoryId=1290"] = esc_html__("-- Databases", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1283&amp;subCategoryId=1295"] = esc_html__("-- Email Services", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1283&amp;subCategoryId=1292"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1283&amp;subCategoryId=1285"] = esc_html__("-- Graphics", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1283&amp;subCategoryId=1288"] = esc_html__("-- Hardware", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1283&amp;subCategoryId=1291"] = esc_html__("-- Networking", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1283&amp;subCategoryId=1293"] = esc_html__("-- Operating Systems", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1283&amp;subCategoryId=1287"] = esc_html__("-- Programming", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1283&amp;subCategoryId=1286"] = esc_html__("-- Software", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1283&amp;subCategoryId=1296"] = esc_html__("-- System Administration", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1283&amp;subCategoryId=1294"] = esc_html__("-- System Analysis &amp; Design", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1283&amp;subCategoryId=1289"] = esc_html__("-- Web Hosting", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1283&amp;subCategoryId=1284"] = esc_html__("-- Web Site Design", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1297"] = esc_html__("Cooking, Food &amp; Wine", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1297&amp;subCategoryId=1300"] = esc_html__("-- BBQ", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1297&amp;subCategoryId=1298"] = esc_html__("-- Baking", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1297&amp;subCategoryId=1303"] = esc_html__("-- Cooking", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1297&amp;subCategoryId=1304"] = esc_html__("-- Drinks &amp; Beverages", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1297&amp;subCategoryId=1305"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1297&amp;subCategoryId=1299"] = esc_html__("-- Recipes", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1297&amp;subCategoryId=1306"] = esc_html__("-- Regional &amp; Intl.", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1297&amp;subCategoryId=1301"] = esc_html__("-- Special Diet", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1297&amp;subCategoryId=1302"] = esc_html__("-- Special Occasions", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1297&amp;subCategoryId=1307"] = esc_html__("-- Vegetables / Vegetarian", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1297&amp;subCategoryId=1521"] = esc_html__("-- Wine Making", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308"] = esc_html__("E-business &amp; E-marketing", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1309"] = esc_html__("-- Affiliate Marketing", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1311"] = esc_html__("-- Article Marketing", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1326"] = esc_html__("-- Auctions", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1330"] = esc_html__("-- Banners", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1318"] = esc_html__("-- Blog Marketing", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1323"] = esc_html__("-- Classified Advertising", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1328"] = esc_html__("-- Consulting", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1327"] = esc_html__("-- Copywriting", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1325"] = esc_html__("-- Domains", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1312"] = esc_html__("-- E-commerce Operations", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1320"] = esc_html__("-- E-zine Strategies", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1321"] = esc_html__("-- Email Marketing", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1324"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1317"] = esc_html__("-- Market Research", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1319"] = esc_html__("-- Marketing", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1322"] = esc_html__("-- Niche Marketing", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1314"] = esc_html__("-- Paid Surveys", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1313"] = esc_html__("-- Pay Per Click Advertising", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1310"] = esc_html__("-- Promotion", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1315"] = esc_html__("-- SEM &amp; SEO", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1331"] = esc_html__("-- Social Media Marketing", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1316"] = esc_html__("-- Submitters", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1308&amp;subCategoryId=1329"] = esc_html__("-- Video Marketing", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1362"] = esc_html__("Education", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1362&amp;subCategoryId=1364"] = esc_html__("-- Admissions", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1362&amp;subCategoryId=1522"] = esc_html__("-- Educational Materials", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1362&amp;subCategoryId=1523"] = esc_html__("-- Higher Education", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1362&amp;subCategoryId=1524"] = esc_html__("-- K-12", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1362&amp;subCategoryId=1365"] = esc_html__("-- Student Loans", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1362&amp;subCategoryId=1363"] = esc_html__("-- Test Prep &amp; Study Guides", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1332"] = esc_html__("Employment &amp; Jobs", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1332&amp;subCategoryId=1335"] = esc_html__("-- Cover Letter &amp; Resume Guides", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1332&amp;subCategoryId=1337"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1332&amp;subCategoryId=1334"] = esc_html__("-- Job Listings", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1332&amp;subCategoryId=1336"] = esc_html__("-- Job Search Guides", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1332&amp;subCategoryId=1333"] = esc_html__("-- Job Skills / Training", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1338"] = esc_html__("Fiction", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1338&amp;subCategoryId=1339"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1340"] = esc_html__("Games", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1340&amp;subCategoryId=1342"] = esc_html__("-- Console Guides &amp; Repairs", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1340&amp;subCategoryId=1343"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1340&amp;subCategoryId=1341"] = esc_html__("-- Strategy Guides", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1344"] = esc_html__("Green Products", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1344&amp;subCategoryId=1345"] = esc_html__("-- Alternative Energy", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1344&amp;subCategoryId=1346"] = esc_html__("-- Conservation &amp; Efficiency", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1344&amp;subCategoryId=1525"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347"] = esc_html__("Health &amp; Fitness", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1357"] = esc_html__("-- Addiction", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1361"] = esc_html__("-- Beauty", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1359"] = esc_html__("-- Dental Health", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1348"] = esc_html__("-- Diets &amp; Weight Loss", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1354"] = esc_html__("-- Exercise &amp; Fitness", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1360"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1526"] = esc_html__("-- Meditation", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1352"] = esc_html__("-- Men's Health", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1355"] = esc_html__("-- Mental Health", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1350"] = esc_html__("-- Nutrition", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1349"] = esc_html__("-- Remedies", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1527"] = esc_html__("-- Sleep and Dreams", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1356"] = esc_html__("-- Spiritual Health", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1351"] = esc_html__("-- Strength Training", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1353"] = esc_html__("-- Women's Health", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1347&amp;subCategoryId=1358"] = esc_html__("-- Yoga", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1366"] = esc_html__("Home &amp; Garden", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1366&amp;subCategoryId=1368"] = esc_html__("-- Animal Care &amp; Pets", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1366&amp;subCategoryId=1371"] = esc_html__("-- Crafts &amp; Hobbies", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1366&amp;subCategoryId=1374"] = esc_html__("-- Entertaining", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1366&amp;subCategoryId=1367"] = esc_html__("-- Gardening &amp; Horticulture", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1366&amp;subCategoryId=1373"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1366&amp;subCategoryId=1376"] = esc_html__("-- Homebuying", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1366&amp;subCategoryId=1369"] = esc_html__("-- How-to &amp; Home Improvements", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1366&amp;subCategoryId=1375"] = esc_html__("-- Interior Design", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1366&amp;subCategoryId=1372"] = esc_html__("-- Sewing", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1366&amp;subCategoryId=1370"] = esc_html__("-- Weddings", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1377"] = esc_html__("Languages", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1377&amp;subCategoryId=1391"] = esc_html__("-- Arabic", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1377&amp;subCategoryId=1383"] = esc_html__("-- Chinese", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1377&amp;subCategoryId=1385"] = esc_html__("-- English", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1377&amp;subCategoryId=1378"] = esc_html__("-- French", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1377&amp;subCategoryId=1381"] = esc_html__("-- German", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1377&amp;subCategoryId=1389"] = esc_html__("-- Hebrew", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1377&amp;subCategoryId=1390"] = esc_html__("-- Hindi", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1377&amp;subCategoryId=1382"] = esc_html__("-- Italian", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1377&amp;subCategoryId=1380"] = esc_html__("-- Japanese", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1377&amp;subCategoryId=1387"] = esc_html__("-- Other", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1377&amp;subCategoryId=1386"] = esc_html__("-- Russian", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1377&amp;subCategoryId=1384"] = esc_html__("-- Sign Language", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1377&amp;subCategoryId=1379"] = esc_html__("-- Spanish", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1377&amp;subCategoryId=1388"] = esc_html__("-- Thai", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1392"] = esc_html__("Mobile", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1392&amp;subCategoryId=1518"] = esc_html__("-- Apps", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1392&amp;subCategoryId=1397"] = esc_html__("-- Developer Tools", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1392&amp;subCategoryId=1395"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1392&amp;subCategoryId=1393"] = esc_html__("-- Ringtones", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1392&amp;subCategoryId=1396"] = esc_html__("-- Security", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1392&amp;subCategoryId=1394"] = esc_html__("-- Video", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1400"] = esc_html__("Parenting &amp; Families", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1400&amp;subCategoryId=1528"] = esc_html__("-- Divorce", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1400&amp;subCategoryId=1402"] = esc_html__("-- Education", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1400&amp;subCategoryId=1405"] = esc_html__("-- Genealogy", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1400&amp;subCategoryId=1407"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1400&amp;subCategoryId=1406"] = esc_html__("-- Marriage", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1400&amp;subCategoryId=1403"] = esc_html__("-- Parenting", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1400&amp;subCategoryId=1401"] = esc_html__("-- Pregnancy &amp; Childbirth", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1400&amp;subCategoryId=1404"] = esc_html__("-- Special Needs", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1408"] = esc_html__("Politics / Current Events", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1408&amp;subCategoryId=1409"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1410"] = esc_html__("Reference", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1410&amp;subCategoryId=1529"] = esc_html__("-- Automotive", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1410&amp;subCategoryId=1412"] = esc_html__("-- Catalogs &amp; Directories", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1410&amp;subCategoryId=1411"] = esc_html__("-- Consumer Guides", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1410&amp;subCategoryId=1413"] = esc_html__("-- Education", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1410&amp;subCategoryId=1418"] = esc_html__("-- Etiquette", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1410&amp;subCategoryId=1416"] = esc_html__("-- Gay / Lesbian", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1410&amp;subCategoryId=1417"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1410&amp;subCategoryId=1414"] = esc_html__("-- Law &amp; Legal Issues", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1410&amp;subCategoryId=1530"] = esc_html__("-- The Sciences", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1410&amp;subCategoryId=1415"] = esc_html__("-- Writing", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1419"] = esc_html__("Self-Help", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1419&amp;subCategoryId=1431"] = esc_html__("-- Abuse", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1419&amp;subCategoryId=1423"] = esc_html__("-- Dating Guides", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1419&amp;subCategoryId=1430"] = esc_html__("-- Eating Disorders", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1419&amp;subCategoryId=1427"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1419&amp;subCategoryId=1420"] = esc_html__("-- Marriage &amp; Relationships", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1419&amp;subCategoryId=1422"] = esc_html__("-- Motivational / Transformational", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1419&amp;subCategoryId=1426"] = esc_html__("-- Personal Finance", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1419&amp;subCategoryId=1531"] = esc_html__("-- Public Speaking", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1419&amp;subCategoryId=1532"] = esc_html__("-- Self Defense", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1419&amp;subCategoryId=1429"] = esc_html__("-- Self-Esteem", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1419&amp;subCategoryId=1421"] = esc_html__("-- Stress Management", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1419&amp;subCategoryId=1425"] = esc_html__("-- Success", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1419&amp;subCategoryId=1428"] = esc_html__("-- Time Management", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432"] = esc_html__("Software &amp; Services", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1438"] = esc_html__("-- Anti Adware / Spyware", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1436"] = esc_html__("-- Background Investigations", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1460"] = esc_html__("-- Communications", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1441"] = esc_html__("-- Dating", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1457"] = esc_html__("-- Developer Tools", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1456"] = esc_html__("-- Digital Photos", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1437"] = esc_html__("-- Drivers", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1453"] = esc_html__("-- Education", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1448"] = esc_html__("-- Email", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1433"] = esc_html__("-- Foreign Exchange Investing", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1445"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1452"] = esc_html__("-- Graphic Design", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1446"] = esc_html__("-- Hosting", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1444"] = esc_html__("-- Internet Tools", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1447"] = esc_html__("-- MP3 &amp; Audio", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1458"] = esc_html__("-- Networking", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1455"] = esc_html__("-- Operating Systems", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1443"] = esc_html__("-- Other Investment Software", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1459"] = esc_html__("-- Personal Finance", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1450"] = esc_html__("-- Productivity", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1434"] = esc_html__("-- Registry Cleaners", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1435"] = esc_html__("-- Reverse Phone Lookup", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1454"] = esc_html__("-- Screensavers &amp; Wallpaper", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1439"] = esc_html__("-- Security", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1440"] = esc_html__("-- System Optimization", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1449"] = esc_html__("-- Utilities", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1442"] = esc_html__("-- Video", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1432&amp;subCategoryId=1451"] = esc_html__("-- Web Design", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1461"] = esc_html__("Spirituality, New Age &amp; Alternative Beliefs", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1461&amp;subCategoryId=1465"] = esc_html__("-- Astrology", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1461&amp;subCategoryId=1470"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1461&amp;subCategoryId=1463"] = esc_html__("-- Hypnosis", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1461&amp;subCategoryId=1466"] = esc_html__("-- Magic", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1461&amp;subCategoryId=1462"] = esc_html__("-- Numerology", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1461&amp;subCategoryId=1468"] = esc_html__("-- Paranormal", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1461&amp;subCategoryId=1467"] = esc_html__("-- Psychics", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1461&amp;subCategoryId=1469"] = esc_html__("-- Religion", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1461&amp;subCategoryId=1471"] = esc_html__("-- Tarot", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1461&amp;subCategoryId=1464"] = esc_html__("-- Witchcraft", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472"] = esc_html__("Sports", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1483"] = esc_html__("-- Automotive", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1476"] = esc_html__("-- Baseball", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1485"] = esc_html__("-- Basketball", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1473"] = esc_html__("-- Coaching", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1533"] = esc_html__("-- Cycling", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1491"] = esc_html__("-- Extreme Sports", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1488"] = esc_html__("-- Football", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1490"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1474"] = esc_html__("-- Golf", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1493"] = esc_html__("-- Hockey", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1481"] = esc_html__("-- Individual Sports", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1480"] = esc_html__("-- Martial Arts", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1492"] = esc_html__("-- Mountaineering", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1484"] = esc_html__("-- Other Team Sports", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1482"] = esc_html__("-- Outdoors &amp; Nature", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1479"] = esc_html__("-- Racket Sports", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1534"] = esc_html__("-- Running", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1477"] = esc_html__("-- Soccer", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1489"] = esc_html__("-- Softball", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1478"] = esc_html__("-- Training", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1475"] = esc_html__("-- Volleyball", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1486"] = esc_html__("-- Water Sports", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1472&amp;subCategoryId=1487"] = esc_html__("-- Winter Sports", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1494"] = esc_html__("Travel", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1494&amp;subCategoryId=1535"] = esc_html__("-- Africa", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1494&amp;subCategoryId=1495"] = esc_html__("-- Asia", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1494&amp;subCategoryId=1500"] = esc_html__("-- Canada", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1494&amp;subCategoryId=1503"] = esc_html__("-- Caribbean", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1494&amp;subCategoryId=1499"] = esc_html__("-- Europe", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1494&amp;subCategoryId=1498"] = esc_html__("-- General", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1494&amp;subCategoryId=1501"] = esc_html__("-- Latin America", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1494&amp;subCategoryId=1502"] = esc_html__("-- Middle East", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1494&amp;subCategoryId=1496"] = esc_html__("-- Specialty Travel", 'aiomatic-automatic-ai-content-writer');
   $cat_arr["mainCategoryId=1494&amp;subCategoryId=1497"] = esc_html__("-- United States", 'aiomatic-automatic-ai-content-writer');
	$aiomatic_language_names = array(
      "English",
      "Spanish",
      "French",
      "Italian",
      "Afrikaans",
      "Albanian",
      "Arabic",
      "Amharic",
      "Armenian",
      "Belarusian",
      "Bulgarian",
      "Catalan",
      "Chinese Simplified",
      "Croatian",
      "Czech",
      "Danish",
      "Dutch",
      "Estonian",
      "Filipino",
      "Finnish",
      "Galician",
      "German",
      "Greek",
      "Hebrew",
      "Hindi",
      "Hungarian",
      "Icelandic",
      "Indonesian",
      "Irish",
      "Japanese",
      "Korean",
      "Latvian",
      "Lithuanian",
      "Norwegian",
      "Macedonian",
      "Malay",
      "Maltese",
      "Persian",
      "Polish",
      "Portuguese",
      "Romanian",
      "Russian",
      "Serbian",
      "Slovak",
      "Slovenian",
      "Swahili",
      "Swedish",
      "Thai",
      "Turkish",
      "Ukrainian",
      "Vietnamese",
      "Welsh",
      "Yiddish",
      "Tamil",
      "Azerbaijani",
      "Kannada",
      "Basque",
      "Bengali",
      "Latin",
      "Chinese Traditional",
      "Esperanto",
      "Georgian",
      "Telugu",
      "Gujarati",
      "Haitian Creole",
      "Urdu",
      "Burmese",
      "Bosnian",
      "Cebuano",
      "Chichewa",
      "Corsican",
      "Frisian",
      "Scottish Gaelic",
      "Hausa",
      "Hawaian",
      "Hmong",
      "Igbo",
      "Javanese",
      "Kazakh",
      "Khmer",
      "Kurdish",
      "Kyrgyz",
      "Lao",
      "Luxembourgish",
      "Malagasy",
      "Malayalam",
      "Maori",
      "Marathi",
      "Mongolian",
      "Nepali",
      "Pashto",
      "Punjabi",
      "Samoan",
      "Sesotho",
      "Shona",
      "Sindhi",
      "Sinhala",
      "Somali",
      "Sundanese",
      "Swahili",
      "Tajik",
      "Uzbek",
      "Xhosa",
      "Yoruba",
      "Zulu",
      "Assammese",
      "Aymara",
      "Bambara",
      "Bhojpuri",
      "Dhivehi",
      "Dogri",
      "Ewe",
      "Guarani",
      "Ilocano",
      "Kinyarwanda",
      "Konkani",
      "Krio",
      "Kurdish - Sorani",
      "Lingala",
      "Luganda",
      "Maithili",
      "Meiteilon",
      "Mizo",
      "Odia",
      "Oromo",
      "Quechua",
      "Sanskrit",
      "Sepedi",
      "Tatar",
      "Tigrinya",
      "Tsonga",
      "Turkmen",
      "Twi",
      "Uyghur"
   );
	$all_models = aiomatic_get_all_models(true);
   $all_assistants = aiomatic_get_all_assistants(true);
?>
<div id="aiomatic-dialog" class="hidden">
  <h3 class="aiomatic-middle"><?php echo esc_html__("Post created as draft. Choose what to do next:", 'aiomatic-automatic-ai-content-writer');?></h3>
  <p class="aiomatic-middle"><button id="aiomatic-success-button" adminurl="<?php echo esc_url(admin_url('post.php?post='));?>" postid=""><?php echo esc_html__("Edit Created Post", 'aiomatic-automatic-ai-content-writer');?></button></p>
  <p class="aiomatic-middle"><button id="aiomatic-close-button" onclick="window.location='#';"><?php echo esc_html__("Continue Creating Posts With AI", 'aiomatic-automatic-ai-content-writer');?></button></p>
</div>


<div class="wrap aiomatic-admin-shell">
<section class="aiomatic-admin-main">
<div class="gs_popuptype_holder seo_pops">
<div id="tab-1" class="tab-content">
<h1 class="wp-heading-inline">
<?php echo esc_html__("Advanced Mode", 'aiomatic-automatic-ai-content-writer'); ?></h1>
<hr class="wp-header-end">
<form name="aiomatic-single-post-advanced" action="<?php echo esc_url((aiomatic_isSecure() ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");?>" method="post" id="aiomatic-single-post-advanced">
<div id="poststuff">
<div id="post-body" class="metabox-holder columns-2">
<div id="post-body-content">

<div id="modediv">

<div id="postbox-container-2" class="postbox-container">
<div id="side-sortables-2" class="meta-box-sortables ui-sortable">
<div id="settingsbox" class="postbox">
<div class="postbox-header"><h2 class="hndle ui-sortable-handle"><?php echo esc_html__("Posting Options", 'aiomatic-automatic-ai-content-writer');?></h2>
</div>
<div class="inside">

<div id="modewrap">
	<h2 class="top_heading cr_align_middle"><b><?php echo esc_html__("Posting Mode", 'aiomatic-automatic-ai-content-writer'); ?></b>&nbsp;&nbsp;<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
      <div class="bws_hidden_help_text cr_min_260px">
         <?php
            echo esc_html__("Select the posting mode you want to use. This will be equivalent with the posting modes available in the plugins Bulk Post Creator menu.", 'aiomatic-automatic-ai-content-writer');
            ?>
      </div>
   </div></h2>
   <p class="aiomatic-margin10">
<select onchange="postingModeChanged();" name="posting_mode_changer_name" id="posting_mode_changer" class="aiomatic-important coderevolution_gutenberg_input">
	<option value="1a" selected><?php echo esc_html__("Topic Based Post (Multiple API Calls) - Enter Topic", 'aiomatic-automatic-ai-content-writer'); ?></option>
	<option value="1a-"><?php echo esc_html__("Topic Based Post (Multiple API Calls) - Enter Title", 'aiomatic-automatic-ai-content-writer'); ?></option>
	<option value="1b"><?php echo esc_html__("Title Based Post (Single API Calls)", 'aiomatic-automatic-ai-content-writer'); ?></option>
	<option value="6"><?php echo esc_html__("Listicle Post", 'aiomatic-automatic-ai-content-writer'); ?></option>
	<option value="2"><?php echo esc_html__("YouTube Video To Post", 'aiomatic-automatic-ai-content-writer'); ?></option>
	<option value="3"><?php echo esc_html__("AI Product Roundup", 'aiomatic-automatic-ai-content-writer'); ?></option>
	<option value="4"><?php echo esc_html__("AI Product Review", 'aiomatic-automatic-ai-content-writer'); ?></option>
	<option value="5"><?php echo esc_html__("CSV To Post", 'aiomatic-automatic-ai-content-writer'); ?></option>
</select>
</p>
	<div class="inside">
			</div></div><!-- /modediv -->
			
<div id="topicdiv">
<div id="topicwrap">
	<h2 class="top_heading cr_align_middle"><b><?php echo esc_html__("Post Topic List", 'aiomatic-automatic-ai-content-writer'); ?>*</b>&nbsp;&nbsp;<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
      <div class="bws_hidden_help_text cr_min_260px">
         <?php
            echo esc_html__("Be sure to edit the 'Title Prompt' settings from the advanced settings to change the way titles will be created! Enter a post topic list, one on each line. If you enter multiple topics (one per line), a random topic will be selected at each run. This will set the value of the %%topic%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
            ?>
      </div>
   </div></h2>
   <p class="aiomatic-margin10">
	<textarea rows="5" id="aiomatic_topics_list" class="coderevolution_gutenberg_input" placeholder="The main topic of the content"></textarea>
</p>
</div>
	<div class="inside">
			</div></div><!-- /topicdiv -->

<div id="listiclediv" class="cr_display_none">
<div id="topicwrap">
	<h2 class="top_heading cr_align_middle"><b><?php echo esc_html__("Listicle Topic List", 'aiomatic-automatic-ai-content-writer'); ?>*</b>&nbsp;&nbsp;<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
      <div class="bws_hidden_help_text cr_min_260px">
         <?php
            echo esc_html__("Be sure to edit the 'Title Prompt' settings from the advanced settings to change the way titles will be created! Enter a post topic list, one on each line. If you enter multiple topics (one per line), a random topic will be selected at each run. This will set the value of the %%topic%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
            ?>
      </div>
   </div></h2>
   <p class="aiomatic-margin10">
	<textarea rows="5" id="aiomatic_listicle_list" class="coderevolution_gutenberg_input" placeholder="The main topic of the listicle"></textarea>
</p>
</div>
	<div class="inside">
			</div></div><!-- /listiclediv -->

<div id="inputtitlediv" class="cr_display_none">
<div id="inputtitlewrap">
	<h2 class="top_heading cr_align_middle"><b><?php echo esc_html__("Post Title List / TXT File URL / RSS Feed URL", 'aiomatic-automatic-ai-content-writer'); ?>*</b>&nbsp;&nbsp;<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
      <div class="bws_hidden_help_text cr_min_260px">
         <?php
            echo esc_html__("Input your desired post titles (one per line), a TXT file with titles (one per line) or a RSS feed URL. The plugin will select a random post title at each run. Nested spintax supported. You can also enter RSS feed URLs, from where the plugin will extract a random post title, each time it runs. If you set a RSS feed URL, an item will be randomly selected from the title/description/content of the RSS feed contents - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
            ?>
      </div>
   </div></h2>
   <p class="aiomatic-margin10">
	<textarea rows="5" id="aiomatic_titles" class="coderevolution_gutenberg_input" placeholder="Post title"></textarea>
</p>
</div>
	<div class="inside">
			</div></div><!-- /inputtitlediv -->

<div id="youtubediv" class="cr_display_none">
<div id="youtubewrap">
	<h2 class="top_heading cr_align_middle"><b><?php echo esc_html__("YouTube Video URLs", 'aiomatic-automatic-ai-content-writer'); ?>*</b>&nbsp;&nbsp;<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
      <div class="bws_hidden_help_text cr_min_260px">
         <?php
            echo wp_kses(
    sprintf(
        __(
            "Please provide the URLs to the YouTube videos (one per line). You can also enter a YouTube handle URL (channel or user), example: %s. If you have added a YouTube API key in the plugin's 'Settings' menu, this will list all recent videos from this specific YouTube channel. Otherwise, it will list videos which appear also on the featured page of the channel. Videos added here must be public and have captions available (uploaded or auto generated). In case auto generated captions are used, the quality of the created article might be lower. Nested Shortcodes are also supported!",
            'aiomatic-automatic-ai-content-writer'
        ),
        '<a href="https://www.youtube.com/@CodeRevolutionTV/videos" target="_blank">https://www.youtube.com/@CodeRevolutionTV/videos</a>'
    ),
    array(
        'a' => array(
            'href'   => array(),
            'target' => array(),
        ),
    )
);

            ?>
      </div>
   </div></h2>
   <p class="aiomatic-margin10">
	<textarea rows="5" id="aiomatic_youtube" class="coderevolution_gutenberg_input" placeholder="YouTube URL"></textarea>
</p>
</div>
	<div class="inside">
			</div></div><!-- /youtubediv -->

<div id="roundupdiv" class="cr_display_none">
<div id="roundupwrap">
	<h2 class="top_heading cr_align_middle"><b><?php echo esc_html__("Product Search Keywords / Product ASIN List", 'aiomatic-automatic-ai-content-writer'); ?>*</b>&nbsp;&nbsp;<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
      <div class="bws_hidden_help_text cr_min_260px">
         <?php
            echo esc_html__("Please provide the a search keyword for Amazon products to be included in the created article. Alternatively, you can provide a comma separated list of product ASINs (ex: B07RZ74VLR,B07RX6FBFR). To create multiple posts from the ASIN lists, add a new comma separated ASIN list to a new line.", 'aiomatic-automatic-ai-content-writer');
            ?>
      </div>
   </div></h2>
   <p class="aiomatic-margin10">
	<textarea rows="5" id="aiomatic_roundup" class="coderevolution_gutenberg_input" placeholder="Product search term"></textarea>
</p>
</div>
	<div class="inside">
			</div></div><!-- /roundupdiv -->

<div id="reviewdiv" class="cr_display_none">
<div id="reviewwrap">
	<h2 class="top_heading cr_align_middle"><b><?php echo esc_html__("Single Product ASIN or Keyword", 'aiomatic-automatic-ai-content-writer'); ?>*</b>&nbsp;&nbsp;<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
      <div class="bws_hidden_help_text cr_min_260px">
         <?php
            echo esc_html__("Please provide a single ASIN of an Amazon product (ex: B07RZ74VLR). To create multiple product review posts, add a different ASIN, each on a new line.", 'aiomatic-automatic-ai-content-writer');
            ?>
      </div>
   </div></h2>
   <p class="aiomatic-margin10">
	<textarea rows="5" id="aiomatic_review" class="coderevolution_gutenberg_input" placeholder="Product keyword or ASIN"></textarea>
</p>
</div>
	<div class="inside">
			</div></div><!-- /reviewdiv -->

<div id="csvdiv" class="cr_display_none">
<div id="csvwrap">
	<h2 class="top_heading cr_align_middle"><b><?php echo esc_html__("CSV File URLs List", 'aiomatic-automatic-ai-content-writer'); ?>*</b>&nbsp;&nbsp;<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
      <div class="bws_hidden_help_text cr_min_260px">
         <?php
            echo esc_html__("Add the URLs of the CSV files from where the plugin will get the details for publishing posts. Add each file URL on a new line.", 'aiomatic-automatic-ai-content-writer');
            ?>
      </div>
   </div></h2>
   <p class="aiomatic-margin10">
	<textarea rows="5" id="csv_title" name="csv_title" placeholder="CSV file URL" class="coderevolution_gutenberg_input"></textarea>
</p>
</div>
	<div class="inside">
			</div></div><!-- /csvdiv -->


<div id="advanceddiv">
<div id="advancedwrap">
	<h2 class="top_heading cr_align_middle"><b><?php echo esc_html__("Options", 'aiomatic-automatic-ai-content-writer'); ?></b>&nbsp;&nbsp;<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
      <div class="bws_hidden_help_text cr_min_260px">
         <?php
            echo esc_html__("Shows advanced settings for this rule.", 'aiomatic-automatic-ai-content-writer');
            ?>
      </div>
   </div></h2>
	<p class="aiomatic-middle aiomatic-margin10"><button id="aiomatic-advanced-button" class="coderevolution_gutenberg_input button dbutton-large"><?php echo esc_html__("Settings", 'aiomatic-automatic-ai-content-writer');?></button></p>
</div>
	<div class="inside">
			</div></div><!-- /advanceddiv -->

         
<div id="generatediv">
<div id="generatewrap">
	<h2 class="top_heading cr_align_middle"><b><?php echo esc_html__("Start Processing", 'aiomatic-automatic-ai-content-writer'); ?></b>&nbsp;&nbsp;<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
      <div class="bws_hidden_help_text cr_min_260px">
         <?php
            echo esc_html__("Click this button to start processing and create the content and title of the post.", 'aiomatic-automatic-ai-content-writer');
            ?>
      </div>
   </div></h2>
	<p class="aiomatic-middle aiomatic-margin10"><button id="aiomatic-generate-button" class="coderevolution_gutenberg_input button button-primary button-large"><?php echo esc_html__("Generate Title And Content", 'aiomatic-automatic-ai-content-writer');?></button></p>
   <div id="aiomaticloader" class="aiomaticloader cr_hidden"></div>
</div>
	<div id="aiomatic-status-loader" class="inside cr_center">
			</div></div><!-- /generatediv -->




         <div id="mymodalfzr5" class="codemodalfzr">
               <div class="codemodalfzr-content">
                  <div class="codemodalfzr-header">
                     <span id="aiomatic_close5" class="codeclosefzr">&times;</span>
                     <h2><span class="cr_color_white"><?php echo esc_html__("CSV File", 'aiomatic-automatic-ai-content-writer');?></span> <?php echo esc_html__("Advanced Settings", 'aiomatic-automatic-ai-content-writer');?></h2>
                  </div>
                  <div class="codemodalfzr-body">
                     <div class="table-responsive">
                        <table class="responsive table cr_main_table_nowr">
                        <tr><td colspan="2">
                                 <h3><?php echo esc_html__("CSV File Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                           </td></tr>
                           <tr>
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the separator of the CSV file. It is usually auto detected, however, if you have issues with auto detection, you can set the CSV separator here.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("CSV File Separator (Optional):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="csv_separator5" name="csv_separator" value="" placeholder="Optional, leave empty if not sure" class="valuesai5 cr_width_full">
                           </td>
                        </tr>
                           <tr><td colspan="2">
                                 <h3><?php echo esc_html__("Posting Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                           </td></tr>
                           <tr>
                              <td>
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                       <div class="bws_hidden_help_text cr_min_260px">
                                          <?php
                                             echo esc_html__("The AI writer might add the title of the post to the created post content. Check this checkbox if you want to remove the title from the post content.", 'aiomatic-automatic-ai-content-writer');
                                             ?>
                                       </div>
                                    </div>
                                    <b><?php echo esc_html__("Strip Title From Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                              </td>
                              <td>
                              <input type="checkbox" id="strip_title5" name="strip_title" class="valuesai5">
                              </td>
                           </tr>
                           <tr>
                              <td>
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                       <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip spinning of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                       </div>
                                    </div>
                                    <b><?php echo esc_html__("Do Not Spin Posts Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                              </td>
                              <td>
                              <input type="checkbox" id="skip_spin5" name="skip_spin" class="valuesai5">               
                              </td>
                           </tr>
                           <tr>
                              <td>
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                       <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip translating of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                       </div>
                                    </div>
                                    <b><?php echo esc_html__("Do Not Translate Posts Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                              </td>
                              <td>
                              <input type="checkbox" id="skip_translate5" name="skip_translate" class="valuesai5">               
                              </td>
                           </tr>
                           <tr>
                              <td>
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                       <div class="bws_hidden_help_text cr_min_260px">
                                          <?php
                                             echo esc_html__("Do you want to randomize CSV row processing order or do you want to process the lines in their order of appearence?", 'aiomatic-automatic-ai-content-writer');
                                             ?>
                                       </div>
                                    </div>
                                    <b><?php echo esc_html__("Randomize CSV Row Processing Order:", 'aiomatic-automatic-ai-content-writer');?></b>
                              </td>
                              <td>
                              <input type="checkbox" id="random_order5" name="random_order" class="valuesai5">
                              </td>
                           </tr>
                           <tr>
                              <td>
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                       <div class="bws_hidden_help_text cr_min_260px">
                                          <?php
                                             echo esc_html__("Run regex on post content. To disable this feature, leave this field blank. No Regex separators are required here. You can add multiple Regex expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                             ?>
                                       </div>
                                    </div>
                                    <b><?php echo esc_html__("Run Regex On Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                              </td>
                              <td>
                              <textarea rows="1" id="strip_by_regex5" name="strip_by_regex" placeholder="regex expression" class="valuesai5 cr_width_full"></textarea>
                              </td>
                           </tr>
                           <tr>
                              <td>
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                       <div class="bws_hidden_help_text cr_min_260px">
                                          <?php
                                             echo esc_html__("Replace the above regex matches with this regex expression. If you want to strip matched content, leave this field blank. No Regex separators are required here. You can add multiple replacement expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                             ?>
                                       </div>
                                    </div>
                                    <b><?php echo esc_html__("Replace Matches From Regex (Content):", 'aiomatic-automatic-ai-content-writer');?></b>
                              </td>
                              <td>
                              <textarea rows="1" id="replace_regex5" name="replace_regex" placeholder="regex replacement" class="valuesai5 cr_width_full"></textarea>
                              </td>
                           </tr>
                        <tr><td colspan="2">
                                 <h3><?php echo esc_html__("Automatic Linking Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                           </td></tr>
                           <tr>
                              <td>
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                       <div class="bws_hidden_help_text cr_min_260px">
                                          <?php
                                             echo esc_html__("Select the linking method to use in posts.", 'aiomatic-automatic-ai-content-writer');
                                             ?>
                                       </div>
                                    </div>
                                    <b><?php echo esc_html__("Automatic Linking Type:", 'aiomatic-automatic-ai-content-writer');?></b>
                              </td>
                              <td>
                              <select autocomplete="off" class="valuesai5 cr_width_full" id="link_type5" onchange="hideLinks('');" name="link_type">
                              <option value="disabled" selected><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="internal"><?php echo esc_html__("Internal Links", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="manual"><?php echo esc_html__("Manual Links", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="serp"><?php echo esc_html__("Related SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="mixed"><?php echo esc_html__("Internal + Manual Links", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="intserp"><?php echo esc_html__("Internal & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="manserp"><?php echo esc_html__("Manual & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="intmanserp"><?php echo esc_html__("Internal & Manual & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                              </select>   
                              </td>
                           </tr>
                           <tr>
                              <td class="cr_min_width_200">
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                       <div class="bws_hidden_help_text cr_min_260px">
                                          <?php
                                             echo esc_html__("Set the maximum number of automatic links to add to created posts. You can also define custom ranges, like: 3-5. Please note that this feature will work best if you already have a considerable number of posts published on your site, which will be used for internal linking.", 'aiomatic-automatic-ai-content-writer');
                                             ?>
                                       </div>
                                    </div>
                                    <b><?php echo esc_html__("Maximum Number Of Automatic Links To Add To The Post Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                              </td>
                              <td>
                              <input type="text" name="max_links" id="max_links5" placeholder="3-5" class="valuesai5 cr_width_full">
                              </td>
                           </tr>
                           <tr class="hidelinks">
                              <td class="cr_min_width_200">
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                       <div class="bws_hidden_help_text cr_min_260px">
                                          <?php
                                             echo esc_html__("Enter a manual list of links, where the plugin will create links.", 'aiomatic-automatic-ai-content-writer');
                                             ?>
                                       </div>
                                    </div>
                                    <b><?php echo esc_html__("Manual List Of URLs (One Per Line):", 'aiomatic-automatic-ai-content-writer');?></b>
                              </td>
                              <td>
                              <textarea rows="1" cols="70" name="link_list" id="link_list5" placeholder="URL list (one per line)" class="valuesai5 cr_width_full"></textarea>
                              </td>
                           </tr>
                           <tr class="hidelinks">
                              <td class="cr_min_width_200">
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                       <div class="bws_hidden_help_text cr_min_260px">
                                          <?php
                                             echo esc_html__("Do you want to add nofollow attribute to manually entered, external links?", 'aiomatic-automatic-ai-content-writer');
                                             ?>
                                       </div>
                                    </div>
                                    <b><?php echo esc_html__("Add Nofollow Attribute To External Links:", 'aiomatic-automatic-ai-content-writer');?></b>
                              </td>
                              <td>
                              <input type="checkbox" id="link_nofollow5" name="link_nofollow" class="valuesai5">
                              </td>
                           </tr>
                           <tr>
                              <td class="cr_min_width_200">
                                    <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                       <div class="bws_hidden_help_text cr_min_260px">
                                          <?php
                                             echo esc_html__("Set the post types where to create automatic links in posts. You can also add a comma separated list of multiple post types.", 'aiomatic-automatic-ai-content-writer');
                                             ?>
                                       </div>
                                    </div>
                                    <b><?php echo esc_html__("Post Types Where To Generate Automatic Links:", 'aiomatic-automatic-ai-content-writer');?></b>
                              </td>
                              <td>
                              <input type="text" name="link_post_types" id="link_post_types5" placeholder="post" class="valuesai5 cr_width_full">
                              </td>
                           </tr>
                        </table>
                     </div>
                  </div>
                  <div class="codemodalfzr-footer">
                     <br/>
                     <h3 class="cr_inline">Aimogen Automatic Post Generator</h3>
                     <span id="aiomatic_ok5" class="codeokfzr cr_inline">OK&nbsp;</span>
                     <br/><br/>
                  </div>
               </div>
            </div>


            <div id="mymodalfzr6" class="codemodalfzr">
            <div class="codemodalfzr-content">
               <div class="codemodalfzr-header">
                  <span id="aiomatic_close6" class="codeclosefzr">&times;</span>
                  <h2><span class="cr_color_white"><?php echo esc_html__("Listicle Article", 'aiomatic-automatic-ai-content-writer');?></span> <?php echo esc_html__("Advanced Settings", 'aiomatic-automatic-ai-content-writer');?></h2>
               </div>
               <div class="codemodalfzr-body">
                  <div class="table-responsive">
                     <table class="responsive table cr_main_table_nowr">
                     <tr><td colspan="2">
                           <h3><?php echo esc_html__("AI Assistant Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                     </td></tr>
                     <tr>
                        <td class="cr_min_width_200">
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("Select the AI Assistant to use for content creation. This will disable the ability to select AI models, as the models assisgned to the assistant will be used for content creation.", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                              <b><?php echo esc_html__("AI Assistant Name:", 'aiomatic-automatic-ai-content-writer');?></b>
                        </td>
                        <td><select id="assistant_id6" name="assistant_id" class="valuesai6 cr_width_full" onchange="assistantSelected('6');">
<?php
if($all_assistants === false)
{
echo '<option val="" selected disabled>' . esc_html__("Only OpenAI API is supported for Assistants API", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
if(count($all_assistants) == 0)
{
echo '<option val="" selected disabled>' . esc_html__("No Assistans added, go to the plugin's 'AI Assistans' menu to add new assistants!", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
echo '<option value="" selected';
echo '>' . esc_html__("Don't use assistants, use AI models instead", 'aiomatic-automatic-ai-content-writer') . '</option>';
foreach($all_assistants as $myassistant)
{
echo '<option value="' . esc_html($myassistant->ID) .'"';
echo '>' . esc_html($myassistant->post_title);
echo '</option>';
}
}
}
?>
</select>  
                        </td>
                     </tr>
                        <tr class="hidetopic"><td colspan="2">
                              <h3><?php echo esc_html__("Listicle Article Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the method to be used for the title generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Title Generator Method:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" class="valuesai6 cr_width_full" id="title_generator_method6" name="title_generator_method">
                           <option value="ai" selected><?php echo esc_html__("AI Writer", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="serp"><?php echo esc_html__("Related SERP Searches", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a list of post sections, one per line. These will be headings of the content. These can also be automatically generated by the plugin. To enable auto generating of sections, leave this field blank. You can use here the %%topic%% shortcode, to get the value of the above topic, automtically. This will set the value of the %%sections%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. If you set a section list here, each created article will have this same list of sections, because of this, use shortcodes or Spintax when defining these static topics or leave this field blank for the plugin to auto generate them!", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Post Sections List (Optional):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_sections_list" id="post_sections_list6" placeholder="Post sections list (one per line)" class="valuesai6 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter the number of listicle entries to create in the article. These will also be set as article headings. You can also set value ranges, example: 5-7. In this case, a random number will be selected in this range. Please use only numeric values in this field. This field will set the value of the %%sections_count%% shortcode.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Number Of Listicle Entries To Generate:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <input type="text" id="section_count6" name="section_count" placeholder="3-4" class="valuesai6 cr_width_full" value="3-4">  
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select what you want to do with listicle entries in articles.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Listicle Entries To Content As:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" class="valuesai6 cr_width_full" id="sections_role6" name="sections_role">
                           <option value="h2" selected><?php echo esc_html__("h2", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="h3"><?php echo esc_html__("h3", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="b"><?php echo esc_html__("Bold", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="i"><?php echo esc_html__("Italic", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="bi"><?php echo esc_html__("Bold and Italic", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="p"><?php echo esc_html__("Paragraph", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="x"><?php echo esc_html__("Plain Text", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="no"><?php echo esc_html__("Don't Add Sections", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter the number of paragraphs to create for each Listicle Entry. These will also be set as article headings. You can also set value ranges, example: 5-7. In this case, a random number will be selected in this range. Please use only numeric values in this field. This field will set the value of the %%paragraphs_per_section%% shortcode.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Number Of Paragraphs Per Listicle Entry:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <input type="text" id="paragraph_count6" name="paragraph_count" placeholder="2-3" class="valuesai6 cr_width_full" value="2">  
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the number of related images to add to the created post content. This feature will use the royalty free image sources configured in the plugin's 'Settings' menu or if you have access to the OpenAI API. You can change image source in the 'AI Image Source' settings field from below. The maximum number of images you can add to each article: number of sections + 2", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Number of Images To Add To The Article:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="topic_images" id="topic_images6" value="" placeholder="Number of images" class="valuesai6 cr_width_full">
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add an image to each of the creating headings from the article.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add An Image To Each Heading Of The Article:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="img_all_headings6" name="img_all_headings" class="valuesai6" checked>
                           </td>
                        </tr> 
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the location of the heading images.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Heading Image Location:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="heading_img_location6" name="heading_img_location" class="valuesai6 cr_width_full">
                              <option value="top" selected><?php echo esc_html__("Top of the section", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="heading"><?php echo esc_html__("Under the heading text", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="bottom"><?php echo esc_html__("Bottom of the section", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="random"><?php echo esc_html__("Random", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the number of related social embeds to add to the created post content. The maximum number of embeds you can add to each article: number of sections You can select the source of the social embeds, in the plugin's 'Settings' menu -> 'Bulk Posts' tab -> 'Social Networks To Get Embeds From In AI Created Articles' settings field.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Number of Social Network Embeds To Add To The Article:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" name="topic_videos" id="topic_videos6" value="" placeholder="Number of social embeds" class="valuesai6 cr_width_full">
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the outro section header. This is optional.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Outro Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="title_outro" id="title_outro6" value="{In Conclusion|To Conclude|In Summary|To Wrap It Up|Key Takeaways|Future Outlook|Closing Remarks|The Conclusion|Final Thoughts|In Retrospect|The Way Forward|Wrapping Up|Concluding Remarks|Insights and Conclusions}" placeholder="Optional" class="valuesai6 cr_width_full">
                           </td>
                        </tr> 
                        <tr class="hidetopic">
                           <td class="hideTOC-1">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add a Table of Contents section to the created post.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Article Table Of Contents:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td class="hideTOC-1">
                           <input type="checkbox" id="enable_toc6" name="enable_toc" class="valuesai6">
                           </td>
                        </tr> 
                        <tr class="hidetopic">
                           <td class="hideTOC-1">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the Table of Contents section header. Default is: Table of Contents", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Table Of Contents Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td class="hideTOC-1">
                           <input type="text" name="title_toc" id="title_toc6" value="Table of Contents" placeholder="Table of Contents" class="valuesai6 cr_width_full">
                           </td>
                        </tr> 
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add a Q&A section to the created post. To enable Q&A for articles, be sure to add a prompt also in the 'Article Q&A Prompt' settings field from below.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Article Q&A Section:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="enable_qa6" name="enable_qa" class="valuesai6">
                           </td>
                        </tr> 
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the Q&A section header. Default is: Q&A", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Q&A Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="title_qa6" name="title_qa" value="Q&A" placeholder="Q&A" class="valuesai6 cr_width_full">
                           </td>
                        </tr> 
                        <tr class="hidetopic"><td colspan="2">
                              <h4><?php echo esc_html__("Content Parameters", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the language of the created content. This will set the value of the %%language%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Content Language:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="content_language6" name="content_language" type="text" list="languages6" placeholder="Created content language" class="valuesai6 coderevolution_gutenberg_input" value="English"/>
<datalist id="languages6">
<?php
foreach($aiomatic_language_names as $ln)
{
echo '<option>' . esc_html($ln) . '</option>';
}
?>
</datalist>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the writing style of the created content. This will set the value of the %%writing_style%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Writing Style:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="writing_style6" name="writing_style" type="text" placeholder="Created content writing style" list="writing_styles6" class="valuesai6 coderevolution_gutenberg_input" value="Creative"/>
                           <datalist id="writing_styles6">
<option>Informative</option>
<option>Academic</option>
<option>Descriptive</option>
<option>Detailed</option>
<option>Dramative</option>
<option>Fiction</option>
<option>Expository</option>
<option>Historical</option>
<option>Dialogue</option>
<option>Creative</option>
<option>Critical</option>
<option>Narrative</option>
<option>Persuasive</option>
<option>Reflective</option>
<option>Argumentative</option>
<option>Analytical</option>
<option>Blog</option>
<option>News</option>
<option>Casual</option>
<option>Pastoral</option>
<option>Personal</option>
<option>Poetic</option>
<option>Satirical</option>
<option>Sensory</option>
<option>Articulate</option>
<option>Monologue</option>
<option>Colloquial</option>
<option>Comparative</option>
<option>Concise</option>
<option>Biographical</option>
<option>Anecdotal</option>
<option>Evaluative</option>
<option>Letter</option>
<option>Lyrical</option>
<option>Simple</option>
<option>Vivid</option>
<option>Journalistic</option>
<option>Technical</option>
<option>Direct</option>
<option>Emotional</option>
<option>Metaphorical</option>
<option>Objective</option>
<option>Rhetorical</option>
<option>Theoretical</option>
<option>Business</option>
<option>Report</option>
<option>Research</option>
</datalist>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the writing tone of the created content. This will set the value of the %%writing_tone%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Writing Tone:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="writing_tone6" name="writing_tone" type="text" list="writing_tones6" placeholder="Created content writing tone" class="valuesai6 coderevolution_gutenberg_input" value="Neutral"/>
                           <datalist id="writing_tones6">
<option>Neutral</option>
<option>Formal</option>
<option>Assertive</option>
<option>Cheerful</option>
<option>Humorous</option>
<option>Informal</option>
<option>Inspirational</option>
<option>Professional</option>
<option>Emotional</option>
<option>Persuasive</option>
<option>Supportive</option>
<option>Sarcastic</option>
<option>Condescending</option>
<option>Skeptical</option>
<option>Narrative</option>
<option>Journalistic</option>
<option>Conversational</option>
<option>Factual</option>
<option>Friendly</option>
<option>Polite</option>
<option>Scientific</option>
<option>Sensitive</option>
<option>Sincere</option>
<option>Curious</option>
<option>Dissapointed</option>
<option>Encouraging</option>
<option>Optimistic</option>
<option>Surprised</option>
<option>Worried</option>
<option>Confident</option>
<option>Authoritative</option>
<option>Nostalgic</option>
<option>Sympathetic</option>
<option>Suspenseful</option>
<option>Romantic</option>
<option>Serious</option>
</datalist>
                           </td>
                        </tr>
                        <tr class="hidetopic"><td colspan="2">
                              <h4><?php echo esc_html__("Prompts", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Post Title. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Title Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="title_prompt" id="title_prompt6" placeholder="Enter your title prompts, one per line" class="valuesai6 cr_width_full">Write a title for a listicle about "%%topic%%" in %%language%%. The listicle will include %%sections_count%% items. Style: %%writing_style%%. Tone: %%writing_tone%%. Include a specific number in the title to indicate a list. Must be between 40 and 60 characters.</textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the title generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Title Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_title_model6" name="topic_title_model" class="hideAssistant6 valuesai6 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the intro of the article. You can use the following shortcodes: %%title%%, %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Intro Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="intro_prompt" id="intro_prompt6" placeholder="Enter your intro prompts, one per line" class="valuesai6 cr_width_full">Craft an introduction for a listicle about "%%title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. Highlight the number of items in the list and what the reader can expect to learn or gain from the listicle.</textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the intro generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Intro Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_intro_model6" name="topic_intro_model" class="hideAssistant6 valuesai6 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Listicle Entries. These will be set also as headings in the article. You can use the following shortcodes: %%title%%, %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Listicle Entries Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="sections_prompt" id="sections_prompt6" placeholder="Enter your sections prompts, one per line" class="valuesai6 cr_width_full">Write %%sections_count%% consecutive entries for a listicle about "%%title%%". The entries must be written in %%language%%, following a %%writing_style%% style and a %%writing_tone%% tone. Don't use HTML in your response, write only plain text entries, one on each line, as I will use these entries to further create content for each of them. Return only the entries, nothing else.</textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the Listicle Entries generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Listicle Entries Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_sections_model6" name="topic_sections_model" class="hideAssistant6 valuesai6 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Content of the article, which will be applied to each section heading generated by the plugin (or entered manually) or to the entire content (depending how you select using the 'Use the Above Content Prompt To Create The Entire Article' checkbox). You can use the following shortcodes: %%title%%, %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections%%, %%current_section%%, %%paragraphs_per_section%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Listicle Entries Content Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="3" cols="70" name="content_prompt" id="content_prompt6" placeholder="Enter your content prompt" class="valuesai6 cr_width_full">Write the content of a listicle section for the heading "%%current_section%%" in %%language%%. The title of the post is: "%%title%%". Don't add the title at the beginning of the created content. Be creative and unique. Don't repeat the heading in the created content. Don't add an intro or outro. Write %%paragraphs_per_section%% paragraphs in the section. Use HTML for formatting, include unnumbered lists and bold. If needed, you can use WordPress related CSS styling for the article. When applicable, add also HTML tables with WordPress styling (you can use WordPress table classes). If added, table data must be relevant, creative, short and simple. Act as a Content Writer, not as a Virtual Assistant. Return only the content requested, without any additional comments or text. Writing Style: %%writing_style%%. Tone: %%writing_tone%%.</textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the content generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Content Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_content_model6" name="topic_content_model" class="hideAssistant6 valuesai6 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to use the above content prompt to create the entire article from a single API call (checkbox checked) or to run the prompt for each section separately (checkbox unchecked). If you check this, be sure to modify the content prompt accordingly.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Use the Above Content Prompt To Create The Entire Article (Not Each Section):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="single_content_call-16" name="single_content_call" onclick="hideTOC(-1);" class="valuesai6">
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Q&A of the article. You can use the following shortcodes: %%title%%, %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Q&A Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="qa_prompt" id="qa_prompt6" placeholder="Enter your Q&A prompts, one per line" class="valuesai6 cr_width_full">Write a Q&A listicle for an article about "%%title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. Each question should be clear and engaging, followed by a detailed and informative answer. Use HTML for formatting, include unnumbered lists and bold where applicable. Return only the Q&A content, nothing else.</textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the Q&A generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Q&A Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_qa_model6" name="topic_qa_model" class="hideAssistant6 valuesai6 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the outro of the article. You can use the following shortcodes: %%title%%, %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Outro Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="outro_prompt" id="outro_prompt6" placeholder="Enter your outro prompts, one per line" class="valuesai6 cr_width_full">Write an outro for a listicle about "%%title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%.</textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the outro generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Outro Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_outro_model6" name="topic_outro_model" class="hideAssistant6 valuesai6 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the excerpt of the article. You can use the following shortcodes: %%title%%, %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Excerpt Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="excerpt_prompt" id="excerpt_prompt6" placeholder="Enter your excerpt prompts, one per line" class="valuesai6 cr_width_full">Write a short excerpt for a listicle about "%%title%%" in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. Must be between 150 and 250 characters. Highlight the listicle nature of the article and what readers can expect to find.</textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the excerpt generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Excerpt Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_excerpt_model6" name="topic_excerpt_model" class="hideAssistant6 valuesai6 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic"><td colspan="2">
                              <h4><?php echo esc_html__("Advanced Prompting Options", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Run regex on prompts. To disable this feature, leave this field blank. No Regex separators are required here. You can add multiple Regex expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Regex On Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="strip_by_regex_prompts" id="strip_by_regex_prompts6" placeholder="regex expression" class="valuesai6 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Replace the above regex matches with this regex expression. If you want to strip matched content, leave this field blank. No Regex separators are required here. You can add multiple replacement expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Replace Matches From Regex (Prompts):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="replace_regex_prompts" id="replace_regex_prompts6" placeholder="regex replacement" class="valuesai6 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select on which prompts do you want to run the above Regex. Possible values are (or any of their combinations): title, intro, sections, content, outro, excerpt", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Above Regex On Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="run_regex_on6" name="run_regex_on" type="text" list="run_regex_on_list6" class="valuesai6 coderevolution_gutenberg_input" value="content"/>
<datalist id="run_regex_on_list6">
<option value="title">title</option>
<option value="intro">intro</option>
<option value="sections">sections</option>
<option value="content">content</option>
<option value="qa">Q&A</option>
<option value="outro">outro</option>
<option value="excerpt">excerpt</option>
</datalist> 
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Global Prompt Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This will be prepended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Prepend Text To All Textual AI Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="global_prepend" id="global_prepend6" placeholder="Global prompt prepend text" class="valuesai6 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This will be appended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Append Text To All Textual AI Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="global_append" id="global_append6" placeholder="Global prompt append text" class="valuesai6 cr_width_full"></textarea>
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Automatic Linking Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the linking method to use in posts.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Automatic Linking Type:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" class="valuesai6 cr_width_full" id="link_type6" onchange="hideLinks('');" name="link_type">
                           <option value="disabled" selected><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="internal"><?php echo esc_html__("Internal Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="manual"><?php echo esc_html__("Manual Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="serp"><?php echo esc_html__("Related SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="mixed"><?php echo esc_html__("Internal + Manual Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="intserp"><?php echo esc_html__("Internal & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="manserp"><?php echo esc_html__("Manual & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="intmanserp"><?php echo esc_html__("Internal & Manual & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of automatic links to add to created posts. You can also define custom ranges, like: 3-5. Please note that this feature will work best if you already have a considerable number of posts published on your site, which will be used for internal linking.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Number Of Automatic Links To Add To The Post Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="max_links" id="max_links6" placeholder="3-5" class="valuesai6 cr_width_full">
                           </td>
                        </tr>
                        <tr class="hidelinks">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a manual list of links, where the plugin will create links.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Manual List Of URLs (One Per Line):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" cols="70" name="link_list" id="link_list6" placeholder="URL list (one per line)" class="valuesai6 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr class="hidelinks">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to add nofollow attribute to manually entered, external links?", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Nofollow Attribute To External Links:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="link_nofollow6" name="link_nofollow" class="valuesai6">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the post types where to create automatic links in posts. You can also add a comma separated list of multiple post types.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Post Types Where To Generate Automatic Links:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="link_post_types" id="link_post_types6" placeholder="post" class="valuesai6 cr_width_full">
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Advanced AI Text Generator Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. Note that in this value the number of tokens sent to the API as an article prompt will also be counted. The maximum amount which can be set is 4000. For other models, the maximum is 2048.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Total Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_tokens" id="max_tokens6" value="" placeholder="32768" class="valuesai6 cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of prompt API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. This defines how much content does the API receive each time you call it. If the API gets more initial data, better quality results will be expected. The maximum amount which can be set is 1000.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Prompt Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_seed_tokens" id="max_seed_tokens6" value="" placeholder="1000" class="valuesai6 cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("What sampling temperature to use. Higher values means the model will take more risks. Try 0.9 for more creative applications, and 0 (argmax sampling) for ones with a well-defined answer. We generally recommend altering this or top_p but not both.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Temperature:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" step="0.01" max="2" name="temperature" id="temperature6" value="" placeholder="1" class="valuesai6 cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("An alternative to sampling with temperature, called nucleus sampling, where the model considers the results of the tokens with top_p probability mass. So 0.1 means only the tokens comprising the top 10% probability mass are considered. We generally recommend altering this or temperature but not both.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Top_p:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" max="1" step="0.01" name="top_p" id="top_p6" value="" placeholder="1" class="valuesai6 cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on whether they appear in the text so far, increasing the model's likelihood to talk about new topics.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Presence Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="-2" step="0.01" max="2" name="presence_penalty" id="presence_penalty6" value="" placeholder="0" class="valuesai6 cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on their existing frequency in the text so far, decreasing the model's likelihood to repeat the same line verbatim.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Frequency Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" max="2" step="0.01" name="frequency_penalty" id="frequency_penalty6" value="" placeholder="0" class="valuesai6 cr_width_full">
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Image Generator Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the search query repetition mode, when searching royalty free images.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Search Query Repetition:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="search_query_repetition6" name="search_query_repetition" class="valuesai6 cr_width_full">
                              <option value="0" selected><?php echo esc_html__("Use Different Search Queries For Images", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1"><?php echo esc_html__("Use The Same Search Query For Images", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to enable the AI Image Generator and to replace Royalty Free Images with AI generated images?", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Image Source:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="enable_ai_images6" onchange="hideImage('6');" name="enable_ai_images" class="valuesai6 cr_width_full">
                              <option value="0" selected><?php echo esc_html__("Royalty Free", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1"><?php echo esc_html__("OpenAI/AiomaticAPI", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              if (isset($aiomatic_Main_Settings['stability_app_id']) && trim($aiomatic_Main_Settings['stability_app_id']) != '')
                              {
                              ?>
                              <option value="2"><?php echo esc_html__("Stability.AI", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['midjourney_app_id']) && trim($aiomatic_Main_Settings['midjourney_app_id']) != '')
                              {
                              ?>
                              <option value="4"><?php echo esc_html__("Midjourney", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['replicate_app_id']) && trim($aiomatic_Main_Settings['replicate_app_id']) != '')
                              {
                              ?>
                              <option value="5"><?php echo esc_html__("Replicate", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['ideogram_app_id']) && trim($aiomatic_Main_Settings['ideogram_app_id']) != '')
                              {
                              ?>
                              <option value="6"><?php echo esc_html__("Ideogram", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['cloudflare_worker_url']) && trim($aiomatic_Main_Settings['cloudflare_worker_url']) != '' && isset($aiomatic_Main_Settings['cloudflare_worker_secret']) && trim($aiomatic_Main_Settings['cloudflare_worker_secret']) != '')
                              {
                              ?>
                              <option value="8"><?php echo esc_html__("Cloudflare Workers", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['app_id_google']) && trim($aiomatic_Main_Settings['app_id_google']) != '')
                              {
                              ?>
                              <option value="7"><?php echo esc_html__("Google", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              ?>
                              <option value="9"><?php echo esc_html__("Random From Media Library", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
                           </td>
                        </tr>
                        <tr class="hideImg6 cr_none">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set list of prompt commands (one on each line) you want to send to the AI image generator. This command can be any given task or order, based on which, it will generate images. You can use the following shortcodes: %%post_title%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%. Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You can also add here a link to a .txt file, where you can add multiple prompts (one per line) and the plugin will select a random one at each run. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          echo '&nbsp;' . sprintf( wp_kses( __( "Please check some tips and tricks about writing prompt commands, <a href='%s' target='_blank'>here</a>. The [aicontent] shortcode is able to be used also here.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-image-generating-for-openai-dall-e-api/' );
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Prompt For The AI Image Generator:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-image-generating-for-openai-dall-e-api/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="ai_command_image" id="ai_command_image6" placeholder="Please insert a command for the AI image generator" class="valuesai6 cr_width_full">Generate a high-resolution, visually compelling image that creatively interprets the theme encapsulated by this post title: "%%post_title%%". The image should be versatile enough to fit various niches, from technology and lifestyle to nature and science. It should feature a central, eye-catching element that abstractly represents the topic, surrounded by relevant, subtler motifs that provide context and depth. The composition should be balanced and aesthetically pleasing, with a harmonious color palette that complements the mood of the title. The artwork should be suitable for use as a captivating header image for a blog post.</textarea>
                           </td>
                        </tr>
                        <tr class="hideDalle6 cr_none">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI model you wish to use for image the image generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Image Model:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="image_model6" name="image_model" class="valuesai6 cr_width_full">
<?php
foreach(AIMOGEN_DALLE_IMAGE_MODELS as $modelx)
{
   echo '<option value="' . esc_html($modelx) .'"';
   if ($modelx == AIMOGEN_DEFAULT_IMAGE_MODEL) { echo ' selected'; }
   echo '>' . esc_html($modelx) . '</option>';
}
?>
                           </select>
                           </td>
                        </tr>
                        <tr class="hideImg6 cr_none">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the size of the generated image.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Generated Image Size:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="model6" name="image_size" class="cr_width_full valuesai6">
                              <option value="256x256"><?php echo esc_html__("256x256", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="512x512"><?php echo esc_html__("512x512", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1024x1024" selected><?php echo esc_html__("1024x1024", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>  
                           </td>
                        </tr>
                        <tr><td colspan="2">
                              <h3><?php echo esc_html__("Posting Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a HTML text that should be prepended to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%random_sentence%%, %%random_sentence2%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("HTML Text To Prepend To AI Created Content:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_prepend" id="post_prepend6" placeholder="HTML content to prepend to the AI generated content" class="cr_width_full valuesai6"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a HTML text that should be appended to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%random_sentence%%, %%random_sentence2%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("HTML Text To Append To AI Created Content:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_append" id="post_append6" placeholder="HTML content to append to the AI generated content" class="cr_width_full valuesai6"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Custom AI generated content shortcode creator. If you wish to create content from multiple AI prompts, and use them in post content/post custom fields/taxonomies, you can configure this from here. Also, these shortcodes will be able to be used in custom fields or custom taxonomies which the plugin will create. Syntax for this field: shortcode_name => AI_MODEL_TO_USE @@ TEXTUAL_PROMPT_TO_USE (to specify multiple shortcodes and crawling values, separate them by a new line. Example: my_custom_shortcode => gpt-5-mini @@ Write a short poem. Afterwards, you can use shortcodes in any settings field that supports shortcodes (ex: 'HTML Text To Append To AI Created Content' settings field), like this: %%my_custom_shortcode%%. Official format is %%name_of_custom_shortcode%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Custom Shortcode Creator (Optional):", 'aiomatic-automatic-ai-content-writer');?></b><span class="tool" data-tip="Supported models: <?php echo esc_html(implode(',', aiomatic_get_all_models()));?>">&nbsp;&#9432;</span>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="custom_shortcodes" id="custom_shortcodes6" placeholder="shortcode_name => AI_MODEL @@ AI_PROMPT" class="valuesai6 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("The AI writer might add the title of the post to the created post content. Check this checkbox if you want to remove the title from the post content.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Strip Title From Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="strip_title6" name="strip_title" class="valuesai6">
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip spinning of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Do Not Spin Posts Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="skip_spin6" name="skip_spin" class="valuesai6">               
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip translating of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Do Not Translate Posts Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="skip_translate6" name="skip_translate" class="valuesai6">               
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Run regex on post content. To disable this feature, leave this field blank. No Regex separators are required here. You can add multiple Regex expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Regex On Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" class="valuesai6 cr_width_full" name="strip_by_regex" id="strip_by_regex6" placeholder="regex expression"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Replace the above regex matches with this regex expression. If you want to strip matched content, leave this field blank. No Regex separators are required here. You can add multiple replacement expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Replace Matches From Regex (Content):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" class="valuesai6 cr_width_full" name="replace_regex" id="replace_regex6" placeholder="regex replacement"></textarea>
                           </td>
                        </tr>
                     </table>
                  </div>
               </div>
               <div class="codemodalfzr-footer">
                  <br/>
                  <h3 class="cr_inline">Aimogen Automatic Post Generator</h3>
                  <span id="aiomatic_ok6" class="codeokfzr cr_inline">OK&nbsp;</span>
                  <br/><br/>
               </div>
            </div>
         </div>
         <div id="mymodalfzr1a" class="codemodalfzr">
            <div class="codemodalfzr-content">
               <div class="codemodalfzr-header">
                  <span id="aiomatic_close1a" class="codeclosefzr">&times;</span>
                  <h2><span class="cr_color_white"><?php echo esc_html__("Topic Based", 'aiomatic-automatic-ai-content-writer');?></span> <?php echo esc_html__("Advanced Settings", 'aiomatic-automatic-ai-content-writer');?></h2>
               </div>
               <div class="codemodalfzr-body">
                  <div class="table-responsive">
                     <table class="responsive table cr_main_table_nowr">
                     <tr><td colspan="2">
                           <h3><?php echo esc_html__("AI Assistant Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                     </td></tr>
                     <tr>
                        <td class="cr_min_width_200">
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("Select the AI Assistant to use for content creation. This will disable the ability to select AI models, as the models assisgned to the assistant will be used for content creation.", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                              <b><?php echo esc_html__("AI Assistant Name:", 'aiomatic-automatic-ai-content-writer');?></b>
                        </td>
                        <td><select id="assistant_id1a" name="assistant_id" class="valuesai1a cr_width_full" onchange="assistantSelected('1a');">
<?php
if($all_assistants === false)
{
echo '<option val="" selected disabled>' . esc_html__("Only OpenAI API is supported for Assistants API", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
if(count($all_assistants) == 0)
{
echo '<option val="" selected disabled>' . esc_html__("No Assistans added, go to the plugin's 'AI Assistans' menu to add new assistants!", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
echo '<option value="" selected';
echo '>' . esc_html__("Don't use assistants, use AI models instead", 'aiomatic-automatic-ai-content-writer') . '</option>';
foreach($all_assistants as $myassistant)
{
echo '<option value="' . esc_html($myassistant->ID) .'"';
echo '>' . esc_html($myassistant->post_title);
echo '</option>';
}
}
}
?>
</select>  
                        </td>
                     </tr>
                        <tr class="hidetopic"><td colspan="2">
                              <h3><?php echo esc_html__("Topic Based Posting Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the method to be used for the title generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Title Generator Method:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" class="valuesai1a cr_width_full" id="title_generator_method1a" name="title_generator_method">
                           <option value="ai" selected><?php echo esc_html__("AI Writer", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="serp"><?php echo esc_html__("Related SERP Searches", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a list of post sections, one per line. These will be headings of the content. These can also be automatically generated by the plugin. To enable auto generating of sections, leave this field blank. You can use here the %%topic%% shortcode, to get the value of the above topic, automtically. This will set the value of the %%sections%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. If you set a section list here, each created article will have this same list of sections, because of this, use shortcodes or Spintax when defining these static topics or leave this field blank for the plugin to auto generate them!", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Post Sections List (Optional):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_sections_list" id="post_sections_list1a" placeholder="Post sections list (one per line)" class="valuesai1a cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter the number of sections to create in the article. These will also be set as article headings. You can also set value ranges, example: 5-7. In this case, a random number will be selected in this range. Please use only numeric values in this field. This field will set the value of the %%sections_count%% shortcode.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Number Of Content Sections To Generate:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <input type="text" id="section_count1a" name="section_count" placeholder="3-4" class="valuesai1a cr_width_full" value="3-4">  
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select what you want to do with sections in articles.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Sections To Content As:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" class="valuesai1a cr_width_full" id="sections_role1a" name="sections_role">
                           <option value="h2" selected><?php echo esc_html__("h2", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="h3"><?php echo esc_html__("h3", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="b"><?php echo esc_html__("Bold", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="i"><?php echo esc_html__("Italic", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="bi"><?php echo esc_html__("Bold and Italic", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="p"><?php echo esc_html__("Paragraph", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="x"><?php echo esc_html__("Plain Text", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="no"><?php echo esc_html__("Don't Add Sections", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter the number of paragraphs to create for each section. These will also be set as article headings. You can also set value ranges, example: 5-7. In this case, a random number will be selected in this range. Please use only numeric values in this field. This field will set the value of the %%paragraphs_per_section%% shortcode.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Number Of Paragraphs Per Section:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <input type="text" id="paragraph_count1a" name="paragraph_count" placeholder="2-3" class="valuesai1a cr_width_full" value="2">  
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the number of related images to add to the created post content. This feature will use the royalty free image sources configured in the plugin's 'Settings' menu or if you have access to the OpenAI API. You can change image source in the 'AI Image Source' settings field from below. The maximum number of images you can add to each article: number of sections + 2", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Number of Images To Add To The Article:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="topic_images" id="topic_images1a" value="" placeholder="Number of images" class="valuesai1a cr_width_full">
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add an image to each of the creating headings from the article.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add An Image To Each Heading Of The Article:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="img_all_headings1a" name="img_all_headings" class="valuesai1a" checked>
                           </td>
                        </tr> 
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the location of the heading images.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Heading Image Location:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="heading_img_location1a" name="heading_img_location" class="valuesai1a cr_width_full">
                              <option value="top" selected><?php echo esc_html__("Top of the section", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="heading"><?php echo esc_html__("Under the heading text", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="bottom"><?php echo esc_html__("Bottom of the section", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="random"><?php echo esc_html__("Random", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the number of related social embeds to add to the created post content. The maximum number of embeds you can add to each article: number of sections You can select the source of the social embeds, in the plugin's 'Settings' menu -> 'Bulk Posts' tab -> 'Social Networks To Get Embeds From In AI Created Articles' settings field.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Number of Social Network Embeds To Add To The Article:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" name="topic_videos" id="topic_videos1a" value="" placeholder="Number of social embeds" class="valuesai1a cr_width_full">
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the outro section header. This is optional.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Outro Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="title_outro" id="title_outro1a" value="{In Conclusion|To Conclude|In Summary|To Wrap It Up|Key Takeaways|Future Outlook|Closing Remarks|The Conclusion|Final Thoughts|In Retrospect|The Way Forward|Wrapping Up|Concluding Remarks|Insights and Conclusions}" placeholder="Optional" class="valuesai1a cr_width_full">
                           </td>
                        </tr> 
                        <tr class="hidetopic">
                           <td class="hideTOC-1">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add a Table of Contents section to the created post.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Article Table Of Contents:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td class="hideTOC-1">
                           <input type="checkbox" id="enable_toc1a" name="enable_toc" class="valuesai1a">
                           </td>
                        </tr> 
                        <tr class="hidetopic">
                           <td class="hideTOC-1">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the Table of Contents section header. Default is: Table of Contents", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Table Of Contents Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td class="hideTOC-1">
                           <input type="text" name="title_toc" id="title_toc1a" value="Table of Contents" placeholder="Table of Contents" class="valuesai1a cr_width_full">
                           </td>
                        </tr> 
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add a Q&A section to the created post. To enable Q&A for articles, be sure to add a prompt also in the 'Article Q&A Prompt' settings field from below.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Article Q&A Section:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="enable_qa1a" name="enable_qa" class="valuesai1a">
                           </td>
                        </tr> 
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the Q&A section header. Default is: Q&A", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Q&A Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="title_qa1a" name="title_qa" value="Q&A" placeholder="Q&A" class="valuesai1a cr_width_full">
                           </td>
                        </tr> 
                        <tr class="hidetopic"><td colspan="2">
                              <h4><?php echo esc_html__("Content Parameters", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the language of the created content. This will set the value of the %%language%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Content Language:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="content_language1a" name="content_language" type="text" list="languages1a" placeholder="Created content language" class="valuesai1a coderevolution_gutenberg_input" value="English"/>
<datalist id="languages1a">
<?php
foreach($aiomatic_language_names as $ln)
{
echo '<option>' . esc_html($ln) . '</option>';
}
?>
</datalist>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the writing style of the created content. This will set the value of the %%writing_style%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Writing Style:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="writing_style1a" name="writing_style" type="text" placeholder="Created content writing style" list="writing_styles1a" class="valuesai1a coderevolution_gutenberg_input" value="Creative"/>
                           <datalist id="writing_styles1a">
<option>Informative</option>
<option>Academic</option>
<option>Descriptive</option>
<option>Detailed</option>
<option>Dramative</option>
<option>Fiction</option>
<option>Expository</option>
<option>Historical</option>
<option>Dialogue</option>
<option>Creative</option>
<option>Critical</option>
<option>Narrative</option>
<option>Persuasive</option>
<option>Reflective</option>
<option>Argumentative</option>
<option>Analytical</option>
<option>Blog</option>
<option>News</option>
<option>Casual</option>
<option>Pastoral</option>
<option>Personal</option>
<option>Poetic</option>
<option>Satirical</option>
<option>Sensory</option>
<option>Articulate</option>
<option>Monologue</option>
<option>Colloquial</option>
<option>Comparative</option>
<option>Concise</option>
<option>Biographical</option>
<option>Anecdotal</option>
<option>Evaluative</option>
<option>Letter</option>
<option>Lyrical</option>
<option>Simple</option>
<option>Vivid</option>
<option>Journalistic</option>
<option>Technical</option>
<option>Direct</option>
<option>Emotional</option>
<option>Metaphorical</option>
<option>Objective</option>
<option>Rhetorical</option>
<option>Theoretical</option>
<option>Business</option>
<option>Report</option>
<option>Research</option>
</datalist>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the writing tone of the created content. This will set the value of the %%writing_tone%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Writing Tone:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="writing_tone1a" name="writing_tone" type="text" list="writing_tones1a" placeholder="Created content writing tone" class="valuesai1a coderevolution_gutenberg_input" value="Neutral"/>
                           <datalist id="writing_tones1a">
<option>Neutral</option>
<option>Formal</option>
<option>Assertive</option>
<option>Cheerful</option>
<option>Humorous</option>
<option>Informal</option>
<option>Inspirational</option>
<option>Professional</option>
<option>Emotional</option>
<option>Persuasive</option>
<option>Supportive</option>
<option>Sarcastic</option>
<option>Condescending</option>
<option>Skeptical</option>
<option>Narrative</option>
<option>Journalistic</option>
<option>Conversational</option>
<option>Factual</option>
<option>Friendly</option>
<option>Polite</option>
<option>Scientific</option>
<option>Sensitive</option>
<option>Sincere</option>
<option>Curious</option>
<option>Dissapointed</option>
<option>Encouraging</option>
<option>Optimistic</option>
<option>Surprised</option>
<option>Worried</option>
<option>Confident</option>
<option>Authoritative</option>
<option>Nostalgic</option>
<option>Sympathetic</option>
<option>Suspenseful</option>
<option>Romantic</option>
<option>Serious</option>
</datalist>
                           </td>
                        </tr>
                        <tr class="hidetopic"><td colspan="2">
                              <h4><?php echo esc_html__("Prompts", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Post Title. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Title Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="title_prompt" id="title_prompt1a" placeholder="Enter your title prompts, one per line" class="valuesai1a cr_width_full">Write a title for an article about "%%topic%%" in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. Must be between 40 and 60 characters.</textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the title generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Title Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_title_model1a" name="topic_title_model" class="hideAssistant1a valuesai1a cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the intro of the article. You can use the following shortcodes: %%title%%, %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Intro Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="intro_prompt" id="intro_prompt1a" placeholder="Enter your intro prompts, one per line" class="valuesai1a cr_width_full">Craft an introduction for an article about "%%title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%.</textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the intro generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Intro Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_intro_model1a" name="topic_intro_model" class="hideAssistant1a valuesai1a cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Sections of the article. These will be set also as headings in the article. You can use the following shortcodes: %%title%%, %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Sections Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="sections_prompt" id="sections_prompt1a" placeholder="Enter your sections prompts, one per line" class="valuesai1a cr_width_full">Write %%sections_count%% consecutive headings for an article about "%%title%%" that highlight specific aspects, provide detailed insights and specific recommendations. The headings must be written in %%language%%, following a %%writing_style%% style and a %%writing_tone%% tone. Don't add numbers to the headings, hyphens or any types of quotes. Return only the headings list, nothing else.</textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the sections generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Sections Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_sections_model1a" name="topic_sections_model" class="hideAssistant1a valuesai1a cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Content of the article, which will be applied to each section heading generated by the plugin (or entered manually) or to the entire content (depending how you select using the 'Use the Above Content Prompt To Create The Entire Article' checkbox). You can use the following shortcodes: %%title%%, %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections%%, %%current_section%%, %%paragraphs_per_section%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Content Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="3" cols="70" name="content_prompt" id="content_prompt1a" placeholder="Enter your content prompt" class="valuesai1a cr_width_full">Write the content of a post section for the heading "%%current_section%%" in %%language%%. The title of the post is: "%%title%%". Don't add the title at the beginning of the created content. Be creative and unique. Don't repeat the heading in the created content. Don't add an intro or outro. Write %%paragraphs_per_section%% paragraphs in the section. Use HTML for formatting, include unnumbered lists and bold. If needed, you can use WordPress related CSS styling for the article. When applicable, add also HTML tables with WordPress styling (you can use WordPress table classes). If added, table data must be relevant, creative, short and simple. Writing Style: %%writing_style%%. Tone: %%writing_tone%%.</textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the content generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Content Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_content_model1a" name="topic_content_model" class="hideAssistant1a valuesai1a cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to use the above content prompt to create the entire article from a single API call (checkbox checked) or to run the prompt for each section separately (checkbox unchecked). If you check this, be sure to modify the content prompt accordingly.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Use the Above Content Prompt To Create The Entire Article (Not Each Section):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="single_content_call-11a" name="single_content_call" onclick="hideTOC(-1);" class="valuesai1a">
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Q&A of the article. You can use the following shortcodes: %%title%%, %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Q&A Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="qa_prompt" id="qa_prompt1a" placeholder="Enter your Q&A prompts, one per line" class="valuesai1a cr_width_full">Write a Q&A for an article about "%%title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%.</textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the Q&A generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Q&A Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_qa_model1a" name="topic_qa_model" class="hideAssistant1a valuesai1a cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the outro of the article. You can use the following shortcodes: %%title%%, %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Outro Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="outro_prompt" id="outro_prompt1a" placeholder="Enter your outro prompts, one per line" class="valuesai1a cr_width_full">Write an outro for an article about "%%title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%.</textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the outro generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Outro Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_outro_model1a" name="topic_outro_model" class="hideAssistant1a valuesai1a cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the excerpt of the article. You can use the following shortcodes: %%title%%, %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Excerpt Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="excerpt_prompt" id="excerpt_prompt1a" placeholder="Enter your excerpt prompts, one per line" class="valuesai1a cr_width_full">Write a short excerpt for an article about "%%title%%" in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. Must be between 150 and 250 characters.</textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the excerpt generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Excerpt Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_excerpt_model1a" name="topic_excerpt_model" class="hideAssistant1a valuesai1a cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetopic"><td colspan="2">
                              <h4><?php echo esc_html__("Advanced Prompting Options", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Run regex on prompts. To disable this feature, leave this field blank. No Regex separators are required here. You can add multiple Regex expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Regex On Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="strip_by_regex_prompts" id="strip_by_regex_prompts1a" placeholder="regex expression" class="valuesai1a cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Replace the above regex matches with this regex expression. If you want to strip matched content, leave this field blank. No Regex separators are required here. You can add multiple replacement expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Replace Matches From Regex (Prompts):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="replace_regex_prompts" id="replace_regex_prompts1a" placeholder="regex replacement" class="valuesai1a cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select on which prompts do you want to run the above Regex. Possible values are (or any of their combinations): title, intro, sections, content, outro, excerpt", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Above Regex On Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="run_regex_on1a" name="run_regex_on" type="text" list="run_regex_on_list1a" class="valuesai1a coderevolution_gutenberg_input" value="content"/>
<datalist id="run_regex_on_list1a">
<option value="title">title</option>
<option value="intro">intro</option>
<option value="sections">sections</option>
<option value="content">content</option>
<option value="qa">Q&A</option>
<option value="outro">outro</option>
<option value="excerpt">excerpt</option>
</datalist> 
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Global Prompt Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This will be prepended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Prepend Text To All Textual AI Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="global_prepend" id="global_prepend1a" placeholder="Global prompt prepend text" class="valuesai1a cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr class="hidetopic">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This will be appended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Append Text To All Textual AI Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="global_append" id="global_append1a" placeholder="Global prompt append text" class="valuesai1a cr_width_full"></textarea>
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Automatic Linking Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the linking method to use in posts.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Automatic Linking Type:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" class="valuesai1a cr_width_full" id="link_type1a" onchange="hideLinks('');" name="link_type">
                           <option value="disabled" selected><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="internal"><?php echo esc_html__("Internal Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="manual"><?php echo esc_html__("Manual Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="serp"><?php echo esc_html__("Related SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="mixed"><?php echo esc_html__("Internal + Manual Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="intserp"><?php echo esc_html__("Internal & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="manserp"><?php echo esc_html__("Manual & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="intmanserp"><?php echo esc_html__("Internal & Manual & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of automatic links to add to created posts. You can also define custom ranges, like: 3-5. Please note that this feature will work best if you already have a considerable number of posts published on your site, which will be used for internal linking.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Number Of Automatic Links To Add To The Post Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="max_links" id="max_links1a" placeholder="3-5" class="valuesai1a cr_width_full">
                           </td>
                        </tr>
                        <tr class="hidelinks">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a manual list of links, where the plugin will create links.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Manual List Of URLs (One Per Line):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" cols="70" name="link_list" id="link_list1a" placeholder="URL list (one per line)" class="valuesai1a cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr class="hidelinks">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to add nofollow attribute to manually entered, external links?", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Nofollow Attribute To External Links:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="link_nofollow1a" name="link_nofollow" class="valuesai1a">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the post types where to create automatic links in posts. You can also add a comma separated list of multiple post types.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Post Types Where To Generate Automatic Links:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="link_post_types" id="link_post_types1a" placeholder="post" class="valuesai1a cr_width_full">
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Advanced AI Text Generator Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. Note that in this value the number of tokens sent to the API as an article prompt will also be counted. The maximum amount which can be set is 4000. For other models, the maximum is 2048.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Total Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_tokens" id="max_tokens1a" value="" placeholder="32768" class="valuesai1a cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of prompt API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. This defines how much content does the API receive each time you call it. If the API gets more initial data, better quality results will be expected. The maximum amount which can be set is 1000.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Prompt Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_seed_tokens" id="max_seed_tokens1a" value="" placeholder="1000" class="valuesai1a cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("What sampling temperature to use. Higher values means the model will take more risks. Try 0.9 for more creative applications, and 0 (argmax sampling) for ones with a well-defined answer. We generally recommend altering this or top_p but not both.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Temperature:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" step="0.01" max="2" name="temperature" id="temperature1a" value="" placeholder="1" class="valuesai1a cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("An alternative to sampling with temperature, called nucleus sampling, where the model considers the results of the tokens with top_p probability mass. So 0.1 means only the tokens comprising the top 10% probability mass are considered. We generally recommend altering this or temperature but not both.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Top_p:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" max="1" step="0.01" name="top_p" id="top_p1a" value="" placeholder="1" class="valuesai1a cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on whether they appear in the text so far, increasing the model's likelihood to talk about new topics.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Presence Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="-2" step="0.01" max="2" name="presence_penalty" id="presence_penalty1a" value="" placeholder="0" class="valuesai1a cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on their existing frequency in the text so far, decreasing the model's likelihood to repeat the same line verbatim.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Frequency Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" max="2" step="0.01" name="frequency_penalty" id="frequency_penalty1a" value="" placeholder="0" class="valuesai1a cr_width_full">
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Image Generator Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the search query repetition mode, when searching royalty free images.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Search Query Repetition:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="search_query_repetition1a" name="search_query_repetition" class="valuesai1a cr_width_full">
                              <option value="0" selected><?php echo esc_html__("Use Different Search Queries For Images", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1"><?php echo esc_html__("Use The Same Search Query For Images", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to enable the AI Image Generator and to replace Royalty Free Images with AI generated images?", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Image Source:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="enable_ai_images1a" onchange="hideImage('1a');" name="enable_ai_images" class="valuesai1a cr_width_full">
                              <option value="0" selected><?php echo esc_html__("Royalty Free", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1"><?php echo esc_html__("OpenAI/AiomaticAPI", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              if (isset($aiomatic_Main_Settings['stability_app_id']) && trim($aiomatic_Main_Settings['stability_app_id']) != '')
                              {
                              ?>
                              <option value="2"><?php echo esc_html__("Stability.AI", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['midjourney_app_id']) && trim($aiomatic_Main_Settings['midjourney_app_id']) != '')
                              {
                              ?>
                              <option value="4"><?php echo esc_html__("Midjourney", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['replicate_app_id']) && trim($aiomatic_Main_Settings['replicate_app_id']) != '')
                              {
                              ?>
                              <option value="5"><?php echo esc_html__("Replicate", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['ideogram_app_id']) && trim($aiomatic_Main_Settings['ideogram_app_id']) != '')
                              {
                              ?>
                              <option value="6"><?php echo esc_html__("Ideogram", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['cloudflare_worker_url']) && trim($aiomatic_Main_Settings['cloudflare_worker_url']) != '' && isset($aiomatic_Main_Settings['cloudflare_worker_secret']) && trim($aiomatic_Main_Settings['cloudflare_worker_secret']) != '')
                              {
                              ?>
                              <option value="8"><?php echo esc_html__("Cloudflare Workers", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['app_id_google']) && trim($aiomatic_Main_Settings['app_id_google']) != '')
                              {
                              ?>
                              <option value="7"><?php echo esc_html__("Google", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              ?>
                              <option value="9"><?php echo esc_html__("Random From Media Library", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
                           </td>
                        </tr>
                        <tr class="hideImg1a cr_none">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set list of prompt commands (one on each line) you want to send to the AI image generator. This command can be any given task or order, based on which, it will generate images. You can use the following shortcodes: %%post_title%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%. The length of this command should not be greater than 1000 characters (4000 characters for Dall-E 3), otherwise the plugin will strip it to 1000 characters length. - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You can also add here a link to a .txt file, where you can add multiple prompts (one per line) and the plugin will select a random one at each run. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          echo '&nbsp;' . sprintf( wp_kses( __( "Please check some tips and tricks about writing prompt commands, <a href='%s' target='_blank'>here</a>. The [aicontent] shortcode is able to be used also here.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-image-generating-for-openai-dall-e-api/' );
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Prompt For The AI Image Generator:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-image-generating-for-openai-dall-e-api/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="ai_command_image" id="ai_command_image1a" placeholder="Please insert a command for the AI image generator" class="valuesai1a cr_width_full">Generate a high-resolution, visually compelling image that creatively interprets the theme encapsulated by this post title: "%%post_title%%". The image should be versatile enough to fit various niches, from technology and lifestyle to nature and science. It should feature a central, eye-catching element that abstractly represents the topic, surrounded by relevant, subtler motifs that provide context and depth. The composition should be balanced and aesthetically pleasing, with a harmonious color palette that complements the mood of the title. The artwork should be suitable for use as a captivating header image for a blog post.</textarea>
                           </td>
                        </tr>
                        <tr class="hideDalle1a cr_none">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI model you wish to use for image the image generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Image Model:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="image_model1a" name="image_model" class="valuesai1a cr_width_full">
<?php
foreach(AIMOGEN_DALLE_IMAGE_MODELS as $modelx)
{
   echo '<option value="' . esc_html($modelx) .'"';
   if ($modelx == AIMOGEN_DEFAULT_IMAGE_MODEL) { echo ' selected'; }
   echo '>' . esc_html($modelx) . '</option>';
}
?>
                           </select>
                           </td>
                        </tr>
                        <tr class="hideImg1a cr_none">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the size of the generated image.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Generated Image Size:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="model1a" name="image_size" class="cr_width_full valuesai1a">
                              <option value="256x256"><?php echo esc_html__("256x256", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="512x512"><?php echo esc_html__("512x512", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1024x1024" selected><?php echo esc_html__("1024x1024", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>  
                           </td>
                        </tr>
                        <tr><td colspan="2">
                              <h3><?php echo esc_html__("Posting Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a HTML text that should be prepended to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%random_sentence%%, %%random_sentence2%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("HTML Text To Prepend To AI Created Content:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_prepend" id="post_prepend1a" placeholder="HTML content to prepend to the AI generated content" class="cr_width_full valuesai1a"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a HTML text that should be appended to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%random_sentence%%, %%random_sentence2%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("HTML Text To Append To AI Created Content:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_append" id="post_append1a" placeholder="HTML content to append to the AI generated content" class="cr_width_full valuesai1a"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Custom AI generated content shortcode creator. If you wish to create content from multiple AI prompts, and use them in post content/post custom fields/taxonomies, you can configure this from here. Also, these shortcodes will be able to be used in custom fields or custom taxonomies which the plugin will create. Syntax for this field: shortcode_name => AI_MODEL_TO_USE @@ TEXTUAL_PROMPT_TO_USE (to specify multiple shortcodes and crawling values, separate them by a new line. Example: my_custom_shortcode => gpt-5-mini @@ Write a short poem. Afterwards, you can use shortcodes in any settings field that supports shortcodes (ex: 'HTML Text To Append To AI Created Content' settings field), like this: %%my_custom_shortcode%%. Official format is %%name_of_custom_shortcode%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Custom Shortcode Creator (Optional):", 'aiomatic-automatic-ai-content-writer');?></b><span class="tool" data-tip="Supported models: <?php echo esc_html(implode(',', aiomatic_get_all_models()));?>">&nbsp;&#9432;</span>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="custom_shortcodes" id="custom_shortcodes1a" placeholder="shortcode_name => AI_MODEL @@ AI_PROMPT" class="valuesai1a cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("The AI writer might add the title of the post to the created post content. Check this checkbox if you want to remove the title from the post content.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Strip Title From Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="strip_title1a" name="strip_title" class="valuesai1a">
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip spinning of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Do Not Spin Posts Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="skip_spin1a" name="skip_spin" class="valuesai1a">               
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip translating of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Do Not Translate Posts Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="skip_translate1a" name="skip_translate" class="valuesai1a">               
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Run regex on post content. To disable this feature, leave this field blank. No Regex separators are required here. You can add multiple Regex expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Regex On Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" class="valuesai1a cr_width_full" name="strip_by_regex" id="strip_by_regex1a" placeholder="regex expression"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Replace the above regex matches with this regex expression. If you want to strip matched content, leave this field blank. No Regex separators are required here. You can add multiple replacement expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Replace Matches From Regex (Content):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" class="valuesai1a cr_width_full" name="replace_regex" id="replace_regex1a" placeholder="regex replacement"></textarea>
                           </td>
                        </tr>
                     </table>
                  </div>
               </div>
               <div class="codemodalfzr-footer">
                  <br/>
                  <h3 class="cr_inline">Aimogen Automatic Post Generator</h3>
                  <span id="aiomatic_ok1a" class="codeokfzr cr_inline">OK&nbsp;</span>
                  <br/><br/>
               </div>
            </div>
         </div>
   <div id="mymodalfzr1b" class="codemodalfzr">
            <div class="codemodalfzr-content">
               <div class="codemodalfzr-header">
                  <span id="aiomatic_close1b" class="codeclosefzr">&times;</span>
                  <h2><span class="cr_color_white"><?php echo esc_html__("Title Based", 'aiomatic-automatic-ai-content-writer');?></span> <?php echo esc_html__("Advanced Settings", 'aiomatic-automatic-ai-content-writer');?></h2>
               </div>
               <div class="codemodalfzr-body">
                  <div class="table-responsive">
                     <table class="responsive table cr_main_table_nowr">
                     <tr><td colspan="2">
                           <h3><?php echo esc_html__("AI Assistant Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                     </td></tr>
                     <tr>
                        <td class="cr_min_width_200">
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("Select the AI Assistant to use for content creation. This will disable the ability to select AI models, as the models assisgned to the assistant will be used for content creation.", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                              <b><?php echo esc_html__("AI Assistant Name:", 'aiomatic-automatic-ai-content-writer');?></b>
                        </td>
                        <td><select id="assistant_id1b" name="assistant_id" class="valuesai1b cr_width_full" onchange="assistantSelected('1b');">
<?php
if($all_assistants === false)
{
echo '<option val="" selected disabled>' . esc_html__("Only OpenAI API is supported for Assistants API", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
if(count($all_assistants) == 0)
{
echo '<option val="" selected disabled>' . esc_html__("No Assistans added, go to the plugin's 'AI Assistans' menu to add new assistants!", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
echo '<option value="" selected';
echo '>' . esc_html__("Don't use assistants, use AI models instead", 'aiomatic-automatic-ai-content-writer') . '</option>';
foreach($all_assistants as $myassistant)
{
echo '<option value="' . esc_html($myassistant->ID) .'"';
echo '>' . esc_html($myassistant->post_title);
echo '</option>';
}
}
}
?>
</select>  
                        </td>
                     </tr>
                        <tr class="hidetitle"><td colspan="2">
                              <h3><?php echo esc_html__("Title Based Posting Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                     <tr class="hidetitle"><td colspan="2">
                              <h4><?php echo esc_html__("Post Content - AI Text Generator Options", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr class="hidetitle">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for text generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Text Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="model1b" name="model" class="hideAssistant1b valuesai1b cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetitle">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set list of prompt commands (one on each line) you want to send to OpenAI/AiomaticAPI. This command can be any given task or order, based on which, it will generate content for posts. You can use the following shortcodes here: %%post_title%%, %%random_sentence%%, %%post_original_title%%, %%random_sentence2%%, %%blog_title%%. You can also add a link to a TXT file, containing keywords (one per line), or to an RSS feed. If you use RSS feeds, you can also use the following additional shortcodes: %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%author_name%%, %%current_date_time%%, %%post_link%%. The length of this command should not be greater than the max token count set in the settings for the prompt command - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You can also add here a link to a .txt file, where you can add multiple prompts (one per line) and the plugin will select a random one at each run. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          echo '&nbsp;' . sprintf( wp_kses( __( "Please check some tips and tricks about writing prompt commands, <a href='%s' target='_blank'>here</a>.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-for-openai-gpt-3-api/' );
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Prompt For The AI Text Generator:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-for-openai-gpt-3-api/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="ai_command" id="ai_command1b" placeholder="Please insert a command for the AI" class="valuesai1b cr_width_full">Write a comprehensive and SEO-optimized article on the topic of "%%post_title%%". Incorporate relevant keywords naturally throughout the article to enhance search engine visibility. This article must provide valuable information to readers and be well-structured with proper headings, bullet points, and HTML formatting. If needed, you can use WordPress related CSS styling for the article. When applicable, add also HTML tables with WordPress styling (you can use WordPress table classes). If added, table data must be relevant, creative, short and simple. 

Add an introductory and a conclusion section to the article. You can add also some other sections, when they fit the article's subject, like: benefits and practical tips, case studies, first had experience.

Please ensure that the article is at least 1200 words in length and adheres to best SEO practices, including proper header tags (H1, H2, H3). The article will be automatically published on my WordPress site, as a post. 

Feel free to use a friendly, conversational tone and make the article as informative and engaging as possible while ensuring it remains factually accurate and well-researched.</textarea>
                           </td>
                        </tr>
                        <tr class="hidetitle">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo sprintf( wp_kses( __( "Select the minimum number of characters that the posts should have. If the API returns content which has fewer characters than this number, another API call will be made, until this character limit is met. Please check about API rate limiting <a href='%s'>here</a>.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://beta.openai.com/docs/api-reference/introduction' );
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Content Minimum Character Count:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" step="1" name="min_char" id="min_char1b" value="500" placeholder="Please insert a minimum number of characters for posts" class="valuesai1b cr_width_full">
                           </td>
                        </tr>
                        <tr class="hidetitle"><td colspan="2">
                              <h4><?php echo esc_html__("Post Title - AI Text Generator Options (%%ai_generated_title%% shortcode)", 'aiomatic-automatic-ai-content-writer');?>:<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("The %%ai_generated_title%% shortcode can be used in the 'Post Title List / TXT File URL / RSS Feed URL' settings field, to get partial or fully AI generated titles.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div></h4>
                        </td></tr>
                        <tr class="hidetitle">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for title text generator. You can add this to the post titles, using the %%ai_generated_title%% shortcode.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Title Text Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="title_model1b" name="title_model" class="hideAssistant1b valuesai1b cr_width_full">
                           <?php
                                 foreach($all_models as $modelx)
                                 {
                                    echo '<option value="' . esc_html($modelx) .'"';
                                    echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
                                 }
                                 ?>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetitle">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set list of prompt commands (one on each line) you want to send to AI for generating post titles. This command can be any given task or order, based on which, it will generate content for posts. You can use the following shortcodes here: %%post_title%%, %%random_sentence%%, %%post_original_title%%, %%random_sentence2%%, %%blog_title%%. You can also add a link to a TXT file, containing keywords (one per line), or to an RSS feed. If you use RSS feeds, you can also use the following additional shortcodes: %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%author_name%%, %%current_date_time%%, %%post_link%%. The length of this command should not be greater than the max token count set in the settings for the prompt command - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You can also add here a link to a .txt file, where you can add multiple prompts (one per line) and the plugin will select a random one at each run. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          echo '&nbsp;' . sprintf( wp_kses( __( "Please check some tips and tricks about writing prompt commands, <a href='%s' target='_blank'>here</a>.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-for-openai-gpt-3-api/' );
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Prompt For The AI Title Text Generator:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-for-openai-gpt-3-api/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="title_ai_command" id="title_ai_command1b" placeholder="Please insert a command for the AI" class="valuesai1b cr_width_full">Craft an attention-grabbing and SEO-optimized article title for a dental health blog. This title must be concise, informative, and designed to pique the interest of readers while clearly conveying the topic of the article.</textarea>
                           </td>
                        </tr><tr class="hidetitle">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the source of the post title. If you select AI generated, the plugin will create an AI generated title based on keywords you enter in the 'Post Title List' settings field. Otherwise, it will use the titles listed there, for the created posts.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Post Title Source:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="title_source1b" name="title_source" class="valuesai1b cr_width_full">
                              <option value="keyword" selected><?php echo esc_html__("Use The Titles From The 'Post Title List' Settings Field", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="ai"><?php echo esc_html__("Fully AI Generated Titles", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr class="hidetitle"><td colspan="2">
                              <h4><?php echo esc_html__("Rich Content Creation Options", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr class="hidetitle">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of related headings to add to the created post content. This feature will use the 'People Also Ask' feature from Google and Bing. By default, the Bing engine is scraped, if you want to enable also Google scraping, add a SerpAPI key in the plugin's 'Settings' menu -> 'SerpAPI API Key' settings field.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Number Of Related Headings to Add To The Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" name="headings" id="headings1b" value="" placeholder="Max heading count" class="valuesai1b cr_width_full">
                           </td>
                        </tr>
                        <tr class="hidetitle">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for headings generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For The Headings Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="headings_model1b" name="headings_model" class="hideAssistant1b valuesai1b cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>  
                           </td>
                        </tr>
                        <tr class="hidetitle">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the prompt you will use when searching for related headings. You can use the following shortcodes: %%post_title%%, %%needed_heading_count%%. The same model will be used, as the one selected for content creation. If you leave this field blank, the default prompt will be used: 'Write %%needed_heading_count%% PAA related questions, each on a new line, for the title: %%post_title%%' You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Related Headings AI Generator Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="headings_ai_command" id="headings_ai_command1b" placeholder="Write %%needed_heading_count%% PAA related questions, each on a new line, for the title: %%post_title%%" class="valuesai1b cr_width_full">Generate %%needed_heading_count%% People Also Ask (PAA) related questions, each on a new line, that are relevant to the topic of the post title: "%%post_title%%".</textarea>
                           </td>
                        </tr>
                        <tr class="hidetitle">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of related images to add to the created post content. This feature will use the 'Royalty Free Image' settings from the plugin's 'Settings' menu or if you have access to the OpenAI API.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Number Of Related Images to Add To The Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" name="images" id="images1b" value="" placeholder="Max image count" class="valuesai1b cr_width_full">
                           </td>
                        </tr>
                        <tr class="hidetitle">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Add a related YouTube video to the end of to the created post content. This feature will require you to add at least one YouTube API key in the plugin's 'Settings' -> 'YouTube API Key List' settings field.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add A Related Video To The End Of The Post:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="videos1b" name="videos" class="valuesai1b">
                           </td>
                        </tr>
                     <tr class="hidetitle"><td colspan="2">
                              <h4><?php echo esc_html__("Manual Headings and Images List", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr class="hidetitle">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Add a list of headings (one on each line) to use in the generated articles. You can use the following shortcodes here: %%post_title%%, %%random_sentence%%, %%post_original_title%%, %%random_sentence2%%, %%blog_title%%. - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins).", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Manual List Of Headings:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="headings_list" id="headings_list1b" placeholder="List of headings" class="valuesai1b cr_width_full"></textarea>
                           </td>
                        </tr><tr class="hidetitle">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Add a list of image URLs (one on each line) to use in the generated articles. - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins).", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Manual List Of Images:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="images_list" id="images_list1b" placeholder="List of images" class="valuesai1b cr_width_full"></textarea>
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Global Prompt Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This will be prepended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Prepend Text To All Textual AI Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="global_prepend" id="global_prepend1b" placeholder="Global prompt prepend text" class="valuesai1b cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This will be appended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Append Text To All Textual AI Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="global_append" id="global_append1b" placeholder="Global prompt append text" class="valuesai1b cr_width_full"></textarea>
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Automatic Linking Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the linking method to use in posts.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Automatic Linking Type:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" class="valuesai1b cr_width_full" id="link_type1b" onchange="hideLinks('');" name="link_type">
                           <option value="disabled" selected><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="internal"><?php echo esc_html__("Internal Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="manual"><?php echo esc_html__("Manual Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="serp"><?php echo esc_html__("Related SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="mixed"><?php echo esc_html__("Internal + Manual Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="intserp"><?php echo esc_html__("Internal & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="manserp"><?php echo esc_html__("Manual & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="intmanserp"><?php echo esc_html__("Internal & Manual & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of automatic links to add to created posts. You can also define custom ranges, like: 3-5. Please note that this feature will work best if you already have a considerable number of posts published on your site, which will be used for internal linking.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Number Of Automatic Links To Add To The Post Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="max_links" id="max_links1b" placeholder="3-5" class="valuesai1b cr_width_full">
                           </td>
                        </tr>
                        <tr class="hidelinks">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a manual list of links, where the plugin will create links.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Manual List Of URLs (One Per Line):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" cols="70" name="link_list" id="link_list1b" placeholder="URL list (one per line)" class="valuesai1b cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr class="hidelinks">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to add nofollow attribute to manually entered, external links?", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Nofollow Attribute To External Links:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="link_nofollow1b" name="link_nofollow" class="valuesai1b">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the post types where to create automatic links in posts. You can also add a comma separated list of multiple post types.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Post Types Where To Generate Automatic Links:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="link_post_types" id="link_post_types1b" placeholder="post" class="valuesai1b cr_width_full">
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Advanced AI Text Generator Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. Note that in this value the number of tokens sent to the API as an article prompt will also be counted. The maximum amount which can be set is 4000. For other models, the maximum is 2048.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Total Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_tokens" id="max_tokens1b" value="" placeholder="32768" class="valuesai1b cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of prompt API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. This defines how much content does the API receive each time you call it. If the API gets more initial data, better quality results will be expected. The maximum amount which can be set is 1000.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Prompt Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_seed_tokens" id="max_seed_tokens1b" value="" placeholder="1000" class="valuesai1b cr_width_full">
                           </td>
                        </tr>
                        <tr class="hidetitle">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of continue API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. This defines how much content does the API receive each time you call it. If the API gets more initial data, better quality results will be expected. The maximum amount which can be set is 500.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Continue Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_continue_tokens" id="max_continue_tokens1b" value="" placeholder="500" class="valuesai1b cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("What sampling temperature to use. Higher values means the model will take more risks. Try 0.9 for more creative applications, and 0 (argmax sampling) for ones with a well-defined answer. We generally recommend altering this or top_p but not both.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Temperature:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" step="0.01" max="2" name="temperature" id="temperature1b" value="" placeholder="1" class="valuesai1b cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("An alternative to sampling with temperature, called nucleus sampling, where the model considers the results of the tokens with top_p probability mass. So 0.1 means only the tokens comprising the top 10% probability mass are considered. We generally recommend altering this or temperature but not both.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Top_p:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" max="1" step="0.01" name="top_p" id="top_p1b" value="" placeholder="1" class="valuesai1b cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on whether they appear in the text so far, increasing the model's likelihood to talk about new topics.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Presence Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="-2" step="0.01" max="2" name="presence_penalty" id="presence_penalty1b" value="" placeholder="0" class="valuesai1b cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on their existing frequency in the text so far, decreasing the model's likelihood to repeat the same line verbatim.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Frequency Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" max="2" step="0.01" name="frequency_penalty" id="frequency_penalty1b" value="" placeholder="0" class="valuesai1b cr_width_full">
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Image Generator Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the search query repetition mode, when searching royalty free images.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Search Query Repetition:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="search_query_repetition1b" name="search_query_repetition" class="valuesai1b cr_width_full">
                              <option value="0" selected><?php echo esc_html__("Use Different Search Queries For Images", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1"><?php echo esc_html__("Use The Same Search Query For Images", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to enable the AI Image Generator and to replace Royalty Free Images with AI generated images?", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Image Source:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="enable_ai_images1b" onchange="hideImage('1b');" name="enable_ai_images" class="valuesai1b cr_width_full">
                              <option value="0" selected><?php echo esc_html__("Royalty Free", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1"><?php echo esc_html__("OpenAI/AiomaticAPI", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              if (isset($aiomatic_Main_Settings['stability_app_id']) && trim($aiomatic_Main_Settings['stability_app_id']) != '')
                              {
                              ?>
                              <option value="2"><?php echo esc_html__("Stability.AI", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['midjourney_app_id']) && trim($aiomatic_Main_Settings['midjourney_app_id']) != '')
                              {
                              ?>
                              <option value="4"><?php echo esc_html__("Midjourney", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['replicate_app_id']) && trim($aiomatic_Main_Settings['replicate_app_id']) != '')
                              {
                              ?>
                              <option value="5"><?php echo esc_html__("Replicate", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['ideogram_app_id']) && trim($aiomatic_Main_Settings['ideogram_app_id']) != '')
                              {
                              ?>
                              <option value="6"><?php echo esc_html__("Ideogram", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['cloudflare_worker_url']) && trim($aiomatic_Main_Settings['cloudflare_worker_url']) != '' && isset($aiomatic_Main_Settings['cloudflare_worker_secret']) && trim($aiomatic_Main_Settings['cloudflare_worker_secret']) != '')
                              {
                              ?>
                              <option value="8"><?php echo esc_html__("Cloudflare Workers", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['app_id_google']) && trim($aiomatic_Main_Settings['app_id_google']) != '')
                              {
                              ?>
                              <option value="7"><?php echo esc_html__("Google", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              ?>
                              <option value="9"><?php echo esc_html__("Random From Media Library", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
                           </td>
                        </tr>
                        <tr class="hideImg1b cr_none">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set list of prompt commands (one on each line) you want to send to the AI image generator. This command can be any given task or order, based on which, it will generate images. You can use the following shortcodes: %%post_title%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%. The length of this command should not be greater than 1000 characters (4000 characters for Dall-E 3), otherwise the plugin will strip it to 1000 characters length. - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You can also add here a link to a .txt file, where you can add multiple prompts (one per line) and the plugin will select a random one at each run. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          echo '&nbsp;' . sprintf( wp_kses( __( "Please check some tips and tricks about writing prompt commands, <a href='%s' target='_blank'>here</a>. The [aicontent] shortcode is able to be used also here.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-image-generating-for-openai-dall-e-api/' );
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Prompt For The AI Image Generator:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-image-generating-for-openai-dall-e-api/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="ai_command_image" id="ai_command_image1b" placeholder="Please insert a command for the AI image generator" class="valuesai1b cr_width_full">Generate a high-resolution, visually compelling image that creatively interprets the theme encapsulated by this post title: "%%post_title%%". The image should be versatile enough to fit various niches, from technology and lifestyle to nature and science. It should feature a central, eye-catching element that abstractly represents the topic, surrounded by relevant, subtler motifs that provide context and depth. The composition should be balanced and aesthetically pleasing, with a harmonious color palette that complements the mood of the title. The artwork should be suitable for use as a captivating header image for a blog post.</textarea>
                           </td>
                        </tr>
                        <tr class="hideDalle1b cr_none">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI model you wish to use for image the image generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Image Model:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="image_model1b" name="image_model" class="valuesai1b cr_width_full">
<?php
foreach(AIMOGEN_DALLE_IMAGE_MODELS as $modelx)
{
   echo '<option value="' . esc_html($modelx) .'"';
   if ($modelx == AIMOGEN_DEFAULT_IMAGE_MODEL) { echo ' selected'; }
   echo '>' . esc_html($modelx) . '</option>';
}
?>
                           </select>
                           </td>
                        </tr>
                        <tr class="hideImg1b cr_none">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the size of the generated image.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Generated Image Size:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="image_size1b" name="image_size" class="valuesai1b cr_width_full">
                              <option value="256x256"><?php echo esc_html__("256x256", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="512x512"><?php echo esc_html__("512x512", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1024x1024" selected><?php echo esc_html__("1024x1024", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>  
                           </td>
                        </tr>
                        <tr><td colspan="2">
                              <h3><?php echo esc_html__("Posting Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a HTML text that should be prepended to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%random_sentence%%, %%random_sentence2%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("HTML Text To Prepend To AI Created Content:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_prepend" id="post_prepend1b" placeholder="HTML content to prepend to the AI generated content" class="valuesai1b cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a HTML text that should be appended to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%random_sentence%%, %%random_sentence2%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("HTML Text To Append To AI Created Content:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_append" id="post_append1b" placeholder="HTML content to append to the AI generated content" class="valuesai1b cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Custom AI generated content shortcode creator. If you wish to create content from multiple AI prompts, and use them in post content/post custom fields/taxonomies, you can configure this from here. Also, these shortcodes will be able to be used in custom fields or custom taxonomies which the plugin will create. Syntax for this field: shortcode_name => AI_MODEL_TO_USE @@ TEXTUAL_PROMPT_TO_USE (to specify multiple shortcodes and crawling values, separate them by a new line. Example: my_custom_shortcode => gpt-5-mini @@ Write a short poem. Afterwards, you can use shortcodes in any settings field that supports shortcodes (ex: 'HTML Text To Append To AI Created Content' settings field), like this: %%my_custom_shortcode%%. Official format is %%name_of_custom_shortcode%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Custom Shortcode Creator (Optional):", 'aiomatic-automatic-ai-content-writer');?></b><span class="tool" data-tip="Supported models: <?php echo esc_html(implode(',', aiomatic_get_all_models()));?>">&nbsp;&#9432;</span>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="custom_shortcodes" id="custom_shortcodes1b" placeholder="shortcode_name => AI_MODEL @@ AI_PROMPT" class="valuesai1b cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("The AI writer might add the title of the post to the created post content. Check this checkbox if you want to remove the title from the post content.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Strip Title From Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="strip_title1b" name="strip_title" class="valuesai1b">
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip spinning of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Do Not Spin Posts Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="skip_spin1b" name="skip_spin" class="valuesai1b">               
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip translating of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Do Not Translate Posts Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="skip_translate1b" name="skip_translate" class="valuesai1b">               
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Run regex on post content. To disable this feature, leave this field blank. No Regex separators are required here. You can add multiple Regex expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Regex On Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="strip_by_regex" id="strip_by_regex1b" placeholder="regex expression" class="valuesai1b cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Replace the above regex matches with this regex expression. If you want to strip matched content, leave this field blank. No Regex separators are required here. You can add multiple replacement expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Replace Matches From Regex (Content):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="replace_regex" id="replace_regex1b" placeholder="regex replacement" class="valuesai1b cr_width_full"></textarea>
                           </td>
                        </tr>
                     </table>
                  </div>
               </div>
               <div class="codemodalfzr-footer">
                  <br/>
                  <h3 class="cr_inline">Aimogen Automatic Post Generator</h3>
                  <span id="aiomatic_ok1b" class="codeokfzr cr_inline">OK&nbsp;</span>
                  <br/><br/>
               </div>
            </div>
         </div>


   <div id="mymodalfzr2" class="codemodalfzr">
            <div class="codemodalfzr-content">
               <div class="codemodalfzr-header">
                  <span id="aiomatic_close2" class="codeclosefzr">&times;</span>
                  <h2><span class="cr_color_white"><?php echo esc_html__("YouTube Video To Post", 'aiomatic-automatic-ai-content-writer');?></span> <?php echo esc_html__("Advanced Settings", 'aiomatic-automatic-ai-content-writer');?></h2>
               </div>
               <div class="codemodalfzr-body">
                  <div class="table-responsive">
                     <table class="responsive table cr_main_table_nowr">
                     <tr><td colspan="2">
                           <h3><?php echo esc_html__("AI Assistant Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                     </td></tr>
                     <tr>
                        <td class="cr_min_width_200">
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("Select the AI Assistant to use for content creation. This will disable the ability to select AI models, as the models assisgned to the assistant will be used for content creation.", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                              <b><?php echo esc_html__("AI Assistant Name:", 'aiomatic-automatic-ai-content-writer');?></b>
                        </td>
                        <td><select id="assistant_id2" name="assistant_id" class="valuesai2 cr_width_full" onchange="assistantSelected('2');">
<?php
if($all_assistants === false)
{
echo '<option val="" selected disabled>' . esc_html__("Only OpenAI API is supported for Assistants API", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
if(count($all_assistants) == 0)
{
echo '<option val="" selected disabled>' . esc_html__("No Assistans added, go to the plugin's 'AI Assistans' menu to add new assistants!", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
echo '<option value="" selected';
echo '>' . esc_html__("Don't use assistants, use AI models instead", 'aiomatic-automatic-ai-content-writer') . '</option>';
foreach($all_assistants as $myassistant)
{
echo '<option value="' . esc_html($myassistant->ID) .'"';
echo '>' . esc_html($myassistant->post_title);
echo '</option>';
}
}
}
?>
</select>  
                        </td>
                     </tr>
                        <tr><td colspan="2">
                              <h3><?php echo esc_html__("YouTube Video Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Input a comma separated list of video captions prefered languages to use for the %%video_caption%% shortcode. Please use a comma separated list of 2 character language codes. Ex: en,es,hu,br. The plugin will use the fisrt language in the list that matches. If you leave this field blank, the default language caption will be imported for each video.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Video Caption Preferred Languages:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="default_lang" id="default_lang2" value="" placeholder="Please insert a language list for video captions" class="valuesai2 cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum length of captions in prompts. This is useful to have, when captions can be very long.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Video Caption Maximum Character Length In Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" name="max_caption" id="max_caption2" value="3000" placeholder="Caption maximum length" class="valuesai2 cr_width_full">  
                           </td>
                        </tr>
                        <tr><td colspan="2">
                              <h3><?php echo esc_html__("Posting Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to use AI generated titles for the posts created by the plugin. If not, the YouTube video title will be used.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Use AI Generated Post Titles:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="ai_titles2" name="ai_titles" class="valuesai2">
                           </td>
                        </tr> 
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a list of post sections, one per line. These will be headings of the content. These can also be automatically generated by the plugin. To enable auto generating of sections, leave this field blank. This will set the value of the %%sections%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. If you set a section list here, each created article will have this same list of sections, because of this, use shortcodes or Spintax when defining these static topics or leave this field blank for the plugin to auto generate them!", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Post Sections List (Optional):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_sections_list" id="post_sections_list2" placeholder="Post sections list (one per line)" class="valuesai2 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter the number of sections to create in the article. These will also be set as article headings. You can also set value ranges, example: 5-7. In this case, a random number will be selected in this range. Please use only numeric values in this field. This field will set the value of the %%sections_count%% shortcode.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Number Of Content Sections To Generate:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <input type="text" id="section_count2" name="section_count" placeholder="3-4" class="valuesai2 cr_width_full" value="3-4">  
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select what you want to do with sections in articles.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Sections To Content As:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" class="valuesai2 cr_width_full" id="sections_role2" name="sections_role">
                           <option value="h2" selected><?php echo esc_html__("h2", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="h3"><?php echo esc_html__("h3", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="b"><?php echo esc_html__("Bold", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="i"><?php echo esc_html__("Italic", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="bi"><?php echo esc_html__("Bold and Italic", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="p"><?php echo esc_html__("Paragraph", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="x"><?php echo esc_html__("Plain Text", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="no"><?php echo esc_html__("Don't Add Sections", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter the number of paragraphs to create for each section. These will also be set as article headings. You can also set value ranges, example: 5-7. In this case, a random number will be selected in this range. Please use only numeric values in this field. This field will set the value of the %%paragraphs_per_section%% shortcode.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Number Of Paragraphs Per Section:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <input type="text" id="paragraph_count2" name="paragraph_count" placeholder="2-3" class="valuesai2 cr_width_full" value="2">  
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the number of related images to add to the created post content. This feature will use the royalty free image sources configured in the plugin's 'Settings' menu or if you have access to the OpenAI API. You can change image source in the 'AI Image Source' settings field from below. The maximum number of images you can add to each article: number of sections + 2", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Number of Images To Add To The Article:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="topic_images" id="topic_images2" value="" placeholder="Number of images" class="valuesai2 cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add an image to each of the creating headings from the article.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add An Image To Each Heading Of The Article:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="img_all_headings2" name="img_all_headings" class="valuesai2" checked>
                           </td>
                        </tr> 
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the location of the heading images.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Heading Image Location:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="heading_img_location2" name="heading_img_location" class="valuesai2 cr_width_full">
                              <option value="top" selected><?php echo esc_html__("Top of the section", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="heading" selected><?php echo esc_html__("Under the heading text", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="bottom"><?php echo esc_html__("Bottom of the section", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="random"><?php echo esc_html__("Random (Top/Bottom)", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you would like to add the source YouTube video to the end of the created article.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add The YouTube Video To The Article:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="topic_videos2" name="topic_videos" class="valuesai2">
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the outro section header. This is optional.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Outro Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="title_outro" id="title_outro2" value="{In Conclusion|To Conclude|In Summary|To Wrap It Up|Key Takeaways|Future Outlook|Closing Remarks|The Conclusion|Final Thoughts|In Retrospect|The Way Forward|Wrapping Up|Concluding Remarks|Insights and Conclusions}" placeholder="Optional" class="valuesai2 cr_width_full">
                           </td>
                        </tr> 
                        <tr>
                           <td class="hideTOC-1">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add a Table of Contents section to the created post.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Article Table Of Contents:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td class="hideTOC-1">
                           <input type="checkbox" id="enable_toc2" name="enable_toc" class="valuesai2">
                           </td>
                        </tr> 
                        <tr>
                           <td class="hideTOC-1">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the Table of Contents section header. Default is: Table of Contents", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Table Of Contents Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td class="hideTOC-1">
                           <input type="text" name="title_toc" id="title_toc2" value="Table of Contents" placeholder="Table of Contents" class="valuesai2 cr_width_full">
                           </td>
                        </tr> 
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add a Q&A section to the created post. To enable Q&A for articles, be sure to add a prompt also in the 'Article Q&A Prompt' settings field from below.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Article Q&A Section:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="enable_qa2" name="enable_qa" class="valuesai2">
                           </td>
                        </tr> 
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the Q&A section header. Default is: Q&A", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Q&A Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="title_qa" id="title_qa2" value="Q&A" placeholder="Q&A" class="valuesai2 cr_width_full">
                           </td>
                        </tr> 
                        <tr><td colspan="2">
                              <h4><?php echo esc_html__("Content Parameters", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the language of the created content. This will set the value of the %%language%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Content Language:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="content_language2" name="content_language" type="text" list="languages2" placeholder="Created content language" class="valuesai2 coderevolution_gutenberg_input" value="English"/>
<datalist id="languages2">
<?php
foreach($aiomatic_language_names as $ln)
{
echo '<option>' . esc_html($ln) . '</option>';
}
?>
</datalist>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the writing style of the created content. This will set the value of the %%writing_style%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Writing Style:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="writing_style2" name="writing_style" type="text" placeholder="Created content writing style" list="writing_styles2" class="valuesai2 coderevolution_gutenberg_input" value="Creative"/>
                           <datalist id="writing_styles2">
<option>Informative</option>
<option>Academic</option>
<option>Descriptive</option>
<option>Detailed</option>
<option>Dramative</option>
<option>Fiction</option>
<option>Expository</option>
<option>Historical</option>
<option>Dialogue</option>
<option>Creative</option>
<option>Critical</option>
<option>Narrative</option>
<option>Persuasive</option>
<option>Reflective</option>
<option>Argumentative</option>
<option>Analytical</option>
<option>Blog</option>
<option>News</option>
<option>Casual</option>
<option>Pastoral</option>
<option>Personal</option>
<option>Poetic</option>
<option>Satirical</option>
<option>Sensory</option>
<option>Articulate</option>
<option>Monologue</option>
<option>Colloquial</option>
<option>Comparative</option>
<option>Concise</option>
<option>Biographical</option>
<option>Anecdotal</option>
<option>Evaluative</option>
<option>Letter</option>
<option>Lyrical</option>
<option>Simple</option>
<option>Vivid</option>
<option>Journalistic</option>
<option>Technical</option>
<option>Direct</option>
<option>Emotional</option>
<option>Metaphorical</option>
<option>Objective</option>
<option>Rhetorical</option>
<option>Theoretical</option>
<option>Business</option>
<option>Report</option>
<option>Research</option>
</datalist>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the writing tone of the created content. This will set the value of the %%writing_tone%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Writing Tone:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="writing_tone2" name="writing_tone" type="text" list="writing_tones3" placeholder="Created content writing tone" class="valuesai2 coderevolution_gutenberg_input" value="Neutral"/>
                           <datalist id="writing_tones3">
<option>Neutral</option>
<option>Formal</option>
<option>Assertive</option>
<option>Cheerful</option>
<option>Humorous</option>
<option>Informal</option>
<option>Inspirational</option>
<option>Professional</option>
<option>Emotional</option>
<option>Persuasive</option>
<option>Supportive</option>
<option>Sarcastic</option>
<option>Condescending</option>
<option>Skeptical</option>
<option>Narrative</option>
<option>Journalistic</option>
<option>Conversational</option>
<option>Factual</option>
<option>Friendly</option>
<option>Polite</option>
<option>Scientific</option>
<option>Sensitive</option>
<option>Sincere</option>
<option>Curious</option>
<option>Dissapointed</option>
<option>Encouraging</option>
<option>Optimistic</option>
<option>Surprised</option>
<option>Worried</option>
<option>Confident</option>
<option>Authoritative</option>
<option>Nostalgic</option>
<option>Sympathetic</option>
<option>Suspenseful</option>
<option>Romantic</option>
<option>Serious</option>
</datalist>
                           </td>
                        </tr>
                        <tr><td colspan="2">
                              <h4><?php echo esc_html__("Prompts", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Post Title. You can use the following shortcodes: %%video_title%%, %%video_descripton%%, %%video_url%%, %%video_id%%, %%video_captions%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Title Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="title_prompt" id="title_prompt2" placeholder="Enter your title prompts, one per line" class="valuesai2 cr_width_full">Generate a title for a blog post discussing the topics covered in the YouTube video titled: "%%video_title%%", in %%language%% language. Style: %%writing_style%%. Tone: %%writing_tone%%. Must be between 40 and 60 characters.</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the title generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Title Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_title_model2" name="topic_title_model" class="hideAssistant2 valuesai2 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the intro of the article. You can use the following shortcodes: %%video_title%%, %%video_descripton%%, %%video_url%%, %%video_id%%, %%video_captions%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Intro Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="intro_prompt" id="intro_prompt2" placeholder="Enter your intro prompts, one per line" class="valuesai2 cr_width_full">Write an introduction for a blog post which talks about the topics discussed in the YouTube video with the following title: "%%video_title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. The YouTube video has the following transcript: "%%video_captions%%"</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the intro generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Intro Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_intro_model2" name="topic_intro_model" class="hideAssistant2 valuesai2 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Sections of the article. These will be set also as headings in the article. You can use the following shortcodes: %%video_title%%, %%video_descripton%%, %%video_url%%, %%video_id%%, %%video_captions%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Sections Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="sections_prompt" id="sections_prompt2" placeholder="Enter your sections prompts, one per line" class="valuesai2 cr_width_full">Write %%sections_count%% consecutive headings that highlight specific aspects, provide detailed insights and specific recommendations for a blog post which talks about the topics discussed in the YouTube video with the following title: "%%video_title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. Don't add numbers to the headings, hyphens or any types of quotes. Return only the headings list, nothing else. Extract ideas from the following video transcript: "%%video_captions%%"</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the sections generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Sections Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_sections_model2" name="topic_sections_model" class="hideAssistant2 valuesai2 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Content of the article, which will be applied to each section heading generated by the plugin (or entered manually) or to the entire content (depending how you select using the 'Use the Above Content Prompt To Create The Entire Article' checkbox). You can use the following shortcodes: %%video_title%%, %%video_descripton%%, %%video_url%%, %%video_id%%, %%video_captions%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections%%, %%current_section%%, %%paragraphs_per_section%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Content Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="3" cols="70" name="content_prompt" id="content_prompt2" placeholder="Enter your content prompt" class="valuesai2 cr_width_full">Write the content of a post section for the heading "%%current_section%%" in %%language%%. The title of the post is: "%%video_title%%". Don't repeat the heading in the created content. Don't add an intro or outro. Be creative and unique. Write %%paragraphs_per_section%% paragraphs in the section. Use HTML for formatting, include unnumbered lists and bold. If needed, you can use WordPress related CSS styling for the article. When applicable, add also HTML tables with WordPress styling (you can use WordPress table classes). If added, table data must be relevant, creative, short and simple. Writing Style: %%writing_style%%. Tone: %%writing_tone%%. Extract content from the following video transcript: "%%video_captions%%"</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the content generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Content Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_content_model2" name="topic_content_model" class="hideAssistant2 valuesai2 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to use the above content prompt to create the entire article from a single API call (checkbox checked) or to run the prompt for each section separately (checkbox unchecked). If you check this, be sure to modify the content prompt accordingly.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Use the Above Content Prompt To Create The Entire Article (Not Each Section):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="single_content_call-12" name="single_content_call" onclick="hideTOC(-1);" class="valuesai2">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Q&A of the article. You can use the following shortcodes: %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Q&A Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="qa_prompt" id="qa_prompt2" placeholder="Enter your Q&A prompts, one per line" class="valuesai2 cr_width_full">Write a Q&A for a blog post which talks about the topics discussed in the YouTube video with the following title: "%%video_title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. The YouTube video has the following transcript: "%%video_captions%%"</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the Q&A generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Q&A Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_qa_model2" name="topic_qa_model" class="hideAssistant2 valuesai2 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the outro of the article. You can use the following shortcodes: %%video_title%%, %%video_descripton%%, %%video_url%%, %%video_id%%, %%video_captions%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Outro Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="outro_prompt" id="outro_prompt2" placeholder="Enter your outro prompts, one per line" class="valuesai2 cr_width_full">Write an outro for a blog post which talks about the topics discussed in the YouTube video with the following title: "%%video_title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. The YouTube video has the following transcript: "%%video_captions%%"</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the outro generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Outro Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_outro_model2" name="topic_outro_model" class="hideAssistant2 valuesai2 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the excerpt of the article. You can use the following shortcodes: %%video_title%%, %%video_descripton%%, %%video_url%%, %%video_id%%, %%video_captions%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Excerpt Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="excerpt_prompt" id="excerpt_prompt2" placeholder="Enter your excerpt prompts, one per line" class="valuesai2 cr_width_full">Write a short excerpt for a blog post which talks about the topics discussed in the YouTube video with the following title: "%%video_title%%" in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. Must be between 150 and 250 characters. The YouTube video has the following transcript: "%%video_captions%%"</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the excerpt generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Excerpt Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_excerpt_model2" name="topic_excerpt_model" class="hideAssistant2 valuesai2 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr><td colspan="2">
                              <h4><?php echo esc_html__("Advanced Prompting Options", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Run regex on prompts. To disable this feature, leave this field blank. No Regex separators are required here. You can add multiple Regex expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Regex On Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="strip_by_regex_prompts" id="strip_by_regex_prompts2" placeholder="regex expression" class="valuesai2 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Replace the above regex matches with this regex expression. If you want to strip matched content, leave this field blank. No Regex separators are required here. You can add multiple replacement expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Replace Matches From Regex (Prompts):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="replace_regex_prompts" id="replace_regex_prompts2" placeholder="regex replacement" class="valuesai2 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select on which prompts do you want to run the above Regex. Possible values are (or any of their combinations): title, intro, sections, content, outro, excerpt", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Above Regex On Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="run_regex_on2" name="run_regex_on" type="text" list="run_regex_on_list3" class="valuesai2 coderevolution_gutenberg_input" value="content"/>
<datalist id="run_regex_on_list3">
<option value="title">title</option>
<option value="intro">intro</option>
<option value="sections">sections</option>
<option value="content">content</option>
<option value="qa">Q&A</option>
<option value="outro">outro</option>
<option value="excerpt">excerpt</option>
</datalist> 
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Global Prompt Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This will be prepended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Prepend Text To All Textual AI Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="global_prepend" id="global_prepend2" placeholder="Global prompt prepend text" class="valuesai2 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This will be appended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Append Text To All Textual AI Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="global_append" id="global_append2" placeholder="Global prompt append text" class="valuesai2 cr_width_full"></textarea>
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Automatic Linking Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the linking method to use in posts.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Automatic Linking Type:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" class="valuesai2 cr_width_full" id="link_type2" onchange="hideLinks('');" name="link_type">
                           <option value="disabled" selected><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="internal"><?php echo esc_html__("Internal Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="manual"><?php echo esc_html__("Manual Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="serp"><?php echo esc_html__("Related SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="mixed"><?php echo esc_html__("Internal + Manual Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="intserp"><?php echo esc_html__("Internal & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="manserp"><?php echo esc_html__("Manual & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="intmanserp"><?php echo esc_html__("Internal & Manual & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of automatic links to add to created posts. You can also define custom ranges, like: 3-5. Please note that this feature will work best if you already have a considerable number of posts published on your site, which will be used for internal linking.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Number Of Automatic Links To Add To The Post Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="max_links" id="max_links2" placeholder="3-5" class="valuesai2 cr_width_full">
                           </td>
                        </tr>
                        <tr class="hidelinks">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a manual list of links, where the plugin will create links.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Manual List Of URLs (One Per Line):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" cols="70" name="link_list" id="link_list2" placeholder="URL list (one per line)" class="valuesai2 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr class="hidelinks">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to add nofollow attribute to manually entered, external links?", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Nofollow Attribute To External Links:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="link_nofollow2" name="link_nofollow" class="valuesai2">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the post types where to create automatic links in posts. You can also add a comma separated list of multiple post types.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Post Types Where To Generate Automatic Links:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="link_post_types" id="link_post_types2" placeholder="post" class="valuesai2 cr_width_full">
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Advanced AI Text Generator Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. Note that in this value the number of tokens sent to the API as an article prompt will also be counted. The maximum amount which can be set is 4000. For other models, the maximum is 2048.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Total Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_tokens" id="max_tokens2" value="" placeholder="2048" class="valuesai2 cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of prompt API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. This defines how much content does the API receive each time you call it. If the API gets more initial data, better quality results will be expected. The maximum amount which can be set is 1000.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Prompt Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_seed_tokens" id="max_seed_tokens2" value="" placeholder="1000" class="valuesai2 cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of continue API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. This defines how much content does the API receive each time you call it. If the API gets more initial data, better quality results will be expected. The maximum amount which can be set is 500.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Continue Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_continue_tokens" id="max_continue_tokens2" value="" placeholder="500" class="valuesai2 cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("What sampling temperature to use. Higher values means the model will take more risks. Try 0.9 for more creative applications, and 0 (argmax sampling) for ones with a well-defined answer. We generally recommend altering this or top_p but not both.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Temperature:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" step="0.01" max="2" name="temperature" id="temperature2" value="" placeholder="1" class="valuesai2 cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("An alternative to sampling with temperature, called nucleus sampling, where the model considers the results of the tokens with top_p probability mass. So 0.1 means only the tokens comprising the top 10% probability mass are considered. We generally recommend altering this or temperature but not both.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Top_p:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" max="1" step="0.01" name="top_p" id="top_p2" value="" placeholder="1" class="valuesai2 cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on whether they appear in the text so far, increasing the model's likelihood to talk about new topics.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Presence Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="-2" step="0.01" max="2" name="presence_penalty" id="presence_penalty2" value="" placeholder="0" class="valuesai2 cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on their existing frequency in the text so far, decreasing the model's likelihood to repeat the same line verbatim.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Frequency Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" max="2" step="0.01" name="frequency_penalty" id="frequency_penalty2" value="" placeholder="0" class="valuesai2 cr_width_full">
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Image Generator Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the search query repetition mode, when searching royalty free images.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Search Query Repetition:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="search_query_repetition2" name="search_query_repetition" class="valuesai2 cr_width_full">
                              <option value="0" selected><?php echo esc_html__("Use Different Search Queries For Images", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1"><?php echo esc_html__("Use The Same Search Query For Images", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to enable the AI Image Generator and to replace Royalty Free Images with AI generated images?", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Image Source:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="enable_ai_images2" onchange="hideImage('2');" name="enable_ai_images" class="valuesai2 cr_width_full">
                              <option value="0" selected><?php echo esc_html__("Royalty Free", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1"><?php echo esc_html__("OpenAI/AiomaticAPI", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              if (isset($aiomatic_Main_Settings['stability_app_id']) && trim($aiomatic_Main_Settings['stability_app_id']) != '')
                              {
                              ?>
                              <option value="2"><?php echo esc_html__("Stability.AI", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['midjourney_app_id']) && trim($aiomatic_Main_Settings['midjourney_app_id']) != '')
                              {
                              ?>
                              <option value="4"><?php echo esc_html__("Midjourney", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['replicate_app_id']) && trim($aiomatic_Main_Settings['replicate_app_id']) != '')
                              {
                              ?>
                              <option value="5"><?php echo esc_html__("Replicate", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['ideogram_app_id']) && trim($aiomatic_Main_Settings['ideogram_app_id']) != '')
                              {
                              ?>
                              <option value="6"><?php echo esc_html__("Ideogram", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['cloudflare_worker_url']) && trim($aiomatic_Main_Settings['cloudflare_worker_url']) != '' && isset($aiomatic_Main_Settings['cloudflare_worker_secret']) && trim($aiomatic_Main_Settings['cloudflare_worker_secret']) != '')
                              {
                              ?>
                              <option value="8"><?php echo esc_html__("Cloudflare Workers", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['app_id_google']) && trim($aiomatic_Main_Settings['app_id_google']) != '')
                              {
                              ?>
                              <option value="7"><?php echo esc_html__("Google", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              ?>
                              <option value="9"><?php echo esc_html__("Random From Media Library", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
                           </td>
                        </tr>
                        <tr class="hideImg2 cr_none">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set list of prompt commands (one on each line) you want to send to the AI image generator. This command can be any given task or order, based on which, it will generate images. You can use the following shortcodes: %%post_title%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%. The length of this command should not be greater than 1000 characters (4000 characters for Dall-E 3), otherwise the plugin will strip it to 1000 characters length. - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You can also add here a link to a .txt file, where you can add multiple prompts (one per line) and the plugin will select a random one at each run. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          echo '&nbsp;' . sprintf( wp_kses( __( "Please check some tips and tricks about writing prompt commands, <a href='%s' target='_blank'>here</a>. The [aicontent] shortcode is able to be used also here.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-image-generating-for-openai-dall-e-api/' );
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Prompt For The AI Image Generator:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-image-generating-for-openai-dall-e-api/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="ai_command_image" id="ai_command_image2" placeholder="Please insert a command for the AI image generator" class="valuesai2 cr_width_full">Generate a high-resolution, visually compelling image that creatively interprets the theme encapsulated by this post title: "%%post_title%%". The image should be versatile enough to fit various niches, from technology and lifestyle to nature and science. It should feature a central, eye-catching element that abstractly represents the topic, surrounded by relevant, subtler motifs that provide context and depth. The composition should be balanced and aesthetically pleasing, with a harmonious color palette that complements the mood of the title. The artwork should be suitable for use as a captivating header image for a blog post.</textarea>
                           </td>
                        </tr>
                        <tr class="hideDalle2 cr_none">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI model you wish to use for image the image generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Image Model:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="image_model2" name="image_model" class="valuesai2 cr_width_full">
<?php
foreach(AIMOGEN_DALLE_IMAGE_MODELS as $modelx)
{
   echo '<option value="' . esc_html($modelx) .'"';
   if ($modelx == AIMOGEN_DEFAULT_IMAGE_MODEL) { echo ' selected'; }
   echo '>' . esc_html($modelx) . '</option>';
}
?>
                           </select>
                           </td>
                        </tr>
                        <tr class="hideImg2 cr_none">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the size of the generated image.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Generated Image Size:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="model2" name="image_size" class="valuesai2 cr_width_full">
                              <option value="256x256"><?php echo esc_html__("256x256", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="512x512"><?php echo esc_html__("512x512", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1024x1024" selected><?php echo esc_html__("1024x1024", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>  
                           </td>
                        </tr>
                        <tr><td colspan="2">
                              <h3><?php echo esc_html__("Posting Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a HTML text that should be prepended to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%video_title%%, %%video_descripton%%, %%video_url%%, %%video_id%%, %%video_captions%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("HTML Text To Prepend To AI Created Content:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_prepend" id="post_prepend2" placeholder="HTML content to prepend to the AI generated content" class="valuesai2 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a HTML text that should be appended to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%video_title%%, %%video_descripton%%, %%video_url%%, %%video_id%%, %%video_captions%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("HTML Text To Append To AI Created Content:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_append" id="post_append2" placeholder="HTML content to append to the AI generated content" class="valuesai2 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Custom AI generated content shortcode creator. If you wish to create content from multiple AI prompts, and use them in post content/post custom fields/taxonomies, you can configure this from here. Also, these shortcodes will be able to be used in custom fields or custom taxonomies which the plugin will create. Syntax for this field: shortcode_name => AI_MODEL_TO_USE @@ TEXTUAL_PROMPT_TO_USE (to specify multiple shortcodes and crawling values, separate them by a new line. Example: my_custom_shortcode => gpt-5-mini @@ Write a short poem. Afterwards, you can use shortcodes in any settings field that supports shortcodes (ex: 'HTML Text To Append To AI Created Content' settings field), like this: %%my_custom_shortcode%%. Official format is %%name_of_custom_shortcode%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Custom Shortcode Creator (Optional):", 'aiomatic-automatic-ai-content-writer');?></b><span class="tool" data-tip="Supported models: <?php echo esc_html(implode(',', aiomatic_get_all_models()));?>">&nbsp;&#9432;</span>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="custom_shortcodes" id="custom_shortcodes2" placeholder="shortcode_name => AI_MODEL @@ AI_PROMPT" class="valuesai2 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("The AI writer might add the title of the post to the created post content. Check this checkbox if you want to remove the title from the post content.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Strip Title From Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="strip_title2" name="strip_title" class="valuesai2">
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip spinning of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Do Not Spin Posts Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="skip_spin2" name="skip_spin" class="valuesai2">               
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip translating of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Do Not Translate Posts Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="skip_translate2" name="skip_translate" class="valuesai2">               
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to process added YouTube videos in order of entry or in random order.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Process Videos In Order Of Entry:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="no_random2" name="no_random" class="valuesai2">
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Run regex on post content. To disable this feature, leave this field blank. No Regex separators are required here. You can add multiple Regex expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Regex On Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="strip_by_regex" id="strip_by_regex2" placeholder="regex expression" class="valuesai2 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Replace the above regex matches with this regex expression. If you want to strip matched content, leave this field blank. No Regex separators are required here. You can add multiple replacement expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Replace Matches From Regex (Content):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="replace_regex" id="replace_regex2" placeholder="regex replacement" class="valuesai2 cr_width_full"></textarea>
                           </td>
                        </tr>
                     </table>
                  </div>
               </div>
               <div class="codemodalfzr-footer">
                  <br/>
                  <h3 class="cr_inline">Aimogen Automatic Post Generator</h3>
                  <span id="aiomatic_ok2" class="codeokfzr cr_inline">OK&nbsp;</span>
                  <br/><br/>
               </div>
            </div>
         </div>




   <div id="mymodalfzr3" class="codemodalfzr">
            <div class="codemodalfzr-content">
               <div class="codemodalfzr-header">
                  <span id="aiomatic_close3" class="codeclosefzr">&times;</span>
                  <h2><span class="cr_color_white"><?php echo esc_html__("AI Product Roundup", 'aiomatic-automatic-ai-content-writer');?></span> <?php echo esc_html__("Advanced Settings", 'aiomatic-automatic-ai-content-writer');?></h2>
               </div>
               <div class="codemodalfzr-body">
                  <div class="table-responsive">
                     <table class="responsive table cr_main_table_nowr">
                        <tr><td colspan="2">
                           <h3><?php echo esc_html__("Product Source Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                     </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the source of the products to be included in the created article.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Product Source:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select id="product_source3" name="product_source" class="valuesai3 cr_width_full" onchange="productSourceChangedSingle();">
                              <option value="amazon" selected><?php echo esc_html__("Amazon", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="clickbank"><?php echo esc_html__("ClickBank", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>  
                           </td>
                        </tr>
                     <tr><td colspan="2">
                           <h3><?php echo esc_html__("AI Assistant Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                     </td></tr>
                     <tr>
                        <td class="cr_min_width_200">
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("Select the AI Assistant to use for content creation. This will disable the ability to select AI models, as the models assisgned to the assistant will be used for content creation.", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                              <b><?php echo esc_html__("AI Assistant Name:", 'aiomatic-automatic-ai-content-writer');?></b>
                        </td>
                        <td><select id="assistant_id3" name="assistant_id" class="valuesai3 cr_width_full" onchange="assistantSelected('3');">
<?php
if($all_assistants === false)
{
echo '<option val="" selected disabled>' . esc_html__("Only OpenAI API is supported for Assistants API", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
if(count($all_assistants) == 0)
{
echo '<option val="" selected disabled>' . esc_html__("No Assistans added, go to the plugin's 'AI Assistans' menu to add new assistants!", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
echo '<option value="" selected';
echo '>' . esc_html__("Don't use assistants, use AI models instead", 'aiomatic-automatic-ai-content-writer') . '</option>';
foreach($all_assistants as $myassistant)
{
echo '<option value="' . esc_html($myassistant->ID) .'"';
echo '>' . esc_html($myassistant->post_title);
echo '</option>';
}
}
}
?>
</select>  
                        </td>
                     </tr>
                        <tr class="ai-amazon"><td colspan="2">
                              <h3><?php echo esc_html__("Amazon Search Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr class="ai-amazon">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo sprintf( wp_kses( __( "Insert your Amazon Associate ID (Optional). Learn how to get one <a href='%s' target='_blank'>here</a>. Also, you need to sign up for Amazon Affiliate program <a href='%s' target='_blank'>here</a>.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://affiliate-program.amazon.com/gp/advertising/api/detail/main.html', 'https://affiliate-program.amazon.com/assoc_credentials/home' );
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Amazon Associate ID (Optional):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="affiliate_id" id="affiliate_id3" value="" placeholder="Please insert your Amazon Affiliate ID" class="valuesai3 cr_width_full">   
                           </td>
                        </tr>
                        <tr class="ai-amazon">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the country where you have registred your affiliate account.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Amazon Target Country:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                        <select id="source3" name="target_country" class="valuesai3 cr_width_full">
                        <?php
                           $amaz_countries = aiomatic_get_amazon_codes();
                           foreach ($amaz_countries as $key => $value) {
                              echo '<option value="' . esc_html($key) . '">' . esc_html($value) . '</option>';
                           }
                           ?>
                        </select>  
                           </td>
                        </tr>
                        <tr class="ai-amazon">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to set a minimum price for the imported item? Price is in pennies: 1000 is 10$.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Min Price in Pennies:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" step="1" id="min_price3" name="min_price" class="valuesai3 cr_width_full" placeholder="Input the minimum price in pennies">
                           </td>
                        </tr>
                        <tr class="ai-amazon">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to set a maximum price for the imported item? Price is in pennies: 1000 is 10$.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Max Price in Pennies:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" step="1" id="max_price3" name="max_price" class="valuesai3 cr_width_full" placeholder="Input the maximum price in pennies">
                           </td>
                        </tr>
                        <tr class="ai-amazon">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter the maximum number of products to include in the product roundup article. You can also enter number ranges like: 3-4", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Max Number Of Products To Include:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <input type="text" id="max_products3" name="max_products" placeholder="3-4" class="valuesai3 cr_width_full" value="3-4">  
                           </td>
                        </tr>
                        <tr class="ai-amazon">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the type of sorting of the returned results. This will work only if you also set a value to the 'Amazon Category' settings field.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Sort Results By:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select id="sort_results3" name="sort_results" class="valuesai3 cr_width_full">
                           <option value="none" selected><?php echo esc_html__("None", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="Relevance"><?php echo esc_html__("Relevance", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="Price:LowToHigh"><?php echo esc_html__("Price:LowToHigh", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="Price:HighToLow"><?php echo esc_html__("Price:HighToLow", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="NewestArrivals"><?php echo esc_html__("NewestArrivals", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="Featured"><?php echo esc_html__("Featured", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="AvgCustomerReviews"><?php echo esc_html__("AvgCustomerReviews", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>    
                           </td>
                        </tr>
                        <tr class="ai-amazon">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("If enabled, the products will be shuffled, randomizing their order on each run.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Randomize Product Order:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="shuffle_products3" name="shuffle_products" class="valuesai3" checked>
                           </td>
                        </tr> 
                        <tr class="ai-clickbank cr_none"><td colspan="2">
                              <h3><?php echo esc_html__("ClickBank Search Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr class="ai-clickbank cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter your ClickBank affiliate ID.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("ClickBank Affiliate ID:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="cb_affiliate_id3" name="cb_affiliate_id" class="valuesai3 cr_width_full" placeholder="ClickBank affiliate ID">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter the maximum number of products to include in the product roundup article. You can also enter number ranges like: 3-4", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Max Number Of Products To Include:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <input type="text" id="max_products_cb3" name="max_products_cb" placeholder="3-4" class="valuesai3 cr_width_full" value="3-4">  
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to exclude products based on a set of negative keywords?", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Exclude Keywords:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="neg_keywords3" name="neg_keywords" class="valuesai3 cr_width_full" placeholder="Input keywords to exclude">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Limits the results to one of the following categories.", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Item Category:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select id="item_category3" name="item_category" class="valuesai3 cr_width_full">
                           <option value="All" selected><?php echo esc_html__("All", 'aiomatic-automatic-ai-content-writer');?></option>
                           <?php
                              foreach($cat_arr as $id => $name)
                              {
                                    echo '<option value="' . esc_attr($id) . '">' . esc_html($name) . '</option>';
                              }
                              ?>
                           </select>
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Selecting this option displays accounts with one-time products.", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Billing Type: One-time:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="one_time3" name="one_time" class="valuesai3">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Selecting this option displays accounts with recurring billing products.", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Billing Type: Recurring:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="recurring3" name="recurring" class="valuesai3">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Display only vendor accounts with an Affiliate Tools page. An Affiliate Tools page contains resources such as images, tips, keywords, testimonials, and FAQs that can help you promote the account's products more effectively.", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Affiliate Tools Page Available:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="affiliate_tools3" name="affiliate_tools" class="valuesai3">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Display only vendor accounts with a Vendor Spotlight. A Vendor Spotlight provides more detailed information about the vendor and their offerings.", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Vendor Spotlight Page Available:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="spotlight3" name="spotlight" class="valuesai3">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Display only vendor accounts with a mobile HopLink target URL.", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Mobile Hoplink Page Available:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="mobile_hoplink3" name="mobile_hoplink" class="valuesai3">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Selecting this option displays only accounts with physical products.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Shippable Media:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="shipable_only3" name="shipable_only" class="valuesai3">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Selecting this option displays only accounts with PitchPlus Upsell Flows.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("PitchPlus:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="pitch_plus3" name="pitch_plus" class="valuesai3">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("The gravity performance statistic is an approximate, relative measure of how many affiliates have successfully promoted products from an account, with a higher number meaning more conversions. You can specify a minimum and/or a maximum gravity value. To input a maximum, enter '<10', to enter a minimum, enter '>10', to input a range, enter '10-20'.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Item Gravity:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="item_gravity3" name="item_gravity" class="valuesai3 cr_width_full" placeholder="Item gravity">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This number represents the average dollar value of an initial sale, not including rebills, to the affiliate who drives the sale. You can specify a minimum and/or a maximum Initial $/Sale value. To input a maximum, enter '<10', to enter a minimum, enter '>10', to input a range, enter '10-20'.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Item Initial $/sale:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="dollar_sale3" name="dollar_sale" class="valuesai3 cr_width_full" placeholder="Income per sale">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This number represents the average dollar value of a sale, including both initial and rebill payments, to the affiliate who drives the sale. You can specify a minimum and/or a maximum Avg $/Sale. To input a maximum, enter '<10', to enter a minimum, enter '>10', to input a range, enter '10-20'.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Item Avg $/sale:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="dollar_sale_av3" name="dollar_sale_av" class="valuesai3 cr_width_full" placeholder="Avarage income per sale">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This number represents the average total dollar value of a sale, including only rebill payments, to the affiliate who drives the sale. You can specify a minimum and/or a maximum Avg Rebill Total. To input a maximum, enter '<10', to enter a minimum, enter '>10', to input a range, enter '10-20'.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Item Avg Rebill Total:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="rebill_total3" name="rebill_total" class="valuesai3 cr_width_full" placeholder="Total rebill">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This number represents the average affiliate commission percentage for a sale, including both initial and rebill commissions. You can specify a minimum and/or a maximum Avg %/Sale. To input a maximum, enter '<10', to enter a minimum, enter '>10', to input a range, enter '10-20'.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Item Avg %/sale:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="per_sale3" name="per_sale" class="valuesai3 cr_width_full" placeholder="Sales percentage">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This number represents the average affiliate commission percentage for a sale, including only the rebill commission. You can specify a minimum and/or a maximum Avg %/Rebill. To input a maximum, enter '<10', to enter a minimum, enter '>10', to input a range, enter '10-20'.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Item Avg %/rebill:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="per_rebill3" name="per_rebill" class="valuesai3 cr_width_full" placeholder="Rebill percentage">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("The date on which the account was added to the ClickBank marketplace. You can specify a beginning and/or end date. The beginning date cannot be earlier than 120 days ago, and the end date cannot be later than today. To input a maximum, enter '<2018-09-20', to enter a minimum, enter '>2018-09-20', to input a range, enter '2018-09-20=2018-09-30'.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Vendor Activation Time:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="activation3" name="activation" class="valuesai3 cr_width_full" placeholder="Vendor activation time">
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("You can select one or more languages to display only accounts with products in the selected languages.", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Language:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select id="item_language3" name="item_language" class="valuesai3 cr_width_full">
                           <option value="All" selected><?php echo esc_html__("All", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="German"><?php echo esc_html__("German", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="English"><?php echo esc_html__("English", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="Spanish"><?php echo esc_html__("Spanish", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="French"><?php echo esc_html__("French", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="Italian"><?php echo esc_html__("Italian", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="Portuguese"><?php echo esc_html__("Portuguese", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr class="ai-clickbank cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the type of sorting of the returned results.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Sort Results By:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select id="sort_results_cb3" name="sort_results_cb" class="valuesai3 cr_width_full">
                           <option value="relevance" selected><?php echo esc_html__("Relevance", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="GRAVITY"><?php echo esc_html__("Gravity", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="POPULARITY"><?php echo esc_html__("Popularity", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="AVERAGE_EARNINGS_PER_SALE"><?php echo esc_html__("Average Earnings Per Sale", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>     
                           </td>
                        </tr>
                        <tr><td colspan="2">
                              <h3><?php echo esc_html__("AI Writer Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("If enabled, the article will be written from a perspective that sometimes can make it sound like the writer has first-hand experience with the products.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Enable First-Hand Experience:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="first_hand3" name="first_hand" class="valuesai3">
                           </td>
                        </tr> 
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select what you want to do with product titles in articles.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Product Titles To Content As:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" class="valuesai3 cr_width_full" id="sections_role3" name="sections_role">
                           <option value="h2" selected><?php echo esc_html__("h2", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="h3"><?php echo esc_html__("h3", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="b"><?php echo esc_html__("Bold", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="i"><?php echo esc_html__("Italic", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="bi"><?php echo esc_html__("Bold and Italic", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="p"><?php echo esc_html__("Paragraph", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="x"><?php echo esc_html__("Plain Text", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="no"><?php echo esc_html__("Don't Add Sections", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter the number of paragraphs to create for each section. These will also be set as article headings. You can also set value ranges, example: 5-7. In this case, a random number will be selected in this range. Please use only numeric values in this field. This field will set the value of the %%paragraphs_per_section%% shortcode.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Number Of Paragraphs Per Section:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <input type="text" id="paragraph_count3" name="paragraph_count" placeholder="2-3" class="valuesai3 cr_width_full" value="2">  
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add the product images to the article.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Product Images To The Article:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="topic_images3" name="topic_images" class="valuesai3" checked>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you don't want to add the product links directly to headings.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Don't Add Product Links to Headings:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="no_headlink3" name="no_headlink" class="valuesai3">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you would like to add a relevant Social Network Embed to the end of the created article. You can select the source of the social embeds, in the plugin's 'Settings' menu -> 'Bulk Posts' tab -> 'Social Networks To Get Embeds From In AI Created Articles' settings field.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add A Relevant Social Network Embed To The Article:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="topic_videos3" name="topic_videos" class="valuesai3">
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the outro section header. This is optional.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Outro Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="title_outro" id="title_outro3" value="{Experience the Difference|Unlock Your Potential|Elevate Your Lifestyle|Embrace a New Era|Seize the Opportunity|Discover the Power|Transform Your World|Unleash Your True Potential|Embody Excellence|Achieve New Heights|Experience Innovation|Ignite Your Passion|Reveal the Extraordinary}" placeholder="Optional" class="valuesai3 cr_width_full">
                           </td>
                        </tr> 
                        <tr>
                           <td class="hideTOC-1">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add a Table of Contents section to the created post.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Article 'Table Of Contents':", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td class="hideTOC-1">
                           <input type="checkbox" id="enable_toc3" name="enable_toc" class="valuesai3">
                           </td>
                        </tr> 
                        <tr>
                           <td class="hideTOC-1">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the Table of Contents section header. Default is: Table of Contents", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article 'Table Of Contents' Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td class="hideTOC-1">
                           <input type="text" name="title_toc" id="title_toc3" value="Table of Contents" placeholder="Table of Contents" class="valuesai3 cr_width_full">
                           </td>
                        </tr> 
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add a Q&A section to the created post. To enable Q&A for articles, be sure to add a prompt also in the 'Article Q&A Prompt' settings field from below.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Article 'Q&A' Section:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="enable_qa3" name="enable_qa" class="valuesai3">
                           </td>
                        </tr> 
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the Q&A section header. Default is: Q&A", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article 'Q&A' Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="title_qa" id="title_qa3" value="Q&A" placeholder="Q&A" class="valuesai3 cr_width_full">
                           </td>
                        </tr> 
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add a product comparison table to the created article.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Product Comparison Table:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="enable_table3" name="enable_table" class="valuesai3">
                           </td>
                        </tr> 
                        <tr><td colspan="2">
                              <h4><?php echo esc_html__("Content Parameters", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the language of the created content. This will set the value of the %%language%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Content Language:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="content_language3" name="content_language" type="text" list="languages4" placeholder="Created content language" class="valuesai3 coderevolution_gutenberg_input" value="English"/>
<datalist id="languages4">
<?php
foreach($aiomatic_language_names as $ln)
{
echo '<option>' . esc_html($ln) . '</option>';
}
?>
</datalist>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the writing style of the created content. This will set the value of the %%writing_style%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Writing Style:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="writing_style3" name="writing_style" type="text" placeholder="Created content writing style" list="writing_styles4" class="valuesai3 coderevolution_gutenberg_input" value="Creative"/>
                           <datalist id="writing_styles4">
<option>Informative</option>
<option>Academic</option>
<option>Descriptive</option>
<option>Detailed</option>
<option>Dramative</option>
<option>Fiction</option>
<option>Expository</option>
<option>Historical</option>
<option>Dialogue</option>
<option>Creative</option>
<option>Critical</option>
<option>Narrative</option>
<option>Persuasive</option>
<option>Reflective</option>
<option>Argumentative</option>
<option>Analytical</option>
<option>Blog</option>
<option>News</option>
<option>Casual</option>
<option>Pastoral</option>
<option>Personal</option>
<option>Poetic</option>
<option>Satirical</option>
<option>Sensory</option>
<option>Articulate</option>
<option>Monologue</option>
<option>Colloquial</option>
<option>Comparative</option>
<option>Concise</option>
<option>Biographical</option>
<option>Anecdotal</option>
<option>Evaluative</option>
<option>Letter</option>
<option>Lyrical</option>
<option>Simple</option>
<option>Vivid</option>
<option>Journalistic</option>
<option>Technical</option>
<option>Direct</option>
<option>Emotional</option>
<option>Metaphorical</option>
<option>Objective</option>
<option>Rhetorical</option>
<option>Theoretical</option>
<option>Business</option>
<option>Report</option>
<option>Research</option>
</datalist>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the writing tone of the created content. This will set the value of the %%writing_tone%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Writing Tone:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="writing_tone3" name="writing_tone" type="text" list="writing_tones4" placeholder="Created content writing tone" class="valuesai3 coderevolution_gutenberg_input" value="Neutral"/>
                           <datalist id="writing_tones4">
<option>Neutral</option>
<option>Formal</option>
<option>Assertive</option>
<option>Cheerful</option>
<option>Humorous</option>
<option>Informal</option>
<option>Inspirational</option>
<option>Professional</option>
<option>Emotional</option>
<option>Persuasive</option>
<option>Supportive</option>
<option>Sarcastic</option>
<option>Condescending</option>
<option>Skeptical</option>
<option>Narrative</option>
<option>Journalistic</option>
<option>Conversational</option>
<option>Factual</option>
<option>Friendly</option>
<option>Polite</option>
<option>Scientific</option>
<option>Sensitive</option>
<option>Sincere</option>
<option>Curious</option>
<option>Dissapointed</option>
<option>Encouraging</option>
<option>Optimistic</option>
<option>Surprised</option>
<option>Worried</option>
<option>Confident</option>
<option>Authoritative</option>
<option>Nostalgic</option>
<option>Sympathetic</option>
<option>Suspenseful</option>
<option>Romantic</option>
<option>Serious</option>
</datalist>
                           </td>
                        </tr>
                        <tr><td colspan="2">
                              <h4><?php echo esc_html__("Prompts", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Post Title. You can use the following shortcodes: %%search_keywords%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Title Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="title_prompt" id="title_prompt3" placeholder="Enter your title prompts, one per line" class="valuesai3 cr_width_full">Write a title for a product roundup blog post which talks about the following products: %%all_product_titles%%,  %%all_product_info%%, in %%language%% language. Style: %%writing_style%%. Tone: %%writing_tone%%. Must be between 40 and 60 characters.</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the title generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Title Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_title_model3" name="topic_title_model" class="hideAssistant3 valuesai3 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the intro of the article. You can use the following shortcodes: %%search_keywords%%, %%all_product_titles%%,  %%all_product_info%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Intro Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="intro_prompt" id="intro_prompt3" placeholder="Enter your intro prompts, one per line" class="valuesai3 cr_width_full">Write an intro for a blog post which talks about the following products: %%all_product_titles%%,  %%all_product_info%%, in %%language%%. The title of the post is "%%post_title%%". Style: %%writing_style%%. Tone: %%writing_tone%%.</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the intro generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Intro Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_intro_model3" name="topic_intro_model" class="hideAssistant3 valuesai3 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Content of the article, which will be applied to each section heading generated by the plugin (or entered manually) or to the entire content (depending how you select using the 'Use the Above Content Prompt To Create The Entire Article' checkbox). You can use the following shortcodes: %%all_product_titles%%,  %%all_product_info%%, %%product_title%%, %%product_description%%, %%product_author%%, %%product_brand%%, %%product_isbn%%, %%product_upc%%, %%offer_url%%, %%offer_price%%, %%product_list_price%%, %%offer_img%%, %%product_reviews%%, %%price_numeric%%, %%price_currency%%, %%review_link%%, %%product_asin%%, %%cart_url%%, %%list_price_numeric%%, %%product_imgs%%, %%product_imgs_html%%, %%price_with_discount_fixed%%, %%first_hand_experience_prompt%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections%%, %%current_section%%, %%paragraphs_per_section%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. If you have access to the Amazon API, you can set it up in the plugin and get access to the following advanced shortcodes also: %%product_score%%, %%product_edition%%, %%product_language%%, %%product_pages_count%%, %%product_publication_date%%, %%product_contributors%%, %%product_manufacturer%%, %%product_binding%%, %%product_product_group%%, %%product_rating%%, %%product_ean%%, %%product_part_no%%, %%product_model%%, %%product_warranty%%, %%product_color%%, %%product_is_adult%%, %%product_dimensions%%, %%product_date%%, %%product_size%%, %%product_unit_count%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Content Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="3" cols="70" name="content_prompt" id="content_prompt3" placeholder="Enter your content prompt" class="valuesai3 cr_width_full">Write the content of a post section describing the product "%%product_title%%" in %%language%%. Include pros and cons of the product. Don't repeat the product title in the created content. Don't add an intro or outro. Write %%paragraphs_per_section%% paragraphs in the section. Use HTML for formatting, include unnumbered lists and bold. When applicable, add also HTML tables with WordPress styling (you can use WordPress table classes). If added, table data must be relevant, creative, short and simple. Writing Style: %%writing_style%%. Tone: %%writing_tone%%. %%first_hand_experience_prompt%% Extract content from the following product description: "%%product_description%%"</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the content generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Content Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_content_model3" name="topic_content_model" class="hideAssistant3 valuesai3 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Q&A of the article. You can use the following shortcodes: %%search_keywords%%, %%all_product_titles%%,  %%all_product_info%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Q&A Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="qa_prompt" id="qa_prompt3" placeholder="Enter your Q&A prompts, one per line" class="valuesai3 cr_width_full">Write a Q&A for a blog post with the following title: "%%post_title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. The blog post describes and compares multiple products: %%all_product_titles%%</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the Q&A generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Q&A Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_qa_model3" name="topic_qa_model" class="hideAssistant3 valuesai3 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the outro of the article. You can use the following shortcodes: %%search_keywords%%, %%all_product_titles%%,  %%all_product_info%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Outro Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="outro_prompt" id="outro_prompt3" placeholder="Enter your outro prompts, one per line" class="valuesai3 cr_width_full">Write an outro for a blog post with the following title: "%%post_title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. The blog post describes and compares multiple products: %%all_product_titles%%</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the outro generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Outro Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_outro_model3" name="topic_outro_model" class="hideAssistant3 valuesai3 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the excerpt of the article. You can use the following shortcodes: %%search_keywords%%, %%all_product_titles%%,  %%all_product_info%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Excerpt Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="excerpt_prompt" id="excerpt_prompt3" placeholder="Enter your excerpt prompts, one per line" class="valuesai3 cr_width_full">Write a short excerpt for a blog post with the following title: "%%post_title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. The blog post describes and compares multiple products: %%all_product_titles%%</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the excerpt generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Excerpt Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_excerpt_model3" name="topic_excerpt_model" class="hideAssistant3 valuesai3 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the product comparison prompt of the article. You can use the following shortcodes: %%search_keywords%%, %%all_product_titles%%,  %%all_product_info%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Comparison Table Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="table_prompt" id="table_prompt3" placeholder="Enter your table prompts, one per line" class="valuesai3 cr_width_full">Generate a HTML product comparison table, for a product review blog post. The post has the following title: "%%post_title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. Point Of View: %%point_of_view%%. Don't add the entire description as a table entry, but instead, extract data from it, make matches between multiple products, be creative and also short and simple. The table must be in a WordPress friendly format and have modern styling (you can use WordPress table classes). Detail product information: %%all_product_info%%</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the product comparison table generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Comparison Table Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_table_model3" name="topic_table_model" class="hideAssistant3 valuesai3 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr><td colspan="2">
                              <h4><?php echo esc_html__("Advanced Prompting Options", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Run regex on prompts. To disable this feature, leave this field blank. No Regex separators are required here. You can add multiple Regex expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Regex On Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="strip_by_regex_prompts" id="strip_by_regex_prompts3" placeholder="regex expression" class="valuesai3 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Replace the above regex matches with this regex expression. If you want to strip matched content, leave this field blank. No Regex separators are required here. You can add multiple replacement expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Replace Matches From Regex (Prompts):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="replace_regex_prompts" id="replace_regex_prompts3" placeholder="regex replacement" class="valuesai3 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select on which prompts do you want to run the above Regex. Possible values are (or any of their combinations): title, intro, sections, content, qa, outro, excerpt", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Above Regex On Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="run_regex_on3" name="run_regex_on" type="text" list="run_regex_on_list4" class="valuesai3 coderevolution_gutenberg_input" value="content"/>
<datalist id="run_regex_on_list4">
<option value="title">title</option>
<option value="intro">intro</option>
<option value="sections">sections</option>
<option value="content">content</option>
<option value="qa">Q&A</option>
<option value="outro">outro</option>
<option value="excerpt">excerpt</option>
<option value="table">table</option>
</datalist> 
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Global Prompt Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This will be prepended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Prepend Text To All Textual AI Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="global_prepend" id="global_prepend3" placeholder="Global prompt prepend text" class="valuesai3 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This will be appended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Append Text To All Textual AI Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="global_append" id="global_append3" placeholder="Global prompt append text" class="valuesai3 cr_width_full"></textarea>
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Automatic Linking Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the linking method to use in posts.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Automatic Linking Type:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" class="valuesai3 cr_width_full" id="link_type3" onchange="hideLinks('');" name="link_type">
                           <option value="disabled" selected><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="internal"><?php echo esc_html__("Internal Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="manual"><?php echo esc_html__("Manual Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="serp"><?php echo esc_html__("Related SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="mixed"><?php echo esc_html__("Internal + Manual Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="intserp"><?php echo esc_html__("Internal & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="manserp"><?php echo esc_html__("Manual & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="intmanserp"><?php echo esc_html__("Internal & Manual & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of automatic links to add to created posts. You can also define custom ranges, like: 3-5. Please note that this feature will work best if you already have a considerable number of posts published on your site, which will be used for internal linking.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Number Of Automatic Links To Add To The Post Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="max_links" id="max_links3" placeholder="3-5" class="valuesai3 cr_width_full">
                           </td>
                        </tr>
                        <tr class="hidelinks">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a manual list of links, where the plugin will create links.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Manual List Of URLs (One Per Line):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" cols="70" name="link_list" id="link_list3" placeholder="URL list (one per line)" class="valuesai3 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr class="hidelinks">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to add nofollow attribute to manually entered, external links?", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Nofollow Attribute To External Links:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="link_nofollow3" name="link_nofollow" class="valuesai3">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the post types where to create automatic links in posts. You can also add a comma separated list of multiple post types.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Post Types Where To Generate Automatic Links:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="link_post_types" id="link_post_types3" placeholder="post" class="valuesai3 cr_width_full">
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Advanced AI Text Generator Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. Note that in this value the number of tokens sent to the API as an article prompt will also be counted. The maximum amount which can be set is 4000. For other models, the maximum is 2048.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Total Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_tokens" id="max_tokens3" value="" placeholder="2048" class="valuesai3 cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of prompt API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. This defines how much content does the API receive each time you call it. If the API gets more initial data, better quality results will be expected. The maximum amount which can be set is 1000.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Prompt Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_seed_tokens" id="max_seed_tokens3" value="" placeholder="1000" class="valuesai3 cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of continue API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. This defines how much content does the API receive each time you call it. If the API gets more initial data, better quality results will be expected. The maximum amount which can be set is 500.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Continue Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_continue_tokens" id="max_continue_tokens3" value="" placeholder="500" class="valuesai3 cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("What sampling temperature to use. Higher values means the model will take more risks. Try 0.9 for more creative applications, and 0 (argmax sampling) for ones with a well-defined answer. We generally recommend altering this or top_p but not both.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Temperature:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" step="0.01" max="2" name="temperature" id="temperature3" value="" placeholder="1" class="valuesai3 cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("An alternative to sampling with temperature, called nucleus sampling, where the model considers the results of the tokens with top_p probability mass. So 0.1 means only the tokens comprising the top 10% probability mass are considered. We generally recommend altering this or temperature but not both.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Top_p:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" max="1" step="0.01" name="top_p" id="top_p3" value="" placeholder="1" class="valuesai3 cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on whether they appear in the text so far, increasing the model's likelihood to talk about new topics.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Presence Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="-2" step="0.01" max="2" name="presence_penalty" id="presence_penalty3" value="" placeholder="0" class="valuesai3 cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on their existing frequency in the text so far, decreasing the model's likelihood to repeat the same line verbatim.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Frequency Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" max="2" step="0.01" name="frequency_penalty" id="frequency_penalty3" value="" placeholder="0" class="valuesai3 cr_width_full">
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Image Generator Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the search query repetition mode, when searching royalty free images.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Search Query Repetition:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="search_query_repetition3" name="search_query_repetition" class="valuesai3 cr_width_full">
                              <option value="0" selected><?php echo esc_html__("Use Different Search Queries For Images", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1"><?php echo esc_html__("Use The Same Search Query For Images", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to enable the AI Image Generator and to replace Royalty Free Images with AI generated images?", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Image Source:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="enable_ai_images3" onchange="hideImage('3');" name="enable_ai_images" class="valuesai3 cr_width_full">
                              <option value="0" selected><?php echo esc_html__("Royalty Free", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1"><?php echo esc_html__("OpenAI/AiomaticAPI", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              if (isset($aiomatic_Main_Settings['stability_app_id']) && trim($aiomatic_Main_Settings['stability_app_id']) != '')
                              {
                              ?>
                              <option value="2"><?php echo esc_html__("Stability.AI", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['midjourney_app_id']) && trim($aiomatic_Main_Settings['midjourney_app_id']) != '')
                              {
                              ?>
                              <option value="4"><?php echo esc_html__("Midjourney", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['replicate_app_id']) && trim($aiomatic_Main_Settings['replicate_app_id']) != '')
                              {
                              ?>
                              <option value="5"><?php echo esc_html__("Replicate", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['ideogram_app_id']) && trim($aiomatic_Main_Settings['ideogram_app_id']) != '')
                              {
                              ?>
                              <option value="6"><?php echo esc_html__("Ideogram", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['cloudflare_worker_url']) && trim($aiomatic_Main_Settings['cloudflare_worker_url']) != '' && isset($aiomatic_Main_Settings['cloudflare_worker_secret']) && trim($aiomatic_Main_Settings['cloudflare_worker_secret']) != '')
                              {
                              ?>
                              <option value="8"><?php echo esc_html__("Cloudflare Workers", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['app_id_google']) && trim($aiomatic_Main_Settings['app_id_google']) != '')
                              {
                              ?>
                              <option value="7"><?php echo esc_html__("Google", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              ?>
                              <option value="9"><?php echo esc_html__("Random From Media Library", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
                           </td>
                        </tr>
                        <tr class="hideImg3 cr_none">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set list of prompt commands (one on each line) you want to send to the AI image generator. This command can be any given task or order, based on which, it will generate images. You can use the following shortcodes: %%post_title%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%. Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You can also add here a link to a .txt file, where you can add multiple prompts (one per line) and the plugin will select a random one at each run. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          echo '&nbsp;' . sprintf( wp_kses( __( "Please check some tips and tricks about writing prompt commands, <a href='%s' target='_blank'>here</a>. The [aicontent] shortcode is able to be used also here.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-image-generating-for-openai-dall-e-api/' );
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Prompt For The AI Image Generator:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-image-generating-for-openai-dall-e-api/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="ai_command_image" id="ai_command_image3" placeholder="Please insert a command for the AI image generator" class="valuesai3 cr_width_full">A high detail image with no text of: "%%post_title%%"</textarea>
                           </td>
                        </tr>
                        <tr class="hideDalle3 cr_none">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI model you wish to use for image the image generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Image Model:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="image_model3" name="image_model" class="valuesai3 cr_width_full">
<?php
foreach(AIMOGEN_DALLE_IMAGE_MODELS as $modelx)
{
   echo '<option value="' . esc_html($modelx) .'"';
   if ($modelx == AIMOGEN_DEFAULT_IMAGE_MODEL) { echo ' selected'; }
   echo '>' . esc_html($modelx) . '</option>';
}
?>
                           </select>
                           </td>
                        </tr>
                        <tr class="hideImg3 cr_none">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the size of the generated image.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Generated Image Size:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="model3" name="image_size" class="valuesai3 cr_width_full">
                              <option value="256x256"><?php echo esc_html__("256x256", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="512x512"><?php echo esc_html__("512x512", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1024x1024" selected><?php echo esc_html__("1024x1024", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>  
                           </td>
                        </tr>
                        <tr><td colspan="2">
                              <h3><?php echo esc_html__("Posting Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a HTML text that should be prepended to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%search_keywords%%, %%all_product_titles%%,  %%all_product_info%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("HTML Text To Prepend To AI Created Content:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_prepend" id="post_prepend3" placeholder="HTML content to prepend to the AI generated content" class="valuesai3 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a HTML text that should be appended to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%search_keywords%%, %%all_product_titles%%,  %%all_product_info%%, %%language%%, %%writing_style%%, %%writing_tone%%, %%sections_count%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("HTML Text To Append To AI Created Content:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_append" id="post_append3" placeholder="HTML content to append to the AI generated content" class="valuesai3 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Custom AI generated content shortcode creator. If you wish to create content from multiple AI prompts, and use them in post content/post custom fields/taxonomies, you can configure this from here. Also, these shortcodes will be able to be used in custom fields or custom taxonomies which the plugin will create. Syntax for this field: shortcode_name => AI_MODEL_TO_USE @@ TEXTUAL_PROMPT_TO_USE (to specify multiple shortcodes and crawling values, separate them by a new line. Example: my_custom_shortcode => gpt-5-mini @@ Write a short poem. Afterwards, you can use shortcodes in any settings field that supports shortcodes (ex: 'HTML Text To Append To AI Created Content' settings field), like this: %%my_custom_shortcode%%. Official format is %%name_of_custom_shortcode%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Custom Shortcode Creator (Optional):", 'aiomatic-automatic-ai-content-writer');?></b><span class="tool" data-tip="Supported models: <?php echo esc_html(implode(',', aiomatic_get_all_models()));?>">&nbsp;&#9432;</span>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="custom_shortcodes" id="custom_shortcodes3" placeholder="shortcode_name => AI_MODEL @@ AI_PROMPT" class="valuesai3 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("The AI writer might add the title of the post to the created post content. Check this checkbox if you want to remove the title from the post content.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Strip Title From Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="strip_title3" name="strip_title" class="valuesai3">
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip spinning of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Do Not Spin Posts Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="skip_spin3" name="skip_spin" class="valuesai3">               
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip translating of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Do Not Translate Posts Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="skip_translate3" name="skip_translate" class="valuesai3">               
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Run regex on post content. To disable this feature, leave this field blank. No Regex separators are required here. You can add multiple Regex expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Regex On Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="strip_by_regex" id="strip_by_regex3" placeholder="regex expression" class="valuesai3 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Replace the above regex matches with this regex expression. If you want to strip matched content, leave this field blank. No Regex separators are required here. You can add multiple replacement expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Replace Matches From Regex (Content):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="replace_regex" id="replace_regex3" placeholder="regex replacement" class="valuesai3 cr_width_full"></textarea>
                           </td>
                        </tr>
                     </table>
                  </div>
               </div>
               <div class="codemodalfzr-footer">
                  <br/>
                  <h3 class="cr_inline">Aimogen Automatic Post Generator</h3>
                  <span id="aiomatic_ok3" class="codeokfzr cr_inline">OK&nbsp;</span>
                  <br/><br/>
               </div>
            </div>
         </div>


   <div id="mymodalfzr4" class="codemodalfzr">
            <div class="codemodalfzr-content">
               <div class="codemodalfzr-header">
                  <span id="aiomatic_close4" class="codeclosefzr">&times;</span>
                  <h2><span class="cr_color_white"><?php echo esc_html__("AI Product Review", 'aiomatic-automatic-ai-content-writer');?></span> <?php echo esc_html__("Advanced Settings", 'aiomatic-automatic-ai-content-writer');?></h2>
               </div>
               <div class="codemodalfzr-body">
                  <div class="table-responsive">
                     <table class="responsive table cr_main_table_nowr">
                        <tr><td colspan="2">
                           <h3><?php echo esc_html__("Product Source Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                     </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the source of the products to be included in the created article.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Product Source:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select id="product_source4" name="product_source" class="valuesai4 cr_width_full" onchange="productSourceChangedReview();">
                              <option value="amazon" selected><?php echo esc_html__("Amazon", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="clickbank"><?php echo esc_html__("ClickBank", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>  
                           </td>
                        </tr>
                     <tr><td colspan="2">
                           <h3><?php echo esc_html__("AI Assistant Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                     </td></tr>
                     <tr>
                        <td class="cr_min_width_200">
                              <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                 <div class="bws_hidden_help_text cr_min_260px">
                                    <?php
                                       echo esc_html__("Select the AI Assistant to use for content creation. This will disable the ability to select AI models, as the models assisgned to the assistant will be used for content creation.", 'aiomatic-automatic-ai-content-writer');
                                       ?>
                                 </div>
                              </div>
                              <b><?php echo esc_html__("AI Assistant Name:", 'aiomatic-automatic-ai-content-writer');?></b>
                        </td>
                        <td><select id="assistant_id4" name="assistant_id" class="valuesai4 cr_width_full" onchange="assistantSelected('4');">
<?php
if($all_assistants === false)
{
echo '<option val="" selected disabled>' . esc_html__("Only OpenAI API is supported for Assistants API", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
if(count($all_assistants) == 0)
{
echo '<option val="" selected disabled>' . esc_html__("No Assistans added, go to the plugin's 'AI Assistans' menu to add new assistants!", 'aiomatic-automatic-ai-content-writer') . '</option>';
}
else
{
echo '<option value="" selected';
echo '>' . esc_html__("Don't use assistants, use AI models instead", 'aiomatic-automatic-ai-content-writer') . '</option>';
foreach($all_assistants as $myassistant)
{
echo '<option value="' . esc_html($myassistant->ID) .'"';
echo '>' . esc_html($myassistant->post_title);
echo '</option>';
}
}
}
?>
</select>  
                        </td>
                     </tr>
                        <tr class="ai-amazon4"><td colspan="2">
                              <h3><?php echo esc_html__("Amazon Search Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr class="ai-amazon4">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo sprintf( wp_kses( __( "Insert your Amazon Associate ID (Optional). Learn how to get one <a href='%s' target='_blank'>here</a>. Also, you need to sign up for Amazon Affiliate program <a href='%s' target='_blank'>here</a>.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://affiliate-program.amazon.com/gp/advertising/api/detail/main.html', 'https://affiliate-program.amazon.com/assoc_credentials/home');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Amazon Associate ID (Optional):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="affiliate_id" id="affiliate_id4" value="" placeholder="Please insert your Amazon Affiliate ID" class="valuesai4 cr_width_full">  
                           </td>
                        </tr>
                        <tr class="ai-amazon4">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the country where you have registred your affiliate account.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Amazon Target Country:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                        <select id="source4" name="target_country" class="valuesai4">
                        <?php
                           $amaz_countries = aiomatic_get_amazon_codes();
                           foreach ($amaz_countries as $key => $value) {
                              echo '<option value="' . esc_html($key) . '">' . esc_html($value) . '</option>';
                           }
                           ?>
                        </select>  
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none"><td colspan="2">
                              <h3><?php echo esc_html__("ClickBank Search Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter your ClickBank affiliate ID.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("ClickBank Affiliate ID:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="cb_affiliate_id4" name="cb_affiliate_id" class="valuesai4 cr_width_full" placeholder="ClickBank affiliate ID">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to exclude products based on a set of negative keywords?", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Exclude Keywords:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="neg_keywords4" name="neg_keywords" class="valuesai4 cr_width_full" placeholder="Input keywords to exclude">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Limits the results to one of the following categories.", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Item Category:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select id="item_category4" name="item_category" class="valuesai4 cr_width_full">
                           <option value="All" selected><?php echo esc_html__("All", 'aiomatic-automatic-ai-content-writer');?></option>
                           <?php
                              foreach($cat_arr as $id => $name)
                              {
                                    echo '<option value="' . esc_attr($id) . '">' . esc_html($name) . '</option>';
                              }
                              ?>
                           </select>
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Selecting this option displays accounts with one-time products.", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Billing Type: One-time:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="one_time4" name="one_time" class="valuesai4">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Selecting this option displays accounts with recurring billing products.", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Billing Type: Recurring:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="recurring4" name="recurring" class="valuesai4">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Display only vendor accounts with an Affiliate Tools page. An Affiliate Tools page contains resources such as images, tips, keywords, testimonials, and FAQs that can help you promote the account's products more effectively.", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Affiliate Tools Page Available:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="affiliate_tools4" name="affiliate_tools" class="valuesai4">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Display only vendor accounts with a Vendor Spotlight. A Vendor Spotlight provides more detailed information about the vendor and their offerings.", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Vendor Spotlight Page Available:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="spotlight4" name="spotlight" class="valuesai4">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Display only vendor accounts with a mobile HopLink target URL.", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Mobile Hoplink Page Available:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="mobile_hoplink4" name="mobile_hoplink" class="valuesai4">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Selecting this option displays only accounts with physical products.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Shippable Media:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="shipable_only4" name="shipable_only" class="valuesai4">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Selecting this option displays only accounts with PitchPlus Upsell Flows.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("PitchPlus:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="pitch_plus4" name="pitch_plus" class="valuesai4">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("The gravity performance statistic is an approximate, relative measure of how many affiliates have successfully promoted products from an account, with a higher number meaning more conversions. You can specify a minimum and/or a maximum gravity value. To input a maximum, enter '<10', to enter a minimum, enter '>10', to input a range, enter '10-20'.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Item Gravity:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="item_gravity4" name="item_gravity" class="valuesai4 cr_width_full" placeholder="Item gravity">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This number represents the average dollar value of an initial sale, not including rebills, to the affiliate who drives the sale. You can specify a minimum and/or a maximum Initial $/Sale value. To input a maximum, enter '<10', to enter a minimum, enter '>10', to input a range, enter '10-20'.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Item Initial $/sale:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="dollar_sale4" name="dollar_sale" class="valuesai4 cr_width_full" placeholder="Income per sale">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This number represents the average dollar value of a sale, including both initial and rebill payments, to the affiliate who drives the sale. You can specify a minimum and/or a maximum Avg $/Sale. To input a maximum, enter '<10', to enter a minimum, enter '>10', to input a range, enter '10-20'.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Item Avg $/sale:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="dollar_sale_av4" name="dollar_sale_av" class="valuesai4 cr_width_full" placeholder="Avarage income per sale">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This number represents the average total dollar value of a sale, including only rebill payments, to the affiliate who drives the sale. You can specify a minimum and/or a maximum Avg Rebill Total. To input a maximum, enter '<10', to enter a minimum, enter '>10', to input a range, enter '10-20'.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Item Avg Rebill Total:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="rebill_total4" name="rebill_total" class="valuesai4 cr_width_full" placeholder="Total rebill">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This number represents the average affiliate commission percentage for a sale, including both initial and rebill commissions. You can specify a minimum and/or a maximum Avg %/Sale. To input a maximum, enter '<10', to enter a minimum, enter '>10', to input a range, enter '10-20'.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Item Avg %/sale:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="per_sale4" name="per_sale" class="valuesai4 cr_width_full" placeholder="Sales percentage">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This number represents the average affiliate commission percentage for a sale, including only the rebill commission. You can specify a minimum and/or a maximum Avg %/Rebill. To input a maximum, enter '<10', to enter a minimum, enter '>10', to input a range, enter '10-20'.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Item Avg %/rebill:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="per_rebill4" name="per_rebill" class="valuesai4 cr_width_full" placeholder="Rebill percentage">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("The date on which the account was added to the ClickBank marketplace. You can specify a beginning and/or end date. The beginning date cannot be earlier than 120 days ago, and the end date cannot be later than today. To input a maximum, enter '<2018-09-20', to enter a minimum, enter '>2018-09-20', to input a range, enter '2018-09-20=2018-09-30'.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Vendor Activation Time:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" id="activation4" name="activation" class="valuesai4 cr_width_full" placeholder="Vendor activation time">
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td>
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("You can select one or more languages to display only accounts with products in the selected languages.", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Language:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select id="item_language4" name="item_language" class="valuesai4 cr_width_full">
                           <option value="All" selected><?php echo esc_html__("All", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="German"><?php echo esc_html__("German", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="English"><?php echo esc_html__("English", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="Spanish"><?php echo esc_html__("Spanish", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="French"><?php echo esc_html__("French", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="Italian"><?php echo esc_html__("Italian", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="Portuguese"><?php echo esc_html__("Portuguese", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr class="ai-clickbank4 cr_none">
                           <td class="cr_min_width_200">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the type of sorting of the returned results.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Sort Results By:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select id="sort_results_cb4" name="sort_results_cb" class="valuesai4 cr_width_full">
                           <option value="relevance" selected><?php echo esc_html__("Relevance", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="GRAVITY"><?php echo esc_html__("Gravity", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="POPULARITY"><?php echo esc_html__("Popularity", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="AVERAGE_EARNINGS_PER_SALE"><?php echo esc_html__("Average Earnings Per Sale", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>     
                           </td>
                        </tr>
                        <tr><td colspan="2">
                              <h3><?php echo esc_html__("AI Writer Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a list of post sections, one per line. These will be headings of the content. These can also be automatically generated by the plugin. To enable auto generating of sections, leave this field blank. This will set the value of the %%sections%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. If you set a section list here, each created article will have this same list of sections, because of this, use shortcodes or Spintax when defining these static topics or leave this field blank for the plugin to auto generate them!", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Post Sections List (Optional):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_sections_list" id="post_sections_list4" placeholder="Post sections list (one per line)" class="valuesai4 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter the number of sections to create in the article. These will also be set as article headings. You can also set value ranges, example: 5-7. In this case, a random number will be selected in this range. Please use only numeric values in this field. This field will set the value of the %%sections_count%% shortcode.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Number Of Content Sections To Generate:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <input type="text" id="section_count4" name="section_count" placeholder="3-4" class="valuesai4 cr_width_full" value="3-4">  
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select what you want to do with product titles in articles.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Headings To Content As:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" class="valuesai4 cr_width_full" id="sections_role4" name="sections_role">
                           <option value="h2" selected><?php echo esc_html__("h2", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="h3"><?php echo esc_html__("h3", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="b"><?php echo esc_html__("Bold", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="i"><?php echo esc_html__("Italic", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="bi"><?php echo esc_html__("Bold and Italic", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="p"><?php echo esc_html__("Paragraph", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="x"><?php echo esc_html__("Plain Text", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="no"><?php echo esc_html__("Don't Add Sections", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter the number of paragraphs to create for each section. These will also be set as article headings. You can also set value ranges, example: 5-7. In this case, a random number will be selected in this range. Please use only numeric values in this field. This field will set the value of the %%paragraphs_per_section%% shortcode.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Number Of Paragraphs Per Section:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <input type="text" id="paragraph_count4" name="paragraph_count" placeholder="2-3" class="valuesai4 cr_width_full" value="2">  
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add the product image to the article.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Product Images To The Article:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="topic_images4" name="topic_images" class="valuesai4" checked>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you don't want to add the product links directly to headings.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Don't Add Product Links to Headings:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="no_headlink4" name="no_headlink" class="valuesai4">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you would like to add a relevant Social Network Embed to the end of the created article. You can select the source of the social embeds, in the plugin's 'Settings' menu -> 'Bulk Posts' tab -> 'Social Networks To Get Embeds From In AI Created Articles' settings field.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add A Relevant Social Network Embed To The Article:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="topic_videos4" name="topic_videos" class="valuesai4">
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the outro section header. This is optional.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Outro Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="title_outro" id="title_outro4" value="{Experience the Difference|Unlock Your Potential|Elevate Your Lifestyle|Embrace a New Era|Seize the Opportunity|Discover the Power|Transform Your World|Unleash Your True Potential|Embody Excellence|Achieve New Heights|Experience Innovation|Ignite Your Passion|Reveal the Extraordinary}" placeholder="Optional" class="valuesai4 cr_width_full">
                           </td>
                        </tr> 
                        <tr>
                           <td class="hideTOC-1">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add a Table of Contents section to the created post.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Article 'Table Of Contents':", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td class="hideTOC-1">
                           <input type="checkbox" id="enable_toc4" name="enable_toc" class="valuesai4">
                           </td>
                        </tr> 
                        <tr>
                           <td class="hideTOC-1">
                              <div>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the Table of Contents section header. Default is: Table of Contents", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article 'Table Of Contents' Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td class="hideTOC-1">
                           <input type="text" name="title_toc" id="title_toc4" value="Table of Contents" placeholder="Table of Contents" class="valuesai4 cr_width_full">
                           </td>
                        </tr> 
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add a Customer Reviews Analysis section to the created post. To enable Customer Reviews Analysis for articles, be sure to add a prompt also in the 'Article Customer Reviews Analysis Prompt' settings field from below.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Article 'Customer Reviews Analysis' Section:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="enable_reviews4" name="enable_reviews" class="valuesai4">
                           </td>
                        </tr> 
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the Customer Reviews Analysis section header. Default is: Customer Reviews Analysis", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article 'Customer Reviews Analysis' Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="title_reviews" id="title_reviews4" value="Customer Reviews Analysis" placeholder="Customer Reviews Analysis" class="valuesai4 cr_width_full">
                           </td>
                        </tr> 
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add a Pros & Cons section to the created post. To enable Pros & Cons for articles, be sure to add a prompt also in the 'Article Pros & Cons Prompt' settings field from below.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Article 'Pros & Cons' Section:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="enable_proscons4" name="enable_proscons" class="valuesai4">
                           </td>
                        </tr> 
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the Pros & Cons section header. Default is: Pros & Cons", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article 'Pros & Cons' Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="title_proscons" id="title_proscons4" value="Pros & Cons" placeholder="Pros & Cons" class="valuesai4 cr_width_full">
                           </td>
                        </tr> 
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select if you want to add a Q&A section to the created post. To enable Q&A for articles, be sure to add a prompt also in the 'Article Q&A Prompt' settings field from below.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Article 'Q&A' Section:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="enable_qa4" name="enable_qa" class="valuesai4">
                           </td>
                        </tr> 
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the text of the Q&A section header. Default is: Q&A", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article 'Q&A' Section Header Text:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="title_qa" id="title_qa4" value="Q&A" placeholder="Q&A" class="valuesai4 cr_width_full">
                           </td>
                        </tr> 
                        <tr><td colspan="2">
                              <h4><?php echo esc_html__("Content Parameters", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the language of the created content. This will set the value of the %%language%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Content Language:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="content_language4" name="content_language" type="text" list="languages5" placeholder="Created content language" class="valuesai4 coderevolution_gutenberg_input" value="English"/>
<datalist id="languages5">
<?php
foreach($aiomatic_language_names as $ln)
{
echo '<option>' . esc_html($ln) . '</option>';
}
?>
</datalist>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the writing style of the created content. This will set the value of the %%writing_style%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Writing Style:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="writing_style4" name="writing_style" type="text" placeholder="Created content writing style" list="writing_styles5" class="valuesai4 coderevolution_gutenberg_input" value="Creative"/>
                           <datalist id="writing_styles5">
<option>Informative</option>
<option>Academic</option>
<option>Descriptive</option>
<option>Detailed</option>
<option>Dramative</option>
<option>Fiction</option>
<option>Expository</option>
<option>Historical</option>
<option>Dialogue</option>
<option>Creative</option>
<option>Critical</option>
<option>Narrative</option>
<option>Persuasive</option>
<option>Reflective</option>
<option>Argumentative</option>
<option>Analytical</option>
<option>Blog</option>
<option>News</option>
<option>Casual</option>
<option>Pastoral</option>
<option>Personal</option>
<option>Poetic</option>
<option>Satirical</option>
<option>Sensory</option>
<option>Articulate</option>
<option>Monologue</option>
<option>Colloquial</option>
<option>Comparative</option>
<option>Concise</option>
<option>Biographical</option>
<option>Anecdotal</option>
<option>Evaluative</option>
<option>Letter</option>
<option>Lyrical</option>
<option>Simple</option>
<option>Vivid</option>
<option>Journalistic</option>
<option>Technical</option>
<option>Direct</option>
<option>Emotional</option>
<option>Metaphorical</option>
<option>Objective</option>
<option>Rhetorical</option>
<option>Theoretical</option>
<option>Business</option>
<option>Report</option>
<option>Research</option>
</datalist>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the writing tone of the created content. This will set the value of the %%writing_tone%% shortcode, which can be used in prompts below. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Writing Tone:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="writing_tone4" name="writing_tone" type="text" list="writing_tones5" placeholder="Created content writing tone" class="valuesai4 coderevolution_gutenberg_input" value="Neutral"/>
                           <datalist id="writing_tones5">
<option>Neutral</option>
<option>Formal</option>
<option>Assertive</option>
<option>Cheerful</option>
<option>Humorous</option>
<option>Informal</option>
<option>Inspirational</option>
<option>Professional</option>
<option>Emotional</option>
<option>Persuasive</option>
<option>Supportive</option>
<option>Sarcastic</option>
<option>Condescending</option>
<option>Skeptical</option>
<option>Narrative</option>
<option>Journalistic</option>
<option>Conversational</option>
<option>Factual</option>
<option>Friendly</option>
<option>Polite</option>
<option>Scientific</option>
<option>Sensitive</option>
<option>Sincere</option>
<option>Curious</option>
<option>Dissapointed</option>
<option>Encouraging</option>
<option>Optimistic</option>
<option>Surprised</option>
<option>Worried</option>
<option>Confident</option>
<option>Authoritative</option>
<option>Nostalgic</option>
<option>Sympathetic</option>
<option>Suspenseful</option>
<option>Romantic</option>
<option>Serious</option>
</datalist>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the point of view of the article.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Point Of View:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" class="cr_width_full valuesai4" name="point_of_view" id="point_of_view4">
                           <option value="First Person Singular (I, me, my, mine)"><?php echo esc_html__("First Person Singular (I, me, my, mine)", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="First Person Plural (we, us, our, ours)" selected><?php echo esc_html__("First Person Plural (we, us, our, ours)", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="Second Person Singular (you, your, yours)"><?php echo esc_html__("Second Person Singular (you, your, yours)", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="Second Person Plural (you [plural], y'all, you guys)"><?php echo esc_html__("Second Person Plural (you [plural], y'all, you guys)", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="Third Person Singular (he, she, it)"><?php echo esc_html__("Third Person Singular (he, she, it)", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="Third Person Plural (they, them, theirs, themselves)"><?php echo esc_html__("Third Person Plural (they, them, theirs, themselves)", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr><td colspan="2">
                              <h4><?php echo esc_html__("Prompts", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Post Title. You can use the following shortcodes: %%product_title%%, %%product_description%%, %%aff_url%%, %%product_author%%, %%offer_price%%, %%product_price%%, %%product_list_price%%, %%product_brand%%, %%product_isbn%%, %%product_upc%%, %%product_reviews%%, %%price_numeric%%, %%price_currency%%, %%product_asin%%, %%cart_url%%, %%list_price_numeric%%, %%product_imgs%%, %%search_keywords%%, %%language%%, %%writing_style%%, %%point_of_view%%, %%writing_tone%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. If you have access to the Amazon API, you can set it up in the plugin and get access to the following advanced shortcodes also: %%product_score%%, %%product_edition%%, %%product_language%%, %%product_pages_count%%, %%product_publication_date%%, %%product_contributors%%, %%product_manufacturer%%, %%product_binding%%, %%product_product_group%%, %%product_rating%%, %%product_ean%%, %%product_part_no%%, %%product_model%%, %%product_warranty%%, %%product_color%%, %%product_is_adult%%, %%product_dimensions%%, %%product_date%%, %%product_size%%, %%product_unit_count%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Title Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="title_prompt" id="title_prompt4" placeholder="Enter your title prompts, one per line" class="valuesai4 cr_width_full">Write a title for a product review blog post of the following product: "%%product_title%%", in %%language%% language. Style: %%writing_style%%. Tone: %%writing_tone%%. Point of View: %%point_of_view%%. The title must be between 40 and 60 characters. The description of the product is: "%%product_description%%".</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the title generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Title Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_title_model4" name="topic_title_model" class="hideAssistant4 valuesai4 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the intro of the article. You can use the following shortcodes: %%product_title%%, %%product_description%%, %%aff_url%%, %%product_author%%, %%offer_price%%, %%product_price%%, %%product_list_price%%, %%product_brand%%, %%product_isbn%%, %%product_upc%%, %%product_reviews%%, %%price_numeric%%, %%price_currency%%, %%product_asin%%, %%cart_url%%, %%list_price_numeric%%, %%product_imgs%%, %%search_keywords%%, %%language%%, %%writing_style%%, %%point_of_view%%, %%writing_tone%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. If you have access to the Amazon API, you can set it up in the plugin and get access to the following advanced shortcodes also: %%product_score%%, %%product_edition%%, %%product_language%%, %%product_pages_count%%, %%product_publication_date%%, %%product_contributors%%, %%product_manufacturer%%, %%product_binding%%, %%product_product_group%%, %%product_rating%%, %%product_ean%%, %%product_part_no%%, %%product_model%%, %%product_warranty%%, %%product_color%%, %%product_is_adult%%, %%product_dimensions%%, %%product_date%%, %%product_size%%, %%product_unit_count%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Intro Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="intro_prompt" id="intro_prompt4" placeholder="Enter your intro prompts, one per line" class="valuesai4 cr_width_full">Write an introduction for a product review blog post of the following product: "%%product_title%%". The post is reviewing the product "%%product_title%%", in %%language%% language. Style: %%writing_style%%. Tone: %%writing_tone%%. Point of View: %%point_of_view%%. Write as if you had first-hand experience with the product you are describing. The description of the product is: "%%product_description%%".</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the intro generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Intro Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_intro_model4" name="topic_intro_model" class="hideAssistant4 valuesai4 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the main Sections of the article. These will be set also as headings in the article. You can use the following shortcodes: %%product_title%%, %%product_description%%, %%aff_url%%, %%product_author%%, %%offer_price%%, %%product_price%%, %%product_list_price%%, %%product_brand%%, %%product_isbn%%, %%product_upc%%, %%product_reviews%%, %%price_numeric%%, %%price_currency%%, %%product_asin%%, %%cart_url%%, %%list_price_numeric%%, %%product_imgs%%, %%sections_count%%, %%search_keywords%%, %%language%%, %%writing_style%%, %%point_of_view%%, %%writing_tone%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. If you have access to the Amazon API, you can set it up in the plugin and get access to the following advanced shortcodes also: %%product_score%%, %%product_edition%%, %%product_language%%, %%product_pages_count%%, %%product_publication_date%%, %%product_contributors%%, %%product_manufacturer%%, %%product_binding%%, %%product_product_group%%, %%product_rating%%, %%product_ean%%, %%product_part_no%%, %%product_model%%, %%product_warranty%%, %%product_color%%, %%product_is_adult%%, %%product_dimensions%%, %%product_date%%, %%product_size%%, %%product_unit_count%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Sections Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="sections_prompt" id="sections_prompt4" placeholder="Enter your sections prompts, one per line" class="valuesai4 cr_width_full">Write %%sections_count%% consecutive headings for a product review article of the "%%product_title%%" product, that starts with an overview, highlights specific features and aspects of the product, provides detailed insights and specific recommendations. The headings should be written in %%language%%, following a %%writing_style%% style and a %%writing_tone%% tone. Point of view: %%point_of_view%%. Don't add numbers to the headings, hyphens or any types of quotes. Write as if you had first-hand experience with the product you are describing. Return only the headings list, nothing else.</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the sections generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Sections Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_sections_model4" name="topic_sections_model" class="hideAssistant4 valuesai4 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Content of the article, which will be applied to each section heading generated by the plugin (or entered manually) or to the entire content (depending how you select using the 'Use the Above Content Prompt To Create The Entire Article' checkbox). You can use the following shortcodes: %current_section%%, %%product_title%%, %%product_description%%, %%aff_url%%, %%product_author%%, %%offer_price%%, %%product_price%%, %%product_list_price%%, %%product_brand%%, %%product_isbn%%, %%product_upc%%, %%product_reviews%%, %%price_numeric%%, %%price_currency%%, %%product_asin%%, %%cart_url%%, %%list_price_numeric%%, %%product_imgs%%, %%search_keywords%%, %%language%%, %%writing_style%%, %%point_of_view%%, %%writing_tone%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. If you have access to the Amazon API, you can set it up in the plugin and get access to the following advanced shortcodes also: %%product_score%%, %%product_edition%%, %%product_language%%, %%product_pages_count%%, %%product_publication_date%%, %%product_contributors%%, %%product_manufacturer%%, %%product_binding%%, %%product_product_group%%, %%product_rating%%, %%product_ean%%, %%product_part_no%%, %%product_model%%, %%product_warranty%%, %%product_color%%, %%product_is_adult%%, %%product_dimensions%%, %%product_date%%, %%product_size%%, %%product_unit_count%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Content Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="3" cols="70" name="content_prompt" id="content_prompt4" placeholder="Enter your content prompt" class="valuesai4 cr_width_full">Write the content of a product review post, for the following section heading: "%%current_section%%". The post is reviewing the product "%%product_title%%" in %%language%%. Don't repeat the product title in the created content, also don't be repetitive in general. Don't add an intro or outro. Write %%paragraphs_per_section%% paragraphs in the section. Use HTML for formatting, include unnumbered lists and bold. When applicable, add also HTML tables with WordPress styling (you can use WordPress table classes). If added, table data must be relevant, creative, short and simple. Writing Style: %%writing_style%%. Tone: %%writing_tone%%. Point Of View: %%point_of_view%%. Extract content from the following product description: "%%product_description%%".</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the content generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Content Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_content_model4" name="topic_content_model" class="hideAssistant4 valuesai4 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Customer Reviews Analysis section of the article. You can use the following shortcodes: %%product_title%%, %%product_description%%, %%aff_url%%, %%product_author%%, %%offer_price%%, %%product_price%%, %%product_list_price%%, %%product_brand%%, %%product_isbn%%, %%product_upc%%, %%product_reviews%%, %%price_numeric%%, %%price_currency%%, %%product_asin%%, %%cart_url%%, %%list_price_numeric%%, %%product_imgs%%, %%search_keywords%%, %%language%%, %%writing_style%%, %%point_of_view%%, %%writing_tone%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. If you have access to the Amazon API, you can set it up in the plugin and get access to the following advanced shortcodes also: %%product_score%%, %%product_edition%%, %%product_language%%, %%product_pages_count%%, %%product_publication_date%%, %%product_contributors%%, %%product_manufacturer%%, %%product_binding%%, %%product_product_group%%, %%product_rating%%, %%product_ean%%, %%product_part_no%%, %%product_model%%, %%product_warranty%%, %%product_color%%, %%product_is_adult%%, %%product_dimensions%%, %%product_date%%, %%product_size%%, %%product_unit_count%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Customer Reviews Analysis Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="reviews_prompt" id="reviews_prompt4" placeholder="Enter your Customer Reviews Analysis prompts, one per line" class="valuesai4 cr_width_full">Write the content of a "Customer Reviews Analysis" section for a product review blog post for the following product: "%%product_title%%". The title of the blog post is: "%%post_title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. Point Of View: %%point_of_view%%. Use HTML for formatting. When applicable, add also HTML tables with WordPress styling (you can use WordPress table classes). If added, table data must be relevant, creative, short and simple. List of customer reviews: "%%product_reviews%%". </textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the Customer Reviews Analysis generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Customer Reviews Analysis Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_reviews_model4" name="topic_reviews_model" class="hideAssistant4 valuesai4 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Pros & Cons section of the article. You can use the following shortcodes: %%product_title%%, %%product_description%%, %%aff_url%%, %%product_author%%, %%offer_price%%, %%product_price%%, %%product_list_price%%, %%product_brand%%, %%product_isbn%%, %%product_upc%%, %%product_reviews%%, %%price_numeric%%, %%price_currency%%, %%product_asin%%, %%cart_url%%, %%list_price_numeric%%, %%product_imgs%%, %%search_keywords%%, %%language%%, %%writing_style%%, %%point_of_view%%, %%writing_tone%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. If you have access to the Amazon API, you can set it up in the plugin and get access to the following advanced shortcodes also: %%product_score%%, %%product_edition%%, %%product_language%%, %%product_pages_count%%, %%product_publication_date%%, %%product_contributors%%, %%product_manufacturer%%, %%product_binding%%, %%product_product_group%%, %%product_rating%%, %%product_ean%%, %%product_part_no%%, %%product_model%%, %%product_warranty%%, %%product_color%%, %%product_is_adult%%, %%product_dimensions%%, %%product_date%%, %%product_size%%, %%product_unit_count%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Pros & Cons Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="proscons_prompt" id="proscons_prompt4" placeholder="Enter your Pros & Cons prompts, one per line" class="valuesai4 cr_width_full">Write the content of a "Pros & Cons" section for a product review blog post for the following product: "%%product_title%%". The title of the blog post is: "%%post_title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. Point Of View: %%point_of_view%%.Use HTML for formatting. When applicable, add also HTML tables with WordPress styling (you can use WordPress table classes). If added, table data must be relevant, creative, short and simple. Product description: "%%product_description%%". </textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the Pros & Cons generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Pros & Cons Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_proscons_model4" name="topic_proscons_model" class="hideAssistant4 valuesai4 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the Q&A of the article. You can use the following shortcodes: %%product_title%%, %%product_description%%, %%aff_url%%, %%product_author%%, %%offer_price%%, %%product_price%%, %%product_list_price%%, %%product_brand%%, %%product_isbn%%, %%product_upc%%, %%product_reviews%%, %%price_numeric%%, %%price_currency%%, %%product_asin%%, %%cart_url%%, %%list_price_numeric%%, %%product_imgs%%, %%search_keywords%%, %%language%%, %%writing_style%%, %%point_of_view%%, %%writing_tone%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. If you have access to the Amazon API, you can set it up in the plugin and get access to the following advanced shortcodes also: %%product_score%%, %%product_edition%%, %%product_language%%, %%product_pages_count%%, %%product_publication_date%%, %%product_contributors%%, %%product_manufacturer%%, %%product_binding%%, %%product_product_group%%, %%product_rating%%, %%product_ean%%, %%product_part_no%%, %%product_model%%, %%product_warranty%%, %%product_color%%, %%product_is_adult%%, %%product_dimensions%%, %%product_date%%, %%product_size%%, %%product_unit_count%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Q&A Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="qa_prompt" id="qa_prompt4" placeholder="Enter your Q&A prompts, one per line" class="valuesai4 cr_width_full">Write the content of a Q&A section for a product review blog post for the following product: "%%product_title%%". The title of the blog post is: "%%post_title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. Point Of View: %%point_of_view%%. Product description: "%%product_description%%".</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the Q&A generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Q&A Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_qa_model4" name="topic_qa_model" class="hideAssistant4 valuesai4 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the outro of the article. You can use the following shortcodes: %%product_title%%, %%product_description%%, %%aff_url%%, %%product_author%%, %%offer_price%%, %%product_price%%, %%product_list_price%%, %%product_brand%%, %%product_isbn%%, %%product_upc%%, %%product_reviews%%, %%price_numeric%%, %%price_currency%%, %%product_asin%%, %%cart_url%%, %%list_price_numeric%%, %%product_imgs%%, %%search_keywords%%, %%language%%, %%writing_style%%, %%point_of_view%%, %%writing_tone%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. If you have access to the Amazon API, you can set it up in the plugin and get access to the following advanced shortcodes also: %%product_score%%, %%product_edition%%, %%product_language%%, %%product_pages_count%%, %%product_publication_date%%, %%product_contributors%%, %%product_manufacturer%%, %%product_binding%%, %%product_product_group%%, %%product_rating%%, %%product_ean%%, %%product_part_no%%, %%product_model%%, %%product_warranty%%, %%product_color%%, %%product_is_adult%%, %%product_dimensions%%, %%product_date%%, %%product_size%%, %%product_unit_count%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Outro Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="outro_prompt" id="outro_prompt4" placeholder="Enter your outro prompts, one per line" class="valuesai4 cr_width_full">Write an outro for a product review blog post, for the product: "%%product_title%%". The post has the following title: "%%post_title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. Point Of View: %%point_of_view%%. Product description: "%%product_description%%". Add also an engaging final call to action link, in a clickable HTML format (don't use markdown language), leading to the link of the product: "%%aff_url%%".</textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the outro generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Outro Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_outro_model4" name="topic_outro_model" class="hideAssistant4 valuesai4 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Prompt to be used for the excerpt of the article. You can use the following shortcodes: %%product_title%%, %%product_description%%, %%aff_url%%, %%product_author%%, %%offer_price%%, %%product_price%%, %%product_list_price%%, %%product_brand%%, %%product_isbn%%, %%product_upc%%, %%product_reviews%%, %%price_numeric%%, %%price_currency%%, %%product_asin%%, %%cart_url%%, %%list_price_numeric%%, %%product_imgs%%, %%search_keywords%%, %%language%%, %%writing_style%%, %%point_of_view%%, %%writing_tone%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. If you have access to the Amazon API, you can set it up in the plugin and get access to the following advanced shortcodes also: %%product_score%%, %%product_edition%%, %%product_language%%, %%product_pages_count%%, %%product_publication_date%%, %%product_contributors%%, %%product_manufacturer%%, %%product_binding%%, %%product_product_group%%, %%product_rating%%, %%product_ean%%, %%product_part_no%%, %%product_model%%, %%product_warranty%%, %%product_color%%, %%product_is_adult%%, %%product_dimensions%%, %%product_date%%, %%product_size%%, %%product_unit_count%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Excerpt Prompt:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="excerpt_prompt" id="excerpt_prompt4" placeholder="Enter your excerpt prompts, one per line" class="valuesai4 cr_width_full">Write a short excerpt for a product review blog post, for the product: "%%product_title%%". The post has the following title: "%%post_title%%", in %%language%%. Style: %%writing_style%%. Tone: %%writing_tone%%. Point Of View: %%point_of_view%%. The excerpt must be between 100 and 150 words. </textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI Model to be used for the excerpt generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Model For Excerpt Generator:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="topic_excerpt_model4" name="topic_excerpt_model" class="hideAssistant4 valuesai4 cr_width_full">
                           <?php
foreach($all_models as $modelx)
{
echo '<option value="' . esc_html($modelx) .'"';
echo '>' . esc_html($modelx) . esc_html(aiomatic_get_model_provider($modelx)) . '</option>';
}
?>
                           </select>   
                           </td>
                        </tr>
                        <tr><td colspan="2">
                              <h4><?php echo esc_html__("Advanced Prompting Options", 'aiomatic-automatic-ai-content-writer');?>:</h4>
                        </td></tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Run regex on prompts. To disable this feature, leave this field blank. No Regex separators are required here. You can add multiple Regex expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Regex On Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="strip_by_regex_prompts" id="strip_by_regex_prompts4" placeholder="regex expression" class="valuesai4 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Replace the above regex matches with this regex expression. If you want to strip matched content, leave this field blank. No Regex separators are required here. You can add multiple replacement expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Replace Matches From Regex (Prompts):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="replace_regex_prompts" id="replace_regex_prompts4" placeholder="regex replacement" class="valuesai4 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select on which prompts do you want to run the above Regex. Possible values are (or any of their combinations): title, intro, sections, content, reviews, proscons, qa, outro, excerpt", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Above Regex On Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input id="run_regex_on4" name="run_regex_on" type="text" list="run_regex_on_list5" class="valuesai4 coderevolution_gutenberg_input" value="content"/>
<datalist id="run_regex_on_list5">
<option value="title">title</option>
<option value="intro">intro</option>
<option value="sections">sections</option>
<option value="content">content</option>
<option value="qa">Q&A</option>
<option value="outro">outro</option>
<option value="excerpt">excerpt</option>
</datalist> 
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Global Prompt Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This will be prepended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%point_of_view%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Prepend Text To All Textual AI Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="global_prepend" id="global_prepend4" placeholder="Global prompt prepend text" class="valuesai4 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("This will be appended to each prompt sent by the plugin to the AI writer. You can use the following shortcodes: %%topic%%, %%language%%, %%writing_style%%, %%point_of_view%%, %%writing_tone%%, %%title%%, %%random_sentence%%, %%random_sentence2%%, %%post_original_title%%, %%blog_title%% - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Append Text To All Textual AI Prompts:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="global_append" id="global_append4" placeholder="Global prompt append text" class="valuesai4 cr_width_full"></textarea>
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Automatic Linking Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the linking method to use in posts.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Automatic Linking Type:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" class="valuesai4 cr_width_full" id="link_type4" onchange="hideLinks('');" name="link_type">
                           <option value="disabled" selected><?php echo esc_html__("Disabled", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="internal"><?php echo esc_html__("Internal Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="manual"><?php echo esc_html__("Manual Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="serp"><?php echo esc_html__("Related SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="mixed"><?php echo esc_html__("Internal + Manual Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="intserp"><?php echo esc_html__("Internal & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="manserp"><?php echo esc_html__("Manual & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           <option value="intmanserp"><?php echo esc_html__("Internal & Manual & SERP Links", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>   
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of automatic links to add to created posts. You can also define custom ranges, like: 3-5. Please note that this feature will work best if you already have a considerable number of posts published on your site, which will be used for internal linking.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Number Of Automatic Links To Add To The Post Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="max_links" id="max_links4" placeholder="3-5" class="valuesai4 cr_width_full">
                           </td>
                        </tr>
                        <tr class="hidelinks">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a manual list of links, where the plugin will create links.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Manual List Of URLs (One Per Line):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" cols="70" name="link_list" id="link_list4" placeholder="URL list (one per line)" class="valuesai4 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr class="hidelinks">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to add nofollow attribute to manually entered, external links?", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Add Nofollow Attribute To External Links:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="link_nofollow4" name="link_nofollow" class="valuesai4">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the post types where to create automatic links in posts. You can also add a comma separated list of multiple post types.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Post Types Where To Generate Automatic Links:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="text" name="link_post_types" id="link_post_types4" placeholder="post" class="valuesai4 cr_width_full">
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Advanced AI Text Generator Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. Note that in this value the number of tokens sent to the API as an article prompt will also be counted. The maximum amount which can be set is 4000. For other models, the maximum is 2048.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Total Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_tokens" id="max_tokens4" value="" placeholder="2048" class="valuesai4 cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of prompt API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. This defines how much content does the API receive each time you call it. If the API gets more initial data, better quality results will be expected. The maximum amount which can be set is 1000.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Prompt Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_seed_tokens" id="max_seed_tokens4" value="" placeholder="1000" class="valuesai4 cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set the maximum number of continue API tokens to use with each request. This will define the length of the resulting API response. Each token usually consists of approximately 4 characters. This defines how much content does the API receive each time you call it. If the API gets more initial data, better quality results will be expected. The maximum amount which can be set is 500.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Maximum Continue Token Count To Use Per API Request:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="1" name="max_continue_tokens" id="max_continue_tokens4" value="" placeholder="500" class="valuesai4 cr_width_full">
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("What sampling temperature to use. Higher values means the model will take more risks. Try 0.9 for more creative applications, and 0 (argmax sampling) for ones with a well-defined answer. We generally recommend altering this or top_p but not both.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Temperature:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" step="0.01" max="2" name="temperature" id="temperature4" value="" placeholder="1" class="valuesai4 cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("An alternative to sampling with temperature, called nucleus sampling, where the model considers the results of the tokens with top_p probability mass. So 0.1 means only the tokens comprising the top 10% probability mass are considered. We generally recommend altering this or temperature but not both.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Top_p:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" max="1" step="0.01" name="top_p" id="top_p4" value="" placeholder="1" class="valuesai4 cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on whether they appear in the text so far, increasing the model's likelihood to talk about new topics.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Presence Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="-2" step="0.01" max="2" name="presence_penalty" id="presence_penalty4" value="" placeholder="0" class="valuesai4 cr_width_full">
                           </td>
                        </tr><tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Number between -2.0 and 2.0. Positive values penalize new tokens based on their existing frequency in the text so far, decreasing the model's likelihood to repeat the same line verbatim.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Frequency Penalty:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="number" min="0" max="2" step="0.01" name="frequency_penalty" id="frequency_penalty4" value="" placeholder="0" class="valuesai4 cr_width_full">
                           </td>
                        </tr>
                     <tr><td colspan="2">
                              <h3><?php echo esc_html__("Image Generator Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the search query repetition mode, when searching royalty free images.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Search Query Repetition:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="search_query_repetition4" name="search_query_repetition" class="valuesai4 cr_width_full">
                              <option value="0" selected><?php echo esc_html__("Use Different Search Queries For Images", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1"><?php echo esc_html__("Use The Same Search Query For Images", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Do you want to enable the AI Image Generator and to replace Royalty Free Images with AI generated images?", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Article Image Source:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="enable_ai_images4" onchange="hideImage('4');" name="enable_ai_images" class="valuesai4 cr_width_full">
                              <option value="0" selected><?php echo esc_html__("Royalty Free", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1"><?php echo esc_html__("OpenAI/AiomaticAPI", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              if (isset($aiomatic_Main_Settings['stability_app_id']) && trim($aiomatic_Main_Settings['stability_app_id']) != '')
                              {
                              ?>
                              <option value="2"><?php echo esc_html__("Stability.AI", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['midjourney_app_id']) && trim($aiomatic_Main_Settings['midjourney_app_id']) != '')
                              {
                              ?>
                              <option value="4"><?php echo esc_html__("Midjourney", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['replicate_app_id']) && trim($aiomatic_Main_Settings['replicate_app_id']) != '')
                              {
                              ?>
                              <option value="5"><?php echo esc_html__("Replicate", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['ideogram_app_id']) && trim($aiomatic_Main_Settings['ideogram_app_id']) != '')
                              {
                              ?>
                              <option value="6"><?php echo esc_html__("Ideogram", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['cloudflare_worker_url']) && trim($aiomatic_Main_Settings['cloudflare_worker_url']) != '' && isset($aiomatic_Main_Settings['cloudflare_worker_secret']) && trim($aiomatic_Main_Settings['cloudflare_worker_secret']) != '')
                              {
                              ?>
                              <option value="8"><?php echo esc_html__("Cloudflare Workers", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              if (isset($aiomatic_Main_Settings['app_id_google']) && trim($aiomatic_Main_Settings['app_id_google']) != '')
                              {
                              ?>
                              <option value="7"><?php echo esc_html__("Google", 'aiomatic-automatic-ai-content-writer');?></option>
                              <?php
                              }
                              ?>
                              <option value="9"><?php echo esc_html__("Random From Media Library", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>
                           </td>
                        </tr>
                        <tr class="hideImg4 cr_none">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Set list of prompt commands (one on each line) you want to send to the AI image generator. This command can be any given task or order, based on which, it will generate images. You can use the following shortcodes: %%post_title%%, %%post_content%%, %%post_content_plain_text%%, %%post_excerpt%%, %%post_cats%%, %%post_tags%%, %%featured_image%%, %%blog_title%%, %%author_name%%, %%current_date_time%%, %%post_link%%, %%random_sentence%%, %%random_sentence2%%. Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You can also add here a link to a .txt file, where you can add multiple prompts (one per line) and the plugin will select a random one at each run. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators. You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          echo '&nbsp;' . sprintf( wp_kses( __( "Please check some tips and tricks about writing prompt commands, <a href='%s' target='_blank'>here</a>. The [aicontent] shortcode is able to be used also here.", 'aiomatic-automatic-ai-content-writer'), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), 'https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-image-generating-for-openai-dall-e-api/' );
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Prompt For The AI Image Generator:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/how-to-create-a-good-seed-prompt-command-for-aiomatic-image-generating-for-openai-dall-e-api/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="ai_command_image" id="ai_command_image4" placeholder="Please insert a command for the AI image generator" class="valuesai4 cr_width_full">A high detail image with no text of: "%%post_title%%"</textarea>
                           </td>
                        </tr>
                        <tr class="hideDalle4 cr_none">
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the AI model you wish to use for image the image generator.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("AI Image Model:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <select autocomplete="off" id="image_model4" name="image_model" class="valuesai4 cr_width_full">
<?php
foreach(AIMOGEN_DALLE_IMAGE_MODELS as $modelx)
{
   echo '<option value="' . esc_html($modelx) .'"';
   if ($modelx == AIMOGEN_DEFAULT_IMAGE_MODEL) { echo ' selected'; }
   echo '>' . esc_html($modelx) . '</option>';
}
?>
                           </select>
                           </td>
                        </tr>
                        <tr class="hideImg4 cr_none">
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Select the size of the generated image.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Generated Image Size:", 'aiomatic-automatic-ai-content-writer');?></b>   
                           </td>
                           <td class="cr_min_width_200">
                           <select autocomplete="off" id="model4" name="image_size" class="valuesai4 cr_width_full">
                              <option value="256x256"><?php echo esc_html__("256x256", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="512x512"><?php echo esc_html__("512x512", 'aiomatic-automatic-ai-content-writer');?></option>
                              <option value="1024x1024" selected><?php echo esc_html__("1024x1024", 'aiomatic-automatic-ai-content-writer');?></option>
                           </select>  
                           </td>
                        </tr>
                        <tr><td colspan="2">
                              <h3><?php echo esc_html__("Posting Options", 'aiomatic-automatic-ai-content-writer');?>:</h3>
                        </td></tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a HTML text that should be prepended to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%product_title%%, %%product_description%%, %%aff_url%%, %%product_author%%, %%offer_price%%, %%product_price%%, %%product_list_price%%, %%product_brand%%, %%product_isbn%%, %%product_upc%%, %%product_reviews%%, %%price_numeric%%, %%price_currency%%, %%product_asin%%, %%cart_url%%, %%list_price_numeric%%, %%product_imgs%%, %%search_keywords%%, %%language%%, %%writing_style%%, %%point_of_view%%, %%writing_tone%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("HTML Text To Prepend To AI Created Content:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_prepend" id="post_prepend4" placeholder="HTML content to prepend to the AI generated content" class="valuesai4 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Enter a HTML text that should be appended to the AI generated content in each created post. You can use the following shortcodes: %%custom_html%%, %%custom_html2%%, %%product_title%%, %%product_description%%, %%aff_url%%, %%product_author%%, %%offer_price%%, %%product_price%%, %%product_list_price%%, %%product_brand%%, %%product_isbn%%, %%product_upc%%, %%product_reviews%%, %%price_numeric%%, %%price_currency%%, %%product_asin%%, %%cart_url%%, %%list_price_numeric%%, %%product_imgs%%, %%search_keywords%%, %%language%%, %%writing_style%%, %%point_of_view%%, %%writing_tone%%, %%random_sentence%%, %%random_sentence2%%, %%blog_title%%, %%random_image[keyword]%%, %%random_image_url[keyword]%%, %%random_video[keyword]%%, %%royalty_free_image_attribution%% - you can also use an optional parameter in the random_image and random_video shortcodes, which will add a percentage chance for the media to appear or not - example: %%random_video[keyword][60]%% - a video will appear in 60% of cases, in the rest of 40%, nothing will be returned by the shortcode - Update: %%related_questions_KEYWORD%% is also supported, to get a list of PAA questions for the KEYWORD you want to use. Update: nested shortcodes also supported (shortcodes generated by rules from other plugins). You will also be able to use the custom shortcodes defined in the 'Custom Shortcode Creator' feature from the rule settings - this will allow you to create partially or fully AI generated prompts which will be used for the content generators.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("HTML Text To Append To AI Created Content:", 'aiomatic-automatic-ai-content-writer');?></b>&nbsp;<b><a href="https://coderevolution.ro/knowledge-base/faq/post-template-reference-advanced-usage/" target="_blank">&#9432;</a></b>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="post_append" id="post_append4" placeholder="HTML content to append to the AI generated content" class="valuesai4 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td class="cr_min_width_200">
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Custom AI generated content shortcode creator. If you wish to create content from multiple AI prompts, and use them in post content/post custom fields/taxonomies, you can configure this from here. Also, these shortcodes will be able to be used in custom fields or custom taxonomies which the plugin will create. Syntax for this field: shortcode_name => AI_MODEL_TO_USE @@ TEXTUAL_PROMPT_TO_USE (to specify multiple shortcodes and crawling values, separate them by a new line. Example: my_custom_shortcode => gpt-5-mini @@ Write a short poem. Afterwards, you can use shortcodes in any settings field that supports shortcodes (ex: 'HTML Text To Append To AI Created Content' settings field), like this: %%my_custom_shortcode%%. Official format is %%name_of_custom_shortcode%%", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Custom Shortcode Creator (Optional):", 'aiomatic-automatic-ai-content-writer');?></b><span class="tool" data-tip="Supported models: <?php echo esc_html(implode(',', aiomatic_get_all_models()));?>">&nbsp;&#9432;</span>
                           </td>
                           <td>
                           <textarea rows="2" cols="70" name="custom_shortcodes" id="custom_shortcodes4" placeholder="shortcode_name => AI_MODEL @@ AI_PROMPT" class="valuesai4 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("The AI writer might add the title of the post to the created post content. Check this checkbox if you want to remove the title from the post content.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Strip Title From Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="strip_title4" name="strip_title" class="valuesai4">
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip spinning of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Do Not Spin Posts Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="skip_spin4" name="skip_spin" class="valuesai4">               
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px"><?php echo esc_html__("Do you want to skip translating of posts generated by this rule?", 'aiomatic-automatic-ai-content-writer');?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Do Not Translate Posts Generated By This Rule:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <input type="checkbox" id="skip_translate4" name="skip_translate" class="valuesai4">               
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Run regex on post content. To disable this feature, leave this field blank. No Regex separators are required here. You can add multiple Regex expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Run Regex On Content:", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="strip_by_regex" id="strip_by_regex4" placeholder="regex expression" class="valuesai4 cr_width_full"></textarea>
                           </td>
                        </tr>
                        <tr>
                           <td>
                                 <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help cr_align_middle">
                                    <div class="bws_hidden_help_text cr_min_260px">
                                       <?php
                                          echo esc_html__("Replace the above regex matches with this regex expression. If you want to strip matched content, leave this field blank. No Regex separators are required here. You can add multiple replacement expressions, each on a different line.", 'aiomatic-automatic-ai-content-writer');
                                          ?>
                                    </div>
                                 </div>
                                 <b><?php echo esc_html__("Replace Matches From Regex (Content):", 'aiomatic-automatic-ai-content-writer');?></b>
                           </td>
                           <td>
                           <textarea rows="1" name="replace_regex" id="replace_regex4" placeholder="regex replacement" class="valuesai4 cr_width_full"></textarea>
                           </td>
                        </tr>
                     </table>
                  </div>
               </div>
               <div class="codemodalfzr-footer">
                  <br/>
                  <h3 class="cr_inline">Aimogen Automatic Post Generator</h3>
                  <span id="aiomatic_ok4" class="codeokfzr cr_inline">OK&nbsp;</span>
                  <br/><br/>
               </div>
            </div>
                           </div>
                           </div>
                           </div>
                           </div>
         </div>
      </div>
<div id="hrdiv">
<div id="hrwrap">
	<hr/>
	<h2 class="aiomatic-middle aiomatic-big"><?php echo esc_html__("Generated Results", 'aiomatic-automatic-ai-content-writer'); ?></h2>
</div>
	</div><!-- /hrdiv -->

<div id="titlediv">
<div id="titlewrap">
	<h2 class="top_heading"><?php echo esc_html__("Post Title", 'aiomatic-automatic-ai-content-writer'); ?></h2>
	<input type="text" name="post_title" size="30" value="" id="title_advanced" class="coderevolution_gutenberg_input aiomatic-big-font" onchange="aiomatic_content_empty('post_content_advanced');" spellcheck="true" autocomplete="off" placeholder="Post title">
</div>
	</div><!-- /titlediv -->
			
			<hr/>
			<h2 class="top_heading"><?php echo esc_html__("Post Content", 'aiomatic-automatic-ai-content-writer'); ?></h2>
	<?php
          $settings = array(
            'textarea_name' => 'post_content_advanced',
            'media_buttons' => true,
            'quicktags' => true,
            'tabindex' => '4'
          );
          wp_editor( '', 'post_content_advanced', $settings );
		  wp_nonce_field( 'create_post', 'create_post_nonce' );
        ?>

<div id="publishdiv">
<div id="publishwrap">
<hr/>
<div id="major-publishing-actions">
	<div class="coderevolution_gutenberg_input" id="publishing-action">
		<span class="spinner"></span>
					<input type="submit" name="publish" id="post_publish_advanced" class="coderevolution_gutenberg_input button button-primary button-large" value="Create Post" disabled>				</div>
					
	<div class="clear"></div>
</div>
</div>
	<div class="inside">
		<div id="publish-slug-box" class="hide-if-no-js">
				</div>
			</div></div><!-- /publishdiv -->

<br/><br/>
<div id="templdiv">
<div id="templwrap">
<hr/>
<h2 class="top_heading"><div class="tool" data-tip="Save or load your templates for content creation. These templates will be stored and accessible only from your user account."><?php echo esc_html__("Advanced Content Templates", 'aiomatic-automatic-ai-content-writer'); ?>&nbsp;&#9072;</div></h2>
<div class="aiomatic-minor-publishing-actions">
<input type="button" name="save_template_advanced" id="save_template_advanced" onclick="aiomatic_save_template_advanced()" class="button button-primary button-large" value="Save New Template">&nbsp;
<input type="button" name="load_template_advanced" id="load_template_advanced" onclick="aiomatic_load_template_advanced()" class="button button-primary button-large" value="Load Selected Template">&nbsp;
<input type="button" name="delete_template_advanced" id="delete_template_advanced" onclick="aiomatic_delete_template_advanced()" class="button button-primary button-large" value="Delete Selected Template">&nbsp;
<input type="button" name="import_template_advanced" id="import_template_advanced" onclick="aiomatic_import_template_advanced()" class="button button-primary button-large" value="Import Templates From File">&nbsp;
<input type="button" name="export_template_advanced" id="export_template_advanced" onclick="aiomatic_export_template_advanced()" class="button button-primary button-large" value="Export Templates To File">&nbsp;
<input type="file" id="import_template_file_advanced" name="import_template_file_advanced" class="cr_none" accept=".json" />
</div>
	<select class="coderevolution_gutenberg_input" id="template_manager_advanced">
		<option value="Default Template"><?php echo esc_html__("Default Template", 'aiomatic-automatic-ai-content-writer');?></option>
<?php
$user_id = get_current_user_id(); 
if($user_id == 0)
{
	aiomatic_log_to_file('No user logged in, cannot find templates!');
}
else
{
	$key = 'aiomatic_templates_advanced'; 
	$single = true; 
	$aiomatic_templates = get_user_meta( $user_id, $key, $single );
	if(is_array($aiomatic_templates))
	{
		foreach($aiomatic_templates as $tn => $template_name)
		{
			echo '<option value="' . esc_html($tn) . '">' . esc_html($tn) . '</option>';
		}
	}
}
?>
	</select>
</div>
</div><!-- /templdiv -->
<div id="tutodiv">
<div id="tutowrap">
<hr/>
<?php if(!isset($aiomatic_Main_Settings['hide_videos']) || trim($aiomatic_Main_Settings['hide_videos']) != 'on'){
?>
<h2 class="top_heading"><div><?php echo esc_html__("Tutorial Video:", 'aiomatic-automatic-ai-content-writer'); ?></div></h2>
<p class="cr_center"><div class="embedtool"><iframe src="https://www.youtube.com/embed/rlDtQ8qgGYg" frameborder="0" allowfullscreen></iframe></div></p>
<?php
}
?>
</div>
</div><!-- /tutodiv -->			

</div><!-- /post-body-content -->

<div id="postbox-container-1" class="postbox-container">
<div id="side-sortables" class="meta-box-sortables ui-sortable">

<div class="postbox">
<div class="postbox-header"><h2 class="hndle ui-sortable-handle"><div class="tool" data-tip="Set the general parameters for your generated content."><?php echo esc_html__("Post Options", 'aiomatic-automatic-ai-content-writer');?>&nbsp;&#9072;
                              </div></h2>
</div><div class="inside">
<div class="submitbox" id="otherpost">

<div id="other-publishing">


	<div class="aiomatic-minor-publishing-actions">
	<div class="cr-align-left">
	<div class="tool" data-tip="Set the post type."><?php echo esc_html__("Post Type", 'aiomatic-automatic-ai-content-writer');?>:&nbsp;&#9072;
                              </div>
							</div>
							<select id="submit_type_advanced" name="submit_type_advanced" class="coderevolution_gutenberg_input">
<?php
foreach ( get_post_types( '', 'names' ) as $post_type ) {
   if(strstr($post_type, 'aiomatic_'))
   {
      continue;
   }
   echo '<option value="' . esc_attr($post_type) . '"';
   echo '>' . esc_html($post_type) . '</option>';
}
?>
							</select> 
					<div class="clear"></div>
	<div class="cr-align-left">
	<div class="tool" data-tip="Set the post status."><?php echo esc_html__("Status", 'aiomatic-automatic-ai-content-writer');?>:&nbsp;&#9072;
                              </div>
							</div>
							<select id="submit_status_advanced" name="submit_status_advanced" class="coderevolution_gutenberg_input">
							<option value="draft" selected><?php echo esc_html__("Draft", 'aiomatic-automatic-ai-content-writer');?></option>
							<option value="pending"><?php echo esc_html__("Pending", 'aiomatic-automatic-ai-content-writer');?></option>
							<option value="publish"><?php echo esc_html__("Published", 'aiomatic-automatic-ai-content-writer');?></option>
							<option value="private"><?php echo esc_html__("Private", 'aiomatic-automatic-ai-content-writer');?></option>
							<option value="trash"><?php echo esc_html__("Trash", 'aiomatic-automatic-ai-content-writer');?></option>
							</select> 
					<div class="clear"></div>
					<div class="cr-align-left">
	<div class="tool" data-tip="Stick this post to the front page."><?php echo esc_html__("Sticky", 'aiomatic-automatic-ai-content-writer');?>:&nbsp;&#9072;
                              </div>
							</div>
							<select id="post_sticky_advanced" name="post_sticky_advanced" class="coderevolution_gutenberg_input">
							<option value="no"><?php echo esc_html__("No", 'aiomatic-automatic-ai-content-writer');?></option>
							<option value="yes"><?php echo esc_html__("Yes", 'aiomatic-automatic-ai-content-writer');?></option>
							</select> 
					<div class="clear"></div>
					<div class="cr-align-left">
	<div class="tool" data-tip="Set the post author."><?php echo esc_html__("Author", 'aiomatic-automatic-ai-content-writer');?>:&nbsp;&#9072;
                              </div>
							</div>
<?php
	$curruser = get_current_user_id();
    wp_dropdown_users(['class' => 'coderevolution_gutenberg_input', 'id' => 'post_author_advanced', 'name' => 'post_author_advanced', 'selected' => $curruser, 'role__in' => array('administrator', 'editor', 'author', 'contributor')]);
?>
					<div class="clear"></div>
					<div class="cr-align-left">
	<div class="tool" data-tip="Set the post publish date."><?php echo esc_html__("Publish Date", 'aiomatic-automatic-ai-content-writer');?>:&nbsp;&#9072;
                              </div>
							</div>
<?php
$date1x = new DateTime('now', aiomatic_get_blog_timezone());
?>
							<input type="datetime-local" id="post_date_advanced" name="post_date_advanced" value="<?php echo esc_attr( $date1x->format('Y-m-d\TH:i:s') ); ?>" class="coderevolution_gutenberg_input" />
					<div class="clear"></div>
					<div class="cr-align-left">
	<div class="tool" data-tip="Set the post categories."><?php echo esc_html__("Post Categories", 'aiomatic-automatic-ai-content-writer');?>:&nbsp;&#9072;
                              </div>
							</div>
							<?php
$default_category = get_option('default_category');
$args = array(
	'orderby'          => 'name',
	'hide_empty'       => 0,
	'echo'             => 0,
	'class'            => 'coderevolution_gutenberg_input',
	'id'               => 'post_category_advanced',
	'name'             => 'post_category_advanced',
	'selected'         => $default_category
);
$select_cats = wp_dropdown_categories($args);
$select_cats = str_replace( "name='post_category_advanced'", "name='post_category_advanced[]' multiple='multiple'", $select_cats );
$select_cats = str_replace( 'name="post_category_advanced"', 'name="post_category_advanced[]" multiple="multiple"', $select_cats );
echo $select_cats;
?>
					<div class="clear"></div><div class="cr-align-left">
	<div class="tool" data-tip="Set the post tags."><?php echo esc_html__("Post Tags", 'aiomatic-automatic-ai-content-writer');?>:&nbsp;&#9072;
                              </div>
							</div>
							<input id="post_tags_advanced" name="post_tags_advanced" type="text" list="post_tags_list2" class="coderevolution_gutenberg_input" value="" placeholder="Tag list"/>
							<datalist id="post_tags_list2">
<?php
$xtags = get_tags(array(
  'hide_empty' => false
));
if(!is_wp_error($xtags))
{
	foreach ($xtags as $tag) {
		echo '<option>' . esc_html($tag->name) . '</option>';
	}
}
?>
							</datalist>
<small class="cr-align-left coderevolution_gutenberg_input"><?php echo esc_html__("Separate tags with commas", 'aiomatic-automatic-ai-content-writer');?></small>
					<div class="clear"></div>
	</div>

	<div class="clear"></div>
</div>
</div>
	</div>
</div>

<div class="postbox">
<div class="postbox-header"><h2 class="hndle ui-sortable-handle"><?php echo esc_html__("Featured Image", 'aiomatic-automatic-ai-content-writer');?></h2>
</div><div class="inside">
<div class="submitbox" id="submitpost">

<div id="minor-publishing">
	<div class="aiomatic-minor-publishing-actions">
<?php
echo '<div class="coderevolution_gutenberg_input"><img id="aiomatic-preview-image-advanced"/></div>';?>
 <input type="hidden" name="aiomatic_image_id_advanced" id="aiomatic_image_id_advanced" value="" class="regular-text" />
 <input type='button' class="button-primary" value="<?php esc_attr_e( 'Select an image', 'aiomatic-automatic-ai-content-writer' ); ?>" id="aiomatic_media_manager_advanced"/>


	<div class="clear"></div>
	</div>

	<div class="clear"></div>
</div>
</div>
	</div>
</div>

</div></div>
</div><!-- /post-body -->
<br class="clear">
</form><!-- /poststuff -->
</div>
</div>
</section>
</div>
<?php
}
?>