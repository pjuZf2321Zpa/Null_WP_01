<?php
defined('ABSPATH') or die();

/*
 * Telegram channel for the AI chatbot.
 *
 * People talk to the site's chatbot in Telegram: Telegram posts each message to a REST
 * webhook, Aimogen answers with the chatbot's model and instructions, and replies through
 * the Bot API. Sending /human hands the conversation to the site owner, who answers from
 * their own Telegram chat with the bot by replying to the forwarded messages, and replies
 * /done to hand it back to the AI.
 *
 * Off until enabled with a bot token. Telegram only delivers to public HTTPS URLs, so it
 * cannot reach a localhost site. The webhook is registered when the chatbot settings are saved.
 */

if (!defined('AIMOGEN_TELEGRAM_HISTORY')) {
    define('AIMOGEN_TELEGRAM_HISTORY', 12); // messages kept per chat, both sides
}
if (!defined('AIMOGEN_TELEGRAM_HANDOFF_TTL')) {
    define('AIMOGEN_TELEGRAM_HANDOFF_TTL', DAY_IN_SECONDS); // a silent handoff returns to the AI after this
}

function aimogen_telegram_settings($chatbot = null)
{
    if ($chatbot === null) {
        $chatbot = get_option('aiomatic_Chatbot_Settings', array());
    }
    $chatbot = is_array($chatbot) ? $chatbot : array();
    return array(
        'enabled' => isset($chatbot['telegram_enabled']) && $chatbot['telegram_enabled'] === 'on',
        'token'   => isset($chatbot['telegram_token']) ? trim((string) $chatbot['telegram_token']) : '',
        'owner'   => isset($chatbot['telegram_owner_chat']) ? trim((string) $chatbot['telegram_owner_chat']) : '',
    );
}

/** Call a Bot API method. Returns the decoded response, or a WP_Error. The token never reaches the logs. */
function aimogen_telegram_api($token, $method, array $params = array())
{
    $response = wp_remote_post('https://api.telegram.org/bot' . $token . '/' . $method, array(
        'headers' => array('Content-Type' => 'application/json'),
        'body'    => wp_json_encode($params),
        'timeout' => 20,
    ));
    if (is_wp_error($response)) {
        return new WP_Error('telegram', $response->get_error_message());
    }
    $body = json_decode(wp_remote_retrieve_body($response), true);
    if (!is_array($body) || empty($body['ok'])) {
        return new WP_Error('telegram', is_array($body) && isset($body['description']) ? $body['description'] : 'HTTP ' . wp_remote_retrieve_response_code($response));
    }
    return $body;
}

/** Split text into pieces under Telegram's 4096-character message limit, at line breaks where possible. */
function aimogen_telegram_chunks($text, $size = 4000)
{
    $lines = preg_split('/(?<=\n)/u', $text);
    if ($lines === false) {
        $lines = array($text);
    }
    $chunks = array();
    $current = '';
    foreach ($lines as $line) {
        while (aiomatic_strlen($line) > $size) {
            if ($current !== '') {
                $chunks[] = $current;
                $current = '';
            }
            $chunks[] = aiomatic_substr($line, 0, $size);
            $line = aiomatic_substr($line, $size);
        }
        if (aiomatic_strlen($current . $line) > $size) {
            $chunks[] = $current;
            $current = '';
        }
        $current .= $line;
    }
    if (trim($current) !== '') {
        $chunks[] = $current;
    }
    return $chunks;
}

/** Send plain text (no parse mode, so AI output can never break Telegram formatting). Returns the sent message IDs. */
function aimogen_telegram_send($token, $chat_id, $text)
{
    $text = trim((string) $text);
    $sent = array();
    if ($text === '') {
        return $sent;
    }
    foreach (aimogen_telegram_chunks($text) as $chunk) {
        $result = aimogen_telegram_api($token, 'sendMessage', array('chat_id' => $chat_id, 'text' => $chunk));
        if (is_wp_error($result)) {
            aiomatic_log_to_file('Telegram sendMessage failed: ' . $result->get_error_message());
            break;
        }
        $sent[] = $result['result']['message_id'];
    }
    return $sent;
}

/** AI replies can contain HTML; Telegram gets plain text. */
function aimogen_telegram_plain($text)
{
    $text = preg_replace('#<br\s*/?>|</p>|</li>|</h[1-6]>#i', "\n", (string) $text);
    $text = html_entity_decode(wp_strip_all_tags($text), ENT_QUOTES, 'UTF-8');
    return trim(preg_replace("/\n{3,}/", "\n\n", $text));
}

function aimogen_telegram_history_key($chat_id)
{
    return 'aimogen_tg_history_' . md5((string) $chat_id);
}

function aimogen_telegram_handoff_key($chat_id)
{
    return 'aimogen_tg_human_' . md5((string) $chat_id);
}

/** Owner-side message ID => the user chat it is about, so the owner's replies can be routed back. */
function aimogen_telegram_map_key($message_id)
{
    return 'aimogen_tg_map_' . (int) $message_id;
}

function aimogen_telegram_history($chat_id)
{
    $history = get_transient(aimogen_telegram_history_key($chat_id));
    return is_array($history) ? $history : array();
}

function aimogen_telegram_remember($chat_id, $role, $text)
{
    $history = aimogen_telegram_history($chat_id);
    $history[] = array('role' => $role, 'text' => $text);
    set_transient(aimogen_telegram_history_key($chat_id), array_slice($history, -AIMOGEN_TELEGRAM_HISTORY), WEEK_IN_SECONDS);
}

/** "Jane Doe (@jane)" */
function aimogen_telegram_sender_name(array $message)
{
    $from = isset($message['from']) && is_array($message['from']) ? $message['from'] : array();
    $name = trim((isset($from['first_name']) ? $from['first_name'] : '') . ' ' . (isset($from['last_name']) ? $from['last_name'] : ''));
    if (!empty($from['username'])) {
        $name .= ' (@' . $from['username'] . ')';
    }
    return $name !== '' ? $name : __('A Telegram user', 'aiomatic-automatic-ai-content-writer');
}

/** Send to the owner about a user chat, remembering which chat each owner-side message belongs to. */
function aimogen_telegram_to_owner($token, $owner, $user_chat, $text)
{
    foreach (aimogen_telegram_send($token, $owner, $text) as $message_id) {
        set_transient(aimogen_telegram_map_key($message_id), (string) $user_chat, WEEK_IN_SECONDS);
    }
}

/** The chatbot's own per-IP limit, applied per Telegram chat; 30 messages an hour when none is set. */
function aimogen_telegram_rate_limited(array $chatbot, $chat_id)
{
    $time = HOUR_IN_SECONDS;
    $count = 30;
    if (!empty($chatbot['restriction_time']) && is_numeric($chatbot['restriction_time']) && !empty($chatbot['restriction_count']) && is_numeric($chatbot['restriction_count'])) {
        $time = (int) $chatbot['restriction_time'];
        $count = (int) $chatbot['restriction_count'];
    }
    $key = 'aimogen_tg_rate_' . md5((string) $chat_id);
    $used = (int) get_transient($key);
    if ($used >= $count) {
        return true;
    }
    set_transient($key, $used + 1, $time);
    return false;
}

/** Flattened prompt in the same shape as the classic chatbot: instructions, recent turns, then the new message. */
function aimogen_telegram_prompt(array $chatbot, array $history, $text)
{
    $user = !empty($chatbot['user_message_preppend']) ? rtrim(trim($chatbot['user_message_preppend']), ':') : 'User';
    $ai = !empty($chatbot['ai_message_preppend']) ? rtrim(trim($chatbot['ai_message_preppend']), ':') : 'AI';
    $lines = array();
    foreach (array('chat_preppend_text', 'chatbot_prepend') as $key) {
        if (!empty($chatbot[$key]) && trim($chatbot[$key]) !== '') {
            $lines[] = trim($chatbot[$key]);
        }
    }
    foreach ($history as $turn) {
        $lines[] = ($turn['role'] === 'user' ? $user : $ai) . ': ' . $turn['text'];
    }
    if (!empty($chatbot['chatbot_append']) && trim($chatbot['chatbot_append']) !== '') {
        $lines[] = trim($chatbot['chatbot_append']);
    }
    $lines[] = $user . ': ' . $text;
    $lines[] = $ai . ':';
    return implode("\n", $lines);
}

/** Answer with the chatbot's model and sampling settings. Returns the reply text, or false. */
function aimogen_telegram_ai_reply(array $chatbot, $prompt, $chat_id, &$error)
{
    $main = get_option('aiomatic_Main_Settings', array());
    $model = !empty($chatbot['chat_model']) ? trim($chatbot['chat_model']) : aiomatic_get_default_model_name($main);
    if (!in_array($model, aiomatic_get_all_models(), true)) {
        $model = aiomatic_get_default_model_name($main);
    }
    $max_tokens = aimogenpro_get_max_tokens($model);
    if (isset($chatbot['max_tokens']) && is_numeric($chatbot['max_tokens']) && (int) $chatbot['max_tokens'] > 0) {
        $max_tokens = min($max_tokens, (int) $chatbot['max_tokens']);
    }
    $prompt_tokens = count(aiomatic_encode($prompt));
    $available = max(1, aiomatic_compute_available_tokens($model, $max_tokens, $prompt, $prompt_tokens));
    $sampling = array();
    foreach (array('temperature' => 1, 'top_p' => 1, 'presence_penalty' => 0, 'frequency_penalty' => 0) as $key => $default) {
        $sampling[$key] = isset($chatbot[$key]) && is_numeric($chatbot[$key]) ? floatval($chatbot[$key]) : $default;
    }
    $token = '';
    if (!empty($main['app_id'])) {
        $keys = array_filter(preg_split('/\r\n|\r|\n/', trim($main['app_id'])));
        $token = empty($keys) ? '' : $keys[array_rand($keys)];
    }
    // Per-chat abuse ID: every Telegram user arrives from Telegram's servers, so the IP is useless here.
    $visitor_id = function () use ($chat_id) {
        return 'aimogen_' . hash_hmac('sha256', 'telegram:' . $chat_id, wp_salt('auth'));
    };
    add_filter('aimogen_visitor_safety_id', $visitor_id);
    $finish_reason = '';
    $reply = aiomatic_generate_text($token, $model, $prompt, $available, $sampling['temperature'], $sampling['top_p'], $sampling['presence_penalty'], $sampling['frequency_penalty'], true, 'telegramChat', 0, $finish_reason, $error);
    remove_filter('aimogen_visitor_safety_id', $visitor_id);
    return $reply;
}

/** Telegram chats are visitor requests, so the provider gets the per-chat abuse ID. */
function aimogen_telegram_visitor_env(array $envs)
{
    $envs[] = 'telegramChat';
    return $envs;
}
add_filter('aimogen_visitor_request_envs', 'aimogen_telegram_visitor_env');

/** Handle one incoming private message. */
function aimogen_telegram_handle_message(array $config, array $message)
{
    if (!isset($message['chat']['id'], $message['chat']['type']) || $message['chat']['type'] !== 'private') {
        return;
    }
    $token = $config['token'];
    $chat_id = (string) $message['chat']['id'];
    $text = isset($message['text']) ? trim((string) $message['text']) : '';
    $owner = $config['owner'];

    if ($text === '/id') {
        /* translators: %s: Telegram chat ID */
        aimogen_telegram_send($token, $chat_id, sprintf(__('Your Telegram chat ID is: %s', 'aiomatic-automatic-ai-content-writer'), $chat_id));
        return;
    }

    // The owner replying to a forwarded message answers that user, or hands them back with /done.
    if ($owner !== '' && $chat_id === $owner && isset($message['reply_to_message']['message_id'])) {
        $user_chat = get_transient(aimogen_telegram_map_key($message['reply_to_message']['message_id']));
        if ($user_chat) {
            if ($text === '/done') {
                delete_transient(aimogen_telegram_handoff_key($user_chat));
                aimogen_telegram_send($token, $user_chat, __('You are back with the AI assistant.', 'aiomatic-automatic-ai-content-writer'));
                aimogen_telegram_send($token, $owner, __('Handed back to the AI.', 'aiomatic-automatic-ai-content-writer'));
            } elseif ($text !== '') {
                set_transient(aimogen_telegram_handoff_key($user_chat), 1, AIMOGEN_TELEGRAM_HANDOFF_TTL);
                aimogen_telegram_send($token, $user_chat, $text);
                aimogen_telegram_remember($user_chat, 'assistant', $text);
            }
            return;
        }
    }

    if ($text === '') {
        aimogen_telegram_send($token, $chat_id, __('I can only read text messages.', 'aiomatic-automatic-ai-content-writer'));
        return;
    }

    $chatbot = get_option('aiomatic_Chatbot_Settings', array());
    $chatbot = is_array($chatbot) ? $chatbot : array();
    if ($text === '/start' || $text === '/reset') {
        delete_transient(aimogen_telegram_history_key($chat_id));
        if ($text === '/start') {
            $hello = !empty($chatbot['ai_first_message']) ? aimogen_telegram_plain($chatbot['ai_first_message']) : __('Hi! How can I help you?', 'aiomatic-automatic-ai-content-writer');
            aimogen_telegram_send($token, $chat_id, $hello);
        } else {
            aimogen_telegram_send($token, $chat_id, __('Conversation cleared.', 'aiomatic-automatic-ai-content-writer'));
        }
        return;
    }

    $name = aimogen_telegram_sender_name($message);
    if ($text === '/human') {
        if ($owner === '') {
            aimogen_telegram_send($token, $chat_id, __('Talking to a person is not available here.', 'aiomatic-automatic-ai-content-writer'));
            return;
        }
        set_transient(aimogen_telegram_handoff_key($chat_id), 1, AIMOGEN_TELEGRAM_HANDOFF_TTL);
        $recent = array();
        foreach (array_slice(aimogen_telegram_history($chat_id), -6) as $turn) {
            $recent[] = ($turn['role'] === 'user' ? $name : 'AI') . ': ' . $turn['text'];
        }
        /* translators: %s: Telegram user's name */
        $intro = sprintf(__('%s asked for a person. Reply to this message to answer them, or reply /done to hand them back to the AI.', 'aiomatic-automatic-ai-content-writer'), $name);
        if (!empty($recent)) {
            $intro .= "\n\n" . __('Recent conversation:', 'aiomatic-automatic-ai-content-writer') . "\n" . implode("\n", $recent);
        }
        aimogen_telegram_to_owner($token, $owner, $chat_id, $intro);
        aimogen_telegram_send($token, $chat_id, __('I have asked a person to join. They will reply here as soon as they can.', 'aiomatic-automatic-ai-content-writer'));
        return;
    }

    if (get_transient(aimogen_telegram_handoff_key($chat_id))) {
        if ($owner !== '') {
            aimogen_telegram_remember($chat_id, 'user', $text);
            aimogen_telegram_to_owner($token, $owner, $chat_id, $name . ': ' . $text);
            return;
        }
        delete_transient(aimogen_telegram_handoff_key($chat_id));
    }

    if (aimogen_telegram_rate_limited($chatbot, $chat_id)) {
        $limit = !empty($chatbot['restriction_message']) ? aimogen_telegram_plain($chatbot['restriction_message']) : __('You have sent too many messages. Please try again later.', 'aiomatic-automatic-ai-content-writer');
        aimogen_telegram_send($token, $chat_id, $limit);
        return;
    }
    if (!empty($chatbot['max_input_length']) && is_numeric($chatbot['max_input_length']) && aiomatic_strlen($text) > (int) $chatbot['max_input_length']) {
        $text = aiomatic_substr($text, 0, (int) $chatbot['max_input_length']);
    }

    aimogen_telegram_api($token, 'sendChatAction', array('chat_id' => $chat_id, 'action' => 'typing'));
    $error = '';
    $reply = aimogen_telegram_ai_reply($chatbot, aimogen_telegram_prompt($chatbot, aimogen_telegram_history($chat_id), $text), $chat_id, $error);
    $reply = $reply === false ? '' : aimogen_telegram_plain($reply);
    if ($reply === '') {
        aiomatic_log_to_file('Telegram chatbot could not answer: ' . $error);
        aimogen_telegram_send($token, $chat_id, __('Sorry, I cannot answer right now. Please try again later.', 'aiomatic-automatic-ai-content-writer'));
        return;
    }
    aimogen_telegram_send($token, $chat_id, $reply);
    aimogen_telegram_remember($chat_id, 'user', $text);
    aimogen_telegram_remember($chat_id, 'assistant', $reply);
}

/** Only Telegram knows the secret it sends in this header. */
function aimogen_telegram_webhook_permission(WP_REST_Request $request)
{
    $secret = (string) get_option('aimogen_telegram_secret', '');
    $header = (string) $request->get_header('x_telegram_bot_api_secret_token');
    return $secret !== '' && $header !== '' && hash_equals($secret, $header);
}

function aimogen_telegram_webhook(WP_REST_Request $request)
{
    $config = aimogen_telegram_settings();
    $update = $request->get_json_params();
    if (!$config['enabled'] || $config['token'] === '' || !is_array($update) || !isset($update['update_id'])) {
        return new WP_REST_Response(array('ok' => true), 200);
    }
    // Telegram retries slow or failed deliveries; handle each update once.
    $seen = 'aimogen_tg_update_' . (int) $update['update_id'];
    if (get_transient($seen)) {
        return new WP_REST_Response(array('ok' => true), 200);
    }
    set_transient($seen, 1, HOUR_IN_SECONDS);
    ignore_user_abort(true);
    if (isset($update['message']) && is_array($update['message'])) {
        aimogen_telegram_handle_message($config, $update['message']);
    }
    return new WP_REST_Response(array('ok' => true), 200);
}

function aimogen_telegram_register_route()
{
    register_rest_route('aiomatic', 'v1/telegram', array(
        'methods'             => 'POST',
        'callback'            => 'aimogen_telegram_webhook',
        'permission_callback' => 'aimogen_telegram_webhook_permission',
    ));
}
add_action('rest_api_init', 'aimogen_telegram_register_route');

/**
 * Register or remove the webhook when the chatbot settings are saved. Runs on every save,
 * but only calls Telegram when the token, the on/off state or the site URL changed, or the
 * last attempt failed.
 */
function aimogen_telegram_sync_webhook($value, $old_value)
{
    $new = aimogen_telegram_settings($value);
    $old = aimogen_telegram_settings($old_value);
    $status = get_option('aimogen_telegram_status', array());
    $status = is_array($status) ? $status : array();
    $url = rest_url('aiomatic/v1/telegram');

    if ($old['enabled'] && $old['token'] !== '' && (!$new['enabled'] || $new['token'] !== $old['token'])) {
        aimogen_telegram_api($old['token'], 'deleteWebhook');
    }
    if (!$new['enabled'] || $new['token'] === '') {
        update_option('aimogen_telegram_status', array('state' => $new['enabled'] ? 'error' : 'off', 'message' => $new['enabled'] ? __('Add a bot token.', 'aiomatic-automatic-ai-content-writer') : ''), false);
        return $value;
    }
    if (isset($status['state'], $status['token'], $status['url']) && $status['state'] === 'ok' && $status['token'] === md5($new['token']) && $status['url'] === $url) {
        return $value;
    }
    $secret = (string) get_option('aimogen_telegram_secret', '');
    if ($secret === '') {
        $secret = wp_generate_password(48, false, false);
        update_option('aimogen_telegram_secret', $secret, false);
    }
    $result = aimogen_telegram_api($new['token'], 'setWebhook', array('url' => $url, 'secret_token' => $secret, 'allowed_updates' => array('message')));
    if (is_wp_error($result)) {
        update_option('aimogen_telegram_status', array('state' => 'error', 'message' => $result->get_error_message()), false);
        return $value;
    }
    $me = aimogen_telegram_api($new['token'], 'getMe');
    $bot = !is_wp_error($me) && isset($me['result']['username']) ? $me['result']['username'] : '';
    update_option('aimogen_telegram_status', array('state' => 'ok', 'message' => '', 'bot' => $bot, 'token' => md5($new['token']), 'url' => $url), false);
    return $value;
}
add_filter('pre_update_option_aiomatic_Chatbot_Settings', 'aimogen_telegram_sync_webhook', 10, 2);
