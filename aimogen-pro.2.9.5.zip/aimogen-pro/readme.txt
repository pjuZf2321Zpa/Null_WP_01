=== Aimogen Pro - Automatic AI Content Writer, Editor, Chatbot & AI Toolkit ===
Contributors: coderevolution
Donate link: https://www.patreon.com/coderevolution
Tags: ai content generator, chatgpt, ai chatbot, openai, ai writer
Requires at least: 5.0
Tested up to: 7.0
Requires PHP: 7.3
Stable tag: 2.8.9
License: Regular/Extended License

The premium all-in-one WordPress AI plugin: automatic content writing and editing, chatbots, AI agents, image/video generation and 15+ AI providers.

== Description ==

Aimogen Pro is the premium, all-in-one AI toolkit for WordPress. It brings automated content creation, in-dashboard AI editing, chatbots, autonomous agents, image and video generation, embeddings/RAG and a large library of shortcodes and blocks together in a single plugin - working with all of the major AI providers.

Aimogen Pro extends the free Aimogen plugin (https://wordpress.org/plugins/aimogen/). Install and activate the free plugin to unlock all shared features.

**Content creation**

* Single and bulk AI post creators (keywords, titles, listicles, product roundups/reviews, CSV, YouTube-to-article)
* AI Omni Pages - build full pages and funnels (Gutenberg or Elementor) from prompts and reference URLs
* AI Content Editor - bulk rewrite, spin, translate and improve existing posts with scheduled rules
* Amazon and ClickBank product roundups and reviews
* Forum content generation (wpForo topics and replies)

**Chatbots & agents**

* Site-wide and embeddable AI chatbots (default, modern and messenger designs)
* Content-aware chatbots, persistent chats, file uploads and realtime voice chat
* Autonomous AI Agents that use tools and complete multi-step tasks on your site
* Remote/embeddable chatbots that bill against user subscription credits

**Automation & developer tools**

* OmniBlocks - composable AI blocks for text, images, scraping, WooCommerce products, webhooks and more
* AI Snippets Engine - AI-generated PHP/JS/CSS/HTML snippets with conditional logic and fatal-error protection
* MCP support - connect to external MCP servers or expose your own
* Embeddings and vector stores (OpenAI Vector Stores, Pinecone, Qdrant, Chroma)
* PHP API, WP-CLI commands, WordPress Abilities API and WordPress 7.0 Connectors integration
* 75+ shortcodes and 22 Gutenberg blocks

**Images & video**

* AI image generation via OpenAI, Stability.AI, Google Imagen, Ideogram, Replicate, Midjourney and Cloudflare Workers
* AI video generation with OpenAI Sora
* Royalty-free image sources and automatic featured images

**Supported AI providers**

OpenAI, AiomaticAPI, Microsoft Azure OpenAI, Anthropic Claude, Google AI Studio (Gemini), xAI (Grok), Perplexity, Groq, NVIDIA NIM, OpenRouter, Hugging Face and Ollama.

---

Nice to meet you! My name is Szabi from CodeRevolution. We are a team of a few people who work FULL TIME as freelancers, making plugins and scripts for WPBay Market. Because we dedicate all our time to this, our items are filled with passion, and we can offer premium support to our customers all the time! Feel free to ask in advance any question you might have about our items! If you buy any of our items, you will have support in case something is not working as specified, related to our item, according to WPBay Support Policy.
Hope that you enjoy my work!

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/aimogen-pro` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Install and activate the free Aimogen plugin (https://wordpress.org/plugins/aimogen/) to unlock all shared features.
4. Open the Aimogen menu and follow the Quick Setup Wizard to add your API key(s) and configure the plugin.

== Frequently Asked Questions ==

= How do I update this plugin? =

This plugin supports automatical updating. Please click "Check for updates" for this plugin in the WordPress plugins control panel. If a new version is available you will be prompted. Click "Update now" to finish the updating process.

= Do I need the free Aimogen plugin? =

Aimogen Pro extends the free Aimogen plugin. Install and activate the free version (https://wordpress.org/plugins/aimogen/) to enable all shared features.

= Which AI providers are supported? =

OpenAI, AiomaticAPI, Microsoft Azure OpenAI, Anthropic Claude, Google AI Studio (Gemini), xAI (Grok), Perplexity, Groq, NVIDIA NIM, OpenRouter, Hugging Face and Ollama. You can use the plugin with any single provider's API key - an OpenAI key is not required.

== Changelog ==

For the complete version history since 1.0, see the full changelog:
https://coderevolution.ro/knowledge-base/faq/full-changelog-aiomatic-automatic-ai-content-writer-editor-gpt-3-gpt-4-chatgpt-chatbot-ai-toolkit/
