<?php
/*
 * Aimogen AI Editor - field discovery and authorization.
 *
 * Every request rebuilds the list of fields the CURRENT user may edit on the CURRENT
 * post from scratch. Field identifiers arriving from the browser are only ever used
 * to look an entry up in that server-built list; they are never used to address a
 * meta key directly. This is what stops the browser (and the AI) from naming an
 * arbitrary meta key to write.
 *
 * Identifier format:
 *   post_title | post_content | post_excerpt   core post columns
 *   meta:<key>                                 regular post meta
 *   acf:<field_key>                            ACF field, addressed by its field key
 */

defined('ABSPATH') or die();

/**
 * Meta keys that are never offered, as fnmatch-style patterns.
 *
 * This is the coarse layer only - the real filtering is structural (protected meta,
 * registered-meta auth callbacks, scalar-only values). The patterns exist for keys
 * that are technically public scalars but are internal bookkeeping rather than
 * content a human would want an AI to rewrite.
 */
function aimogen_ai_editor_excluded_meta_patterns($post_id)
{
    $patterns = array(
        /* WordPress and plugin internals that are not underscore-prefixed. */
        'aiomatic_*',
        'aimogen_*',
        'enclosure',
        'slide_template',
        'panels_data',

        /* Page builders store serialized/JSON layout trees under public keys. */
        'elementor*',
        'et_pb_*',
        'fusion_*',
        'vc_*',
        'oxygen_*',
        'ct_builder*',
        'themify_*',

        /* WooCommerce bookkeeping. Prices, stock and SKUs are underscore-prefixed
           and excluded structurally; these are the public-key exceptions. Product
           commerce data is out of scope until a dedicated integration exists. */
        'total_sales',

        /* SEO plugins keep human-editable text under public keys (rank_math_description
           and friends stay available on purpose); these are the machine-only ones. */
        'rank_math_internal_links_processed',
        'rank_math_analytic_object_id',
        'rank_math_seo_score',
        'rank_math_permalink',
    );

    return apply_filters('aimogen_ai_editor_excluded_meta_fields', $patterns, $post_id);
}

/**
 * fnmatch() is not available on every host (notably some Windows builds), so the
 * wildcard match is done with a translated regex instead.
 */
function aimogen_ai_editor_key_matches_pattern($key, $pattern)
{
    if (strpos($pattern, '*') === false && strpos($pattern, '?') === false) {
        return $key === $pattern;
    }
    $regex = '';
    $length = strlen($pattern);
    for ($i = 0; $i < $length; $i++) {
        $char = $pattern[$i];
        if ($char === '*') {
            $regex .= '.*';
        } elseif ($char === '?') {
            $regex .= '.';
        } else {
            $regex .= preg_quote($char, '#');
        }
    }
    return (bool) preg_match('#^' . $regex . '$#i', $key);
}

function aimogen_ai_editor_key_is_excluded($key, $patterns)
{
    foreach ($patterns as $pattern) {
        if (aimogen_ai_editor_key_matches_pattern($key, (string) $pattern)) {
            return true;
        }
    }
    return false;
}

/**
 * Whether a raw meta value is simple enough to hand to an AI and write back.
 *
 * Serialized arrays, JSON documents and oversized blobs are rejected: rewriting them
 * as free text would corrupt whatever plugin owns them.
 */
function aimogen_ai_editor_value_is_editable($value)
{
    if (is_array($value) || is_object($value)) {
        return false;
    }
    if ($value === null || is_bool($value)) {
        return false;
    }
    $value = (string) $value;
    if (is_serialized($value)) {
        return false;
    }
    if (strlen($value) > AIMOGEN_AI_EDITOR_MAX_META_LENGTH) {
        return false;
    }
    /* Reject values that are really structured documents. A leading { or [ that
       parses as JSON means some plugin owns the shape of this value. */
    $trimmed = ltrim($value);
    if ($trimmed !== '' && ($trimmed[0] === '{' || $trimmed[0] === '[')) {
        $decoded = json_decode($value, true);
        if ($decoded !== null && (is_array($decoded) || is_object($decoded))) {
            return false;
        }
    }
    /* Binary-ish payloads (thumbnails, encoded blobs) are not content. */
    if (strpos($value, "\0") !== false) {
        return false;
    }
    return true;
}

/**
 * Registered meta may declare its own authorization. Honour it rather than assuming
 * that edit_post is enough.
 */
function aimogen_ai_editor_registered_meta_allows($post, $key)
{
    if (!function_exists('get_registered_meta_keys')) {
        return true;
    }
    $registered = get_registered_meta_keys('post', $post->post_type);
    if (!isset($registered[$key])) {
        $registered = get_registered_meta_keys('post');
    }
    if (!isset($registered[$key]) || !is_array($registered[$key])) {
        return true;
    }
    $args = $registered[$key];
    /* A registered single=false meta is an array-valued field; out of scope. */
    if (isset($args['single']) && $args['single'] === false) {
        return false;
    }
    if (isset($args['type']) && in_array($args['type'], array('object', 'array'), true)) {
        return false;
    }
    if (isset($args['auth_callback']) && is_callable($args['auth_callback'])) {
        $allowed = call_user_func($args['auth_callback'], false, $key, $post->ID, get_current_user_id(), 'edit_post', array('edit_post'));
        if (!$allowed) {
            return false;
        }
    }
    return true;
}

/**
 * Turn a meta key into something a human recognises.
 */
function aimogen_ai_editor_humanize_key($key)
{
    $label = str_replace(array('_', '-'), ' ', (string) $key);
    $label = trim(preg_replace('/\s+/', ' ', $label));
    if ($label === '') {
        return (string) $key;
    }
    return ucfirst($label);
}

function aimogen_ai_editor_acf_active()
{
    return function_exists('acf_get_field_groups') && function_exists('get_field') && function_exists('update_field');
}

/**
 * ACF field types that map cleanly onto "a block of text an AI can rewrite".
 *
 * Repeaters, flexible content, relationships, galleries and groups are excluded:
 * the plugin has no abstraction for editing those structures safely, and a wrong
 * write would destroy the stored layout.
 */
function aimogen_ai_editor_acf_supported_types()
{
    return apply_filters(
        'aimogen_ai_editor_acf_supported_types',
        array('text', 'textarea', 'wysiwyg', 'url', 'email', 'number')
    );
}

/**
 * Collect the ACF fields attached to this post, descending through layout-only
 * containers (tabs, accordions) but never into value-bearing containers.
 */
function aimogen_ai_editor_collect_acf_fields($fields, &$out, $depth = 0)
{
    if (!is_array($fields) || $depth > 3) {
        return;
    }
    $supported = aimogen_ai_editor_acf_supported_types();
    foreach ($fields as $field) {
        if (!is_array($field) || empty($field['key']) || empty($field['type'])) {
            continue;
        }
        /* Tabs/accordions/messages hold no value but do hold sub-fields in some
           ACF versions; walk them so fields behind a tab are still offered. */
        if (in_array($field['type'], array('tab', 'accordion', 'message'), true)) {
            if (!empty($field['sub_fields'])) {
                aimogen_ai_editor_collect_acf_fields($field['sub_fields'], $out, $depth + 1);
            }
            continue;
        }
        if (!in_array($field['type'], $supported, true)) {
            continue;
        }
        $out[] = $field;
    }
}

/**
 * Build the authoritative list of fields the current user may edit on this post.
 *
 * Returns a map of field id => descriptor. Descriptors carry everything the rest of
 * the module needs: how to read the value, how to write it, and how to sanitize it.
 */
function aimogen_ai_editor_get_available_fields($post)
{
    if (!($post instanceof WP_Post)) {
        $post = get_post($post);
    }
    if (!($post instanceof WP_Post) || empty($post->ID)) {
        return array();
    }
    if (!current_user_can('edit_post', $post->ID)) {
        return array();
    }

    $fields = array();
    $post_type_object = get_post_type_object($post->post_type);
    $supports_editor  = post_type_supports($post->post_type, 'editor');
    $supports_excerpt = post_type_supports($post->post_type, 'excerpt');
    $supports_title   = post_type_supports($post->post_type, 'title');

    if ($supports_title) {
        $fields['post_title'] = array(
            'id'       => 'post_title',
            'kind'     => 'core',
            'key'      => 'post_title',
            'label'    => __('Title', 'aiomatic-automatic-ai-content-writer'),
            'group'    => 'core',
            'format'   => 'plain',
            'value'    => (string) $post->post_title,
            'editable_in_editor' => true,
        );
    }
    if ($supports_excerpt) {
        $fields['post_excerpt'] = array(
            'id'       => 'post_excerpt',
            'kind'     => 'core',
            'key'      => 'post_excerpt',
            'label'    => __('Excerpt', 'aiomatic-automatic-ai-content-writer'),
            'group'    => 'core',
            'format'   => 'text',
            'value'    => (string) $post->post_excerpt,
            'editable_in_editor' => true,
        );
    }
    if ($supports_editor) {
        $fields['post_content'] = array(
            'id'       => 'post_content',
            'kind'     => 'core',
            'key'      => 'post_content',
            'label'    => __('Content', 'aiomatic-automatic-ai-content-writer'),
            'group'    => 'core',
            'format'   => 'html',
            'value'    => (string) $post->post_content,
            'editable_in_editor' => true,
        );
    }

    $acf_handled_keys = array();
    if (aimogen_ai_editor_acf_active()) {
        $acf_fields = array();
        $groups = acf_get_field_groups(array('post_id' => $post->ID));
        if (is_array($groups)) {
            foreach ($groups as $group) {
                if (!is_array($group) || empty($group['key'])) {
                    continue;
                }
                $group_fields = acf_get_fields($group['key']);
                aimogen_ai_editor_collect_acf_fields($group_fields, $acf_fields);
            }
        }
        foreach ($acf_fields as $acf_field) {
            $id = 'acf:' . $acf_field['key'];
            if (isset($fields[$id])) {
                continue;
            }
            /* Raw value (format_value = false) so shortcodes/oEmbeds are not expanded
               into the "current value" we show and feed back to the model. */
            $value = get_field($acf_field['key'], $post->ID, false);
            /* A field that has never been filled in reads back as null. The field is
               still declared by a group attached to this post, so it is offered as an
               empty field rather than hidden: filling one in is exactly what the panel
               is for, and update_field() creates the row and its key reference. */
            if ($value === null) {
                $value = '';
            }
            if (!aimogen_ai_editor_value_is_editable($value)) {
                continue;
            }
            if (!empty($acf_field['name'])) {
                $acf_handled_keys[$acf_field['name']] = true;
            }
            $format = 'text';
            if ($acf_field['type'] === 'wysiwyg') {
                $format = 'html';
            } elseif ($acf_field['type'] === 'text' || $acf_field['type'] === 'url' || $acf_field['type'] === 'email' || $acf_field['type'] === 'number') {
                $format = 'plain';
            }
            $fields[$id] = array(
                'id'        => $id,
                'kind'      => 'acf',
                'key'       => $acf_field['key'],
                'meta_key'  => isset($acf_field['name']) ? (string) $acf_field['name'] : '',
                'label'     => !empty($acf_field['label']) ? (string) $acf_field['label'] : aimogen_ai_editor_humanize_key($acf_field['key']),
                'group'     => 'acf',
                'format'    => $format,
                'acf_type'  => (string) $acf_field['type'],
                'maxlength' => isset($acf_field['maxlength']) && $acf_field['maxlength'] !== '' ? (int) $acf_field['maxlength'] : 0,
                'value'     => (string) $value,
                'editable_in_editor' => false,
            );
        }
    }

    $patterns = aimogen_ai_editor_excluded_meta_patterns($post->ID);
    $meta = get_post_meta($post->ID);
    if (is_array($meta)) {
        foreach ($meta as $key => $values) {
            if (count($fields) >= AIMOGEN_AI_EDITOR_MAX_FIELDS) {
                break;
            }
            $key = (string) $key;
            /* Underscore-prefixed and registered-protected keys are internal by
               WordPress convention: _edit_lock, _thumbnail_id, _wp_page_template... */
            if ($key === '' || $key[0] === '_' || is_protected_meta($key, 'post')) {
                continue;
            }
            if (isset($acf_handled_keys[$key])) {
                continue;
            }
            if (aimogen_ai_editor_key_is_excluded($key, $patterns)) {
                continue;
            }
            /* Multiple rows under one key means it is a list, not a text field. */
            if (!is_array($values) || count($values) !== 1) {
                continue;
            }
            $value = maybe_unserialize($values[0]);
            if (!aimogen_ai_editor_value_is_editable($value)) {
                continue;
            }
            if (!aimogen_ai_editor_registered_meta_allows($post, $key)) {
                continue;
            }
            $id = 'meta:' . $key;
            $fields[$id] = array(
                'id'       => $id,
                'kind'     => 'meta',
                'key'      => $key,
                'label'    => aimogen_ai_editor_humanize_key($key),
                'group'    => 'meta',
                'format'   => (strpos((string) $value, '<') !== false) ? 'html' : 'text',
                'value'    => (string) $value,
                'editable_in_editor' => false,
            );
        }
    }

    /* Third parties can add or remove entries here. Anything added is trusted the
       same way the built-in entries are, so integrations are expected to do their
       own capability checks before adding a field. */
    $fields = apply_filters('aimogen_ai_editor_available_meta_fields', $fields, $post->ID, $post);
    $fields = apply_filters('aimogen_ai_editor_available_fields', $fields, $post->ID, $post);

    if (!is_array($fields)) {
        return array();
    }
    return $fields;
}

/**
 * Why this meta key may not be created on this post, or '' when it may.
 *
 * Discovery can only list keys that are already stored, which leaves no way to fill
 * in a custom field that has never been set. A key the user types into the panel is
 * admitted through here instead. It has to clear every rule an existing key clears
 * before it is offered, plus WordPress's own add_post_meta meta-capability - the same
 * gate the core Custom Fields box goes through. The browser contributes the spelling
 * of the key and nothing else; whether it may be written is decided here.
 */
function aimogen_ai_editor_new_meta_key_error($post, $key)
{
    $key = (string) $key;

    /* Must start with a letter, which also rules out the underscore prefix WordPress
       uses for protected meta, and excludes the separators the field ids are built
       from so 'meta:<key>' can never be ambiguous. */
    if ($key === '' || strlen($key) > 255 || !preg_match('/^[A-Za-z][A-Za-z0-9_-]*$/', $key)) {
        return __('A custom field key must start with a letter and contain only letters, numbers, hyphens and underscores.', 'aiomatic-automatic-ai-content-writer');
    }
    if (metadata_exists('post', $post->ID, $key)) {
        return __('This custom field already exists on this post, so pick it from the list instead.', 'aiomatic-automatic-ai-content-writer');
    }
    if (is_protected_meta($key, 'post') ||
        aimogen_ai_editor_key_is_excluded($key, aimogen_ai_editor_excluded_meta_patterns($post->ID))) {
        return __('This key is reserved by WordPress or by another plugin.', 'aiomatic-automatic-ai-content-writer');
    }
    if (!aimogen_ai_editor_registered_meta_allows($post, $key)) {
        return __('This custom field is managed by another plugin and cannot be edited here.', 'aiomatic-automatic-ai-content-writer');
    }
    /* The meta-capability WordPress maps for adding post meta: it re-checks the post's
       own edit capability, protected keys, and any registered auth_callback. */
    if (!current_user_can('add_post_meta', $post->ID, $key)) {
        return __('You are not allowed to add this custom field.', 'aiomatic-automatic-ai-content-writer');
    }
    if (!apply_filters('aimogen_ai_editor_allow_new_meta_key', true, $key, $post)) {
        return __('This custom field cannot be created here.', 'aiomatic-automatic-ai-content-writer');
    }

    return '';
}

/**
 * Add admitted new meta keys to an allow-list, so the rest of the module treats them
 * exactly like a key that was already stored - with an empty current value.
 *
 * Returns the augmented list alongside the keys that were turned down and why, so the
 * panel can say what happened rather than silently dropping a field the user asked for.
 */
function aimogen_ai_editor_admit_new_meta_keys($post, $keys, $available)
{
    $rejected = array();

    if (!($post instanceof WP_Post) || !is_array($keys) || empty($keys)) {
        return array('fields' => $available, 'rejected' => $rejected);
    }
    if (!current_user_can('edit_post', $post->ID)) {
        return array('fields' => $available, 'rejected' => $rejected);
    }

    foreach ($keys as $key) {
        $key = (string) $key;
        $id = 'meta:' . $key;
        if (isset($available[$id])) {
            continue;
        }
        if (count($available) >= AIMOGEN_AI_EDITOR_MAX_FIELDS) {
            $rejected[$id] = __('Too many fields are selected.', 'aiomatic-automatic-ai-content-writer');
            continue;
        }

        $error = aimogen_ai_editor_new_meta_key_error($post, $key);
        if ($error !== '') {
            $rejected[$id] = $error;
            continue;
        }

        $available[$id] = array(
            'id'       => $id,
            'kind'     => 'meta',
            'key'      => $key,
            'label'    => aimogen_ai_editor_humanize_key($key),
            'group'    => 'meta',
            'format'   => 'text',
            'value'    => '',
            'editable_in_editor' => false,
            /* Remembered so Undo can remove the row again rather than leaving an
               empty one behind on a post that never had this key. */
            'is_new'   => true,
        );
    }

    return array('fields' => $available, 'rejected' => $rejected);
}

/**
 * Look a field id up in the server-built list.
 *
 * The single entry point used by the AJAX handlers: an id that is not in the list
 * simply does not resolve, so an invented meta key can never reach the database.
 */
function aimogen_ai_editor_resolve_field($post, $field_id, $available = null)
{
    if ($available === null) {
        $available = aimogen_ai_editor_get_available_fields($post);
    }
    $field_id = (string) $field_id;
    if ($field_id === '' || !isset($available[$field_id])) {
        return null;
    }
    return $available[$field_id];
}

/**
 * Shape sent to the browser. Long values are trimmed for the initial payload; the
 * review UI fetches nothing else because generation returns the current value again.
 */
function aimogen_ai_editor_fields_for_client($fields)
{
    $out = array();
    foreach ($fields as $id => $field) {
        $value = isset($field['value']) ? (string) $field['value'] : '';
        $out[] = array(
            'id'      => (string) $id,
            'label'   => isset($field['label']) ? (string) $field['label'] : (string) $id,
            'key'     => isset($field['key']) ? (string) $field['key'] : '',
            'group'   => isset($field['group']) ? (string) $field['group'] : 'meta',
            'format'  => isset($field['format']) ? (string) $field['format'] : 'text',
            'inEditor' => !empty($field['editable_in_editor']),
            'preview' => aimogen_ai_editor_shorten($value, 160),
            'empty'   => ($value === ''),
        );
    }
    return $out;
}

function aimogen_ai_editor_shorten($value, $length)
{
    $value = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags((string) $value)));
    if ($value === '') {
        return '';
    }
    if (function_exists('mb_strlen') && mb_strlen($value, 'UTF-8') > $length) {
        return mb_substr($value, 0, $length, 'UTF-8') . '…';
    }
    if (strlen($value) > $length) {
        return substr($value, 0, $length) . '…';
    }
    return $value;
}

/**
 * Canonicalize the line endings of a field value.
 *
 * The panel posts with FormData, and the multipart/form-data encoding defined by the
 * HTML standard rewrites every bare LF in a text entry to CRLF. So a multi-line value
 * that left the server as "\n" comes back as "\r\n" without the user touching it.
 * Left alone that breaks two things: the stale-write comparison in
 * aimogen_ai_editor_apply_changes() never matches for post_content or any other
 * multi-line field, and the CRLF would be written into the database.
 *
 * Everything crossing that boundary is therefore normalized to LF, which is what
 * Gutenberg's block serializer and wp_insert_post() produce anyway.
 */
function aimogen_ai_editor_normalize_newlines($value)
{
    return str_replace(array("\r\n", "\r"), "\n", (string) $value);
}
