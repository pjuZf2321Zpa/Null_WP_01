<?php
defined('ABSPATH') or die();

/*
 * Retired and retiring AI models.
 *
 * Providers retire model IDs on fixed dates. After that date Anthropic rejects
 * requests to the retired model, while Google keeps answering them with a newer
 * model, billed at that model's price. This module:
 *
 * - sends requests for a retired Anthropic model to Anthropic's recommended
 *   replacement from the retirement date on, wherever the ID is stored
 *   (settings, rules, shortcodes, forms, agents, reliability fallbacks);
 * - rewrites saved settings once that date has passed;
 * - labels retiring models in every model selector;
 * - warns administrators about retirements that still affect saved settings.
 *
 * Retired IDs deliberately stay in the model constants: removing them would make
 * existing selectors lose their saved value and resave a different model. The exception
 * is models the provider no longer serves at all: they are removed from the lists, saved
 * settings are migrated off them, and request entry points that validate the model resolve
 * it first, so saved references to them keep working.
 */

/**
 * Retirement schedule, keyed by model ID.
 *
 * 'date'            First day the provider stops serving the model (YYYY-MM-DD, UTC).
 * 'replacement'     The provider's recommended or automatic replacement.
 * 'provider_routes' True when the provider itself answers with the replacement, so
 *                   Aimogen leaves those requests alone and only warns.
 *
 * Sources, checked 2026-11-03:
 * https://platform.claude.com/docs/en/about-claude/model-deprecations
 * https://aistudio.google.com/docs/deprecations
 */
function aimogen_model_retirements()
{
    return array(
        'claude-sonnet-4-5-20250929' => array('date' => '2026-11-30', 'replacement' => 'claude-sonnet-5-5'),
        'claude-opus-4-1-20250805'   => array('date' => '2026-08-05', 'replacement' => 'claude-opus-4-8'),
        'claude-opus-4-20250514'     => array('date' => '2026-06-15', 'replacement' => 'claude-opus-4-8'),
        'claude-sonnet-4-20250514'   => array('date' => '2026-06-15', 'replacement' => 'claude-sonnet-5-5'),
        'claude-3-haiku-20240307'    => array('date' => '2026-04-20', 'replacement' => 'claude-haiku-4-5-20251001'),
        'claude-3-7-sonnet-20250219' => array('date' => '2026-02-19', 'replacement' => 'claude-sonnet-5-5'),
        'claude-3-5-haiku-20241022'  => array('date' => '2026-02-19', 'replacement' => 'claude-haiku-4-5-20251001'),
        'gemini-2.5-pro'             => array('date' => '2026-12-01', 'replacement' => 'gemini-3.8-flash', 'provider_routes' => true),
        'gemini-2.5-flash'           => array('date' => '2026-12-01', 'replacement' => 'gemini-3.5-flash-lite', 'provider_routes' => true),
        'gemini-3.7-flash'           => array('date' => '2026-10-08', 'replacement' => 'gemini-3.8-flash', 'provider_routes' => true),
        'gemini-3.5-flash'           => array('date' => '2026-10-08', 'replacement' => 'gemini-3.6-flash', 'provider_routes' => true),
        // Gemini models Google no longer serves at all (404 when checked on 2026-11-03). Unlike the
        // models above they were removed from the model lists, since nobody can use them; saved
        // references still run, on the replacement Google names for its own retired models where it
        // gives one, otherwise on the closest model Aimogen lists.
        'gemini-2.5-pro-exp-03-25'            => array('date' => '2026-11-03', 'replacement' => 'gemini-3.8-flash'),
        'gemini-2.5-flash-preview-04-17'      => array('date' => '2026-11-03', 'replacement' => 'gemini-3.6-flash'),
        'gemini-2.5-flash-lite-preview-06-17' => array('date' => '2026-11-03', 'replacement' => 'gemini-2.5-flash-lite'),
        'gemini-2.0-pro-exp-02-05'            => array('date' => '2026-11-03', 'replacement' => 'gemini-3.8-flash'),
        'gemini-2.0-flash-thinking-exp-01-21' => array('date' => '2026-11-03', 'replacement' => 'gemini-3.8-flash'),
        'gemini-2.0-flash-exp'                => array('date' => '2026-11-03', 'replacement' => 'gemini-3.8-flash'),
        'gemini-2.0-flash'                    => array('date' => '2026-11-03', 'replacement' => 'gemini-3.8-flash'),
        'gemini-2.0-flash-lite'               => array('date' => '2026-11-03', 'replacement' => 'gemini-2.5-flash-lite'),
        'gemma-3-27b-it'                      => array('date' => '2026-11-03', 'replacement' => 'gemini-2.5-flash-lite'),
        'chat-bison-001'                      => array('date' => '2026-11-03', 'replacement' => 'gemini-3.8-flash'),
        'text-bison-001'                      => array('date' => '2026-11-03', 'replacement' => 'gemini-3.8-flash'),
    );
}

/** Retirement entry for a model ID, or null when the model is not retiring. */
function aimogen_model_retirement($model)
{
    if (!is_string($model) || $model === '') {
        return null;
    }
    $retirements = aimogen_model_retirements();
    return isset($retirements[$model]) ? $retirements[$model] : null;
}

/** Whether the provider has stopped serving the model. */
function aimogen_model_retirement_due($entry)
{
    return gmdate('Y-m-d') >= $entry['date'];
}

/** Retirement date in the site's date format. */
function aimogen_model_retirement_date($entry)
{
    // Noon UTC keeps the same calendar day in every site timezone.
    $timestamp = strtotime($entry['date'] . ' 12:00:00 UTC');
    return function_exists('wp_date') ? wp_date(get_option('date_format'), $timestamp) : date_i18n(get_option('date_format'), $timestamp);
}

/**
 * The model to request: Anthropic's replacement once a Claude model has retired,
 * otherwise the model unchanged.
 */
function aimogen_resolve_retired_model($model)
{
    $key = is_string($model) ? trim($model) : $model;
    $entry = aimogen_model_retirement($key);
    if ($entry === null || !empty($entry['provider_routes']) || !aimogen_model_retirement_due($entry)) {
        return $model;
    }
    static $logged = array();
    if (!isset($logged[$key])) {
        $logged[$key] = true;
        aiomatic_log_to_file('Model ' . $key . ' was retired on ' . $entry['date'] . ', using ' . $entry['replacement'] . ' instead.');
    }
    return $entry['replacement'];
}
add_filter('aiomatic_model_selection', 'aimogen_resolve_retired_model');

/**
 * Model selector suffix for a retiring model, e.g.
 * " - retires Nov 30, 2026, then runs as claude-sonnet-5-5". Plain text; callers escape it.
 */
function aimogen_model_retirement_label($model)
{
    $entry = aimogen_model_retirement($model);
    if ($entry === null) {
        return '';
    }
    $due = aimogen_model_retirement_due($entry);
    if (!empty($entry['provider_routes'])) {
        if ($due) {
            /* translators: %s: replacement model ID */
            return sprintf(__(' - retired, answered by %s', 'aiomatic-automatic-ai-content-writer'), $entry['replacement']);
        }
        /* translators: 1: retirement date, 2: replacement model ID */
        return sprintf(__(' - retires %1$s, then answered by %2$s', 'aiomatic-automatic-ai-content-writer'), aimogen_model_retirement_date($entry), $entry['replacement']);
    }
    if ($due) {
        /* translators: %s: replacement model ID */
        return sprintf(__(' - retired, runs as %s', 'aiomatic-automatic-ai-content-writer'), $entry['replacement']);
    }
    /* translators: 1: retirement date, 2: replacement model ID */
    return sprintf(__(' - retires %1$s, then runs as %2$s', 'aiomatic-automatic-ai-content-writer'), aimogen_model_retirement_date($entry), $entry['replacement']);
}

/** Whether an option can hold model selections: Aimogen settings and rule lists, not caches, stats or logs. */
function aimogen_retired_model_option_allowed($name)
{
    if (strpos($name, 'aiomatic_') !== 0 || strpos($name, 'aiomatic_lite_') === 0) {
        return false;
    }
    return !preg_match('/(_model_list|_models|_stats_registry|_activity|_history|_today|_total|_order)$|^aiomatic_last_activity/', $name);
}

/** Names of the options that mention any of the given model IDs. */
function aimogen_retired_model_option_names(array $models)
{
    global $wpdb;
    if (empty($models)) {
        return array();
    }
    $matches = array();
    foreach ($models as $model) {
        $matches[] = $wpdb->prepare('option_value LIKE %s', '%' . $wpdb->esc_like($model) . '%');
    }
    $names = $wpdb->get_col("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'aiomatic\\_%' AND (" . implode(' OR ', $matches) . ')');
    return array_values(array_filter((array) $names, 'aimogen_retired_model_option_allowed'));
}

/**
 * Replace every value that is exactly one of the mapped model IDs. Strings that only
 * contain a model ID (prompts, fallback lists) are left alone; the request filter
 * covers those at run time.
 *
 * @param mixed $value  Option value.
 * @param array $map    Model ID => replacement.
 * @param array $counts Model ID => number of values found, incremented in place.
 */
function aimogen_replace_model_values($value, array $map, array &$counts)
{
    if (is_array($value)) {
        foreach ($value as $key => $item) {
            $value[$key] = aimogen_replace_model_values($item, $map, $counts);
        }
        return $value;
    }
    if (is_string($value) && isset($map[$value])) {
        $counts[$value] = isset($counts[$value]) ? $counts[$value] + 1 : 1;
        return $map[$value];
    }
    return $value;
}

/**
 * Where the given models are selected in saved settings, optionally replacing them.
 *
 * @param array $map  Model ID => replacement.
 * @param bool  $save Whether to write the replacements.
 * @return array Model ID => array(option name => number of values).
 */
function aimogen_scan_retired_model_settings(array $map, $save)
{
    $usage = array();
    foreach (aimogen_retired_model_option_names(array_keys($map)) as $name) {
        $counts = array();
        $value = get_option($name);
        $updated = aimogen_replace_model_values($value, $map, $counts);
        if (empty($counts)) {
            continue;
        }
        if ($save) {
            update_option($name, $updated);
        }
        foreach ($counts as $model => $count) {
            $usage[$model][$name] = $count;
        }
    }
    return $usage;
}

/**
 * Switch saved settings to the replacements and record what changed for the admin notice.
 *
 * @param array $map       Model ID => replacement.
 * @param bool  $mark_done Whether the scheduled migration should skip these models from now on.
 */
function aimogen_apply_retired_model_migration(array $map, $mark_done)
{
    $switched = aimogen_scan_retired_model_settings($map, true);
    if ($mark_done) {
        $done = get_option('aimogen_retired_models_migrated', array());
        $done = array_values(array_unique(array_merge(is_array($done) ? $done : array(), array_keys($map))));
        update_option('aimogen_retired_models_migrated', $done, true);
    }
    if (!empty($switched)) {
        $report = get_option('aimogen_retired_models_report', array());
        if (!is_array($report)) {
            $report = array();
        }
        foreach ($switched as $model => $options) {
            $report[$model] = array('replacement' => $map[$model], 'options' => $options);
        }
        update_option('aimogen_retired_models_report', $report, false);
    }
    delete_transient('aimogen_retired_models_in_use');
}

/** Once per model, after its retirement date, switch saved settings off retired Anthropic models. */
function aimogen_migrate_retired_models()
{
    if (wp_doing_ajax() || wp_doing_cron()) {
        return;
    }
    $done = get_option('aimogen_retired_models_migrated', array());
    if (!is_array($done)) {
        $done = array();
    }
    $map = array();
    foreach (aimogen_model_retirements() as $model => $entry) {
        if (empty($entry['provider_routes']) && aimogen_model_retirement_due($entry) && !in_array($model, $done, true)) {
            $map[$model] = $entry['replacement'];
        }
    }
    if (!empty($map)) {
        aimogen_apply_retired_model_migration($map, true);
    }
}
add_action('admin_init', 'aimogen_migrate_retired_models');

/**
 * Retirements that still affect saved settings: Anthropic models retiring within
 * 60 days, and Google models that Google answers (or will answer) with another model.
 *
 * @return array Model ID => array(option name => number of values).
 */
function aimogen_retired_models_in_use()
{
    $usage = get_transient('aimogen_retired_models_in_use');
    if (is_array($usage)) {
        return $usage;
    }
    $soon = gmdate('Y-m-d', time() + 60 * DAY_IN_SECONDS);
    $map = array();
    foreach (aimogen_model_retirements() as $model => $entry) {
        if (!empty($entry['provider_routes']) || (!aimogen_model_retirement_due($entry) && $entry['date'] <= $soon)) {
            $map[$model] = $model;
        }
    }
    $usage = aimogen_scan_retired_model_settings($map, false);
    set_transient('aimogen_retired_models_in_use', $usage, 12 * HOUR_IN_SECONDS);
    return $usage;
}

/** Re-check usage when a settings option changes. */
function aimogen_retired_models_option_changed($name)
{
    if (is_string($name) && aimogen_retired_model_option_allowed($name)) {
        delete_transient('aimogen_retired_models_in_use');
    }
}
add_action('updated_option', 'aimogen_retired_models_option_changed');
add_action('added_option', 'aimogen_retired_models_option_changed');

/** Readable name for an option in the admin notice. */
function aimogen_retired_model_option_label($name)
{
    $labels = array(
        'aiomatic_Main_Settings'             => __('Main settings', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_Chatbot_Settings'          => __('Chatbot settings', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_Realtime_Chatbot_Settings' => __('Realtime chatbot settings', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_Spinner_Settings'          => __('AI Content Editor settings', 'aiomatic-automatic-ai-content-writer'),
        'aiomatic_Limit_Settings'            => __('Usage limit settings', 'aiomatic-automatic-ai-content-writer'),
    );
    return isset($labels[$name]) ? $labels[$name] : $name;
}

/** "Main settings (2), aiomatic_rules_list (1)" */
function aimogen_retired_model_usage_text(array $options)
{
    $parts = array();
    foreach ($options as $name => $count) {
        $parts[] = aimogen_retired_model_option_label($name) . ' (' . (int) $count . ')';
    }
    return implode(', ', $parts);
}

/** Admin notice: settings that were switched, and retirements still affecting saved settings. */
function aimogen_retired_models_notice()
{
    if (!current_user_can('manage_options')) {
        return;
    }
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($screen === null || (strpos($screen->id, 'aiomatic') === false && !in_array($screen->id, array('dashboard', 'plugins'), true))) {
        return;
    }
    $action_url = admin_url('admin-post.php');

    $report = get_option('aimogen_retired_models_report', array());
    if (is_array($report) && !empty($report)) {
        echo '<div class="notice notice-success"><p><strong>Aimogen Pro:</strong> ' . esc_html__('Saved settings were switched off retired AI models:', 'aiomatic-automatic-ai-content-writer') . '</p><ul class="ul-disc">';
        foreach ($report as $model => $item) {
            echo '<li><code>' . esc_html($model) . '</code> &rarr; <code>' . esc_html($item['replacement']) . '</code>: ' . esc_html(aimogen_retired_model_usage_text($item['options'])) . '</li>';
        }
        echo '</ul><p><a class="button" href="' . esc_url(wp_nonce_url(add_query_arg(array('action' => 'aimogen_dismiss_retired_models', 'notice' => 'report'), $action_url), 'aimogen_dismiss_retired_models')) . '">' . esc_html__('Dismiss', 'aiomatic-automatic-ai-content-writer') . '</a></p></div>';
    }

    $usage = aimogen_retired_models_in_use();
    if (empty($usage) || get_option('aimogen_retired_models_dismissed', '') === md5(serialize($usage))) {
        return;
    }
    $can_switch = false;
    echo '<div class="notice notice-warning"><p><strong>Aimogen Pro:</strong> ' . esc_html__('Some saved settings use AI models that are being retired.', 'aiomatic-automatic-ai-content-writer') . '</p><ul class="ul-disc">';
    foreach ($usage as $model => $options) {
        $entry = aimogen_model_retirement($model);
        $date = aimogen_model_retirement_date($entry);
        if (!empty($entry['provider_routes'])) {
            if (aimogen_model_retirement_due($entry)) {
                /* translators: 1: model ID, 2: retirement date, 3: replacement model ID */
                $text = __('%1$s was retired on %2$s. Google now answers it with %3$s, billed at that model\'s price.', 'aiomatic-automatic-ai-content-writer');
            } else {
                /* translators: 1: model ID, 2: retirement date, 3: replacement model ID */
                $text = __('%1$s retires on %2$s. From then on, Google answers it with %3$s, billed at that model\'s price.', 'aiomatic-automatic-ai-content-writer');
            }
        } else {
            $can_switch = true;
            /* translators: 1: model ID, 2: retirement date, 3: replacement model ID */
            $text = __('%1$s retires on %2$s. From then on, Aimogen sends its requests to %3$s.', 'aiomatic-automatic-ai-content-writer');
        }
        echo '<li>' . esc_html(sprintf($text, $model, $date, $entry['replacement'])) . ' ' . esc_html__('Used in:', 'aiomatic-automatic-ai-content-writer') . ' ' . esc_html(aimogen_retired_model_usage_text($options)) . '</li>';
    }
    echo '</ul><p>' . esc_html__('Pick another model in those settings to choose the replacement yourself. Shortcodes, forms and agents that name a retired Claude model switch automatically on its retirement date.', 'aiomatic-automatic-ai-content-writer') . '</p><p>';
    if ($can_switch) {
        echo '<a class="button button-primary" href="' . esc_url(wp_nonce_url(add_query_arg(array('action' => 'aimogen_switch_retired_models'), $action_url), 'aimogen_switch_retired_models')) . '">' . esc_html__('Switch Claude settings now', 'aiomatic-automatic-ai-content-writer') . '</a> ';
    }
    echo '<a class="button" href="' . esc_url(wp_nonce_url(add_query_arg(array('action' => 'aimogen_dismiss_retired_models', 'notice' => 'usage'), $action_url), 'aimogen_dismiss_retired_models')) . '">' . esc_html__('Dismiss', 'aiomatic-automatic-ai-content-writer') . '</a></p></div>';
}
add_action('admin_notices', 'aimogen_retired_models_notice');

/** "Switch Claude settings now": apply upcoming Anthropic replacements to saved settings before the date. */
function aimogen_switch_retired_models_now()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('You do not have permission to do this.', 'aiomatic-automatic-ai-content-writer'));
    }
    check_admin_referer('aimogen_switch_retired_models');
    $map = array();
    foreach (aimogen_model_retirements() as $model => $entry) {
        if (empty($entry['provider_routes'])) {
            $map[$model] = $entry['replacement'];
        }
    }
    // Not marked done: selections made again before the date are still migrated on it.
    aimogen_apply_retired_model_migration($map, false);
    wp_safe_redirect(wp_get_referer() ? wp_get_referer() : admin_url());
    exit;
}
add_action('admin_post_aimogen_switch_retired_models', 'aimogen_switch_retired_models_now');

/** Dismiss the switched-settings report, or the usage warning until the usage changes. */
function aimogen_dismiss_retired_models_notice()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('You do not have permission to do this.', 'aiomatic-automatic-ai-content-writer'));
    }
    check_admin_referer('aimogen_dismiss_retired_models');
    if (isset($_GET['notice']) && $_GET['notice'] === 'report') {
        delete_option('aimogen_retired_models_report');
    } else {
        update_option('aimogen_retired_models_dismissed', md5(serialize(aimogen_retired_models_in_use())), false);
    }
    wp_safe_redirect(wp_get_referer() ? wp_get_referer() : admin_url());
    exit;
}
add_action('admin_post_aimogen_dismiss_retired_models', 'aimogen_dismiss_retired_models_notice');
