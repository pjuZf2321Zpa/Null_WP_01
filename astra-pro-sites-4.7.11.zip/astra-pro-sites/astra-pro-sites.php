<?php
/**
 * Plugin Name: Premium Starter Templates
 * Plugin URI: https://wpastra.com/
 * Description: Starter Templates is all in one solution for complete starter sites, single page templates, blocks & images. This plugin offers the premium library of ready templates & provides quick access to beautiful Pixabay images that can be imported in your website easily.
 * Version: 4.7.11
 * Requires at least: 6.6
 * Requires PHP: 7.4
 * Author: Brainstorm Force
 * Author URI: https://www.brainstormforce.com
 * Text Domain: astra-sites
 *
 * @package Astra Pro Sites
 */

// Check PHP version before loading the plugin.
if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
	add_action( 'admin_notices', 'astra_pro_sites_php_version_notice' );
	return;
}
/**
 * Display notice if PHP version is below 7.4
 * 
 * @return void
 */
function astra_pro_sites_php_version_notice() {
	$plugin_name = 'Premium Starter Templates';
	?>
	<div class="error">
		<p><?php echo esc_html( $plugin_name . ' requires PHP version 7.4 or higher. Please upgrade your PHP version.' ); ?></p>
	</div>
	<?php
}

define( 'ASTRA_PRO_SITES_NAME', 'Premium Starter Templates' );
define( 'ASTRA_PRO_SITES_VER', '4.7.11' );
define( 'ASTRA_PRO_SITES_FILE', __FILE__ );
define( 'ASTRA_PRO_SITES_BASE', plugin_basename( ASTRA_PRO_SITES_FILE ) );
define( 'ASTRA_PRO_SITES_DIR', plugin_dir_path( ASTRA_PRO_SITES_FILE ) );
define( 'ASTRA_PRO_SITES_URI', plugins_url( '/', ASTRA_PRO_SITES_FILE ) );

// GPL Vault: activate the Astra Pro family locally (mark as free) and mute usage tracking. Additive filters only.
// Remove down to "END GPL Vault" to restore upstream behaviour.
if ( ! function_exists( 'gplvault_bsf_astra_license' ) ) {
	/**
	 * Report the Astra Pro family products as free products.
	 *
	 * BSF_License_Manager::bsf_is_active_license() returns true for any product
	 * flagged 'is_product_free' before it performs a remote check, so this activates
	 * the product with no purchase key and no licence-server round-trip. Scoped to our
	 * own product IDs so unrelated Brainstorm Force products are left untouched.
	 *
	 * @param mixed $value Stored value of the 'brainstrom_products' option.
	 * @return mixed Filtered value.
	 */
	function gplvault_bsf_astra_license( $value ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}
		$slugs = array( 'astra-addon', 'astra-pro-sites', 'astra-portfolio' );
		foreach ( array( 'plugins', 'themes' ) as $group ) {
			if ( empty( $value[ $group ] ) || ! is_array( $value[ $group ] ) ) {
				continue;
			}
			foreach ( $slugs as $slug ) {
				if ( isset( $value[ $group ][ $slug ] ) && is_array( $value[ $group ][ $slug ] ) ) {
					$value[ $group ][ $slug ]['is_product_free'] = 'true';
				}
			}
		}
		return $value;
	}
	add_filter( 'option_brainstrom_products', 'gplvault_bsf_astra_license' );
	add_filter( 'site_option_brainstrom_products', 'gplvault_bsf_astra_license' );
	add_filter( 'bsf_usage_tracking_enabled', '__return_false' );
}

// GPL Vault: route the premium template + block library API through our licensed proxy, which injects the purchase key server-side so it never ships to customers.
// Remove down to "END GPL Vault" to restore upstream behaviour.
if ( ! defined( 'STARTER_TEMPLATES_REMOTE_URL' ) ) {
	define( 'STARTER_TEMPLATES_REMOTE_URL', 'https://st.gplvault.com/' );
}
add_filter(
	'ast_block_templates_library_url',
	static function () {
		return 'https://st.gplvault.com/';
	}
);
// The importer only trusts data-file hosts matching the API domain; the JSON/WXR/images still live on websitedemos.net, so keep it allowed as upstream does.
add_filter(
	'astra_sites_valid_url',
	static function ( $hosts ) {
		$hosts   = (array) $hosts;
		$hosts[] = 'websitedemos.net';
		return $hosts;
	}
);
// END GPL Vault.

if ( ! function_exists( 'astra_pro_sites_setup' ) ) :

	/**
	 * Astra Sites Setup
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function astra_pro_sites_setup() {

		require_once ASTRA_PRO_SITES_DIR . 'classes/class-astra-pro-sites.php';

		// Graupi.
		require_once 'class-brainstorm-update-astra-pro-sites.php';

		if ( ! class_exists( 'Astra_Sites' ) ) {
			require_once ASTRA_PRO_SITES_DIR . 'astra-sites.php';
		}
	}

	add_action( 'plugins_loaded', 'astra_pro_sites_setup', 11 );

endif;


if ( ! function_exists( 'astra_pro_sites_fetch_bundled_products' ) ) :

	/**
	 * Fetch Bundled Products
	 *
	 * @since 1.1.2 Checking required plugins on `register_activation_hook` hook instead of `admin_init`.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function astra_pro_sites_fetch_bundled_products() {
		update_site_option( 'bsf_force_check_extensions', true );
	}

	register_activation_hook( __FILE__, 'astra_pro_sites_fetch_bundled_products' );

endif;


if ( ! function_exists( 'astra_sites_redirect_to_onboarding' ) ) :

	/**
	 * Redirect to onboarding.
	 *
	 * @since 3.3.0
	 * @return void
	 */
	function astra_sites_redirect_to_onboarding() {
		if ( ! get_option( 'st_start_onboarding', false ) ) {
			return;
		}

		delete_option( 'st_start_onboarding' );
		if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) {

			/**
			 * Filters whether to redirect after Starter Templates is activated.
			 *
			 * @since 4.7.5
			 *
			 * @param bool $do_redirect Whether to redirect. Default true.
			 */
			if ( ! apply_filters( 'astra_sites_do_activation_redirect', true ) ) {
				return;
			}

			if ( ! class_exists( 'Astra_Sites' ) ) {
				require_once ASTRA_PRO_SITES_DIR . '/inc/classes/class-astra-sites.php';
			}
			// Use helper function to get URL with appropriate ci parameter based on flags.
			$redirect_url = Astra_Sites::get_starter_templates_url();
			wp_safe_redirect( $redirect_url );
			exit();
		}
	}

	add_action( 'admin_init', 'astra_sites_redirect_to_onboarding' );

endif;

if ( ! function_exists( 'astra_pro_sites_activate' ) ) :

	/**
	 * Astra pro sites activate.
	 *
	 * @since 4.1.2
	 * @return void
	 */
	function astra_pro_sites_activate() {
		update_option( 'st_start_onboarding', true );
	}
	register_activation_hook( __FILE__, 'astra_pro_sites_activate' );

endif;

if ( ! function_exists( 'astra_pro_sites_deactivate' ) ) :

	/**
	 * Clean up import state options on plugin deactivation.
	 *
	 * Prevents stale import flags from persisting in wp_options and
	 * causing database conflicts during WP-Cron after deactivation.
	 *
	 * @since 4.5.4
	 * @return void
	 */
	function astra_pro_sites_deactivate() {
		delete_option( 'astra_sites_batch_process_started' );
		delete_option( 'astra_sites_batch_process_started_time' );
		delete_option( 'astra_sites_batch_process_complete' );
		delete_option( 'astra_sites_ai_import_started' );
		delete_option( 'ast_ai_import_current_url' );
		delete_option( 'astra_sites_import_started' );
		delete_option( 'astra_sites_current_import_template_type' );
		delete_option( 'astra_sites_import_data_fallback' );
		delete_option( 'astra_sites_import_data_saved_time' );
	}
	register_deactivation_hook( __FILE__, 'astra_pro_sites_deactivate' );

endif;
