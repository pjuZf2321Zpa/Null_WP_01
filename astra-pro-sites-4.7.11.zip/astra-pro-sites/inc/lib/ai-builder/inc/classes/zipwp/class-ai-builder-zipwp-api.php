<?php
/**
 * Ai Builder
 *
 * @since  1.0.0
 * @package Ai Builder
 */

namespace AiBuilder\Inc\Classes\Zipwp;

use AiBuilder\Inc\Classes\Ai_Builder_Importer_Log;
use AiBuilder\Inc\Traits\Helper;
use AiBuilder\Inc\Traits\Instance;
use STImporter\Importer\ST_Importer_File_System;
use STImporter\Importer\WXR_Importer\ST_WXR_Importer;

/**
 * Class ZipWP API
 *
 * @since 1.0.0
 */
class Ai_Builder_ZipWP_Api {
	use Instance;
	/**
	 * Constructor
	 *
	 * @since 4.0.0
	 */
	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_route' ) );
	}

	/**
	 * Get api domain
	 *
	 * @since 4.0.0
	 * @param bool $v1 Check for V1.
	 * @return string
	 */
	public function get_api_domain( $v1 = true ) {
		if ( $v1 ) {
			return defined( 'ZIPWP_API_V1' ) ? ZIPWP_API_V1 : 'https://api.zipwp.com/api/v1/';
		}

		return defined( 'ZIPWP_API' ) ? ZIPWP_API : 'https://api.zipwp.com/api/';
	}

	/**
	 * Get api namespace
	 *
	 * @since 4.0.0
	 * @return string
	 */
	public function get_api_namespace() {
		return 'zipwp/v1';
	}

	/**
	 * Get API headers
	 *
	 * @param bool $locale Check for locale.
	 * @since 4.0.0
	 * @return array<string, string>
	 */
	public function get_api_headers( $locale = false ) {
		$headers = array(
			'Content-Type'  => 'application/json',
			'Accept'        => 'application/json',
			'Authorization' => 'Bearer ' . Ai_Builder_ZipWP_Integration::get_token(),
		);

		if ( $locale ) {
			$locale = get_locale();
			if ( 'en_US' !== $locale ) {
				// Getting translation codes.
				$iso_locale = $locale;
				if ( strpos( $iso_locale, '_' ) !== false ) {
					$iso_locale = strstr( $locale, '_', true );
				}
				$headers['X-Zip-Locale'] = $iso_locale ? $iso_locale : 'en';
			}
		}

		return $headers;
	}

	/**
	 * Check whether a given request has permission to read notes.
	 *
	 * @param  object $request WP_REST_Request Full details about the request.
	 * @return object|bool
	 */
	public function get_item_permissions_check( $request ) {

		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error(
				'gt_rest_cannot_access',
				__( 'Sorry, you are not allowed to do that.', 'astra-sites' ),
				array( 'status' => rest_authorization_required_code() )
			);
		}
		return true;
	}

	/**
	 * Set the dismiss time for the plan promotion.
	 *
	 * @return \WP_REST_Response|\WP_Error Response object on success, or WP_Error object on failure.
	 */
	public function set_plan_promo_dismiss_time() {
		$dismiss_time = time();
		update_option( 'ai_builder_promo_dismiss_time', $dismiss_time );

		return new \WP_REST_Response( array( 'success' => true ), 200 );
	}

	/**
	 * Get the dismiss time for the plan promotion.
	 *
	 * @return \WP_REST_Response|\WP_Error Response object on success, or WP_Error object on failure.
	 */
	public function get_plan_promo_dismiss_time() {
		$dismisstime = get_option( 'ai_builder_promo_dismiss_time', 0 );

		return new \WP_REST_Response(
			array(
				'success'      => true,
				'dismiss_time' => $dismisstime,
			),
			200
		);
	}

	/**
	 * Register route
	 *
	 * @since 4.0.0
	 * @return void
	 */
	public function register_route() {
		$namespace = $this->get_api_namespace();

		register_rest_route(
			$namespace,
			'/description/',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'get_description' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'business_name'        => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'business_description' => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'category'             => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
							'required'          => false,
						),
					),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/images/',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'get_images' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'keywords'    => array(
							'type'     => 'string',
							'required' => true,
						),
						'per_page'    => array(
							'type'     => 'string',
							'required' => false,
						),
						'page'        => array(
							'type'     => 'string',
							'required' => false,
						),
						'orientation' => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
							'required'          => false,
						),
						'engine'      => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/record-step/',
			[
				[
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'record_step' ],
					'permission_callback' => [ $this, 'get_item_permissions_check' ],
					'args'                => [
						'action'            => [
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						],
						'current_step'      => [
							'type'              => 'integer',
							'required'          => true,
							'sanitize_callback' => 'absint',
						],
						'current_step_name' => [
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						],
						'funnel_session_id' => [
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						],
					],
				],
			]
		);

		register_rest_route(
			$namespace,
			'/keywords/',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'get_keywords' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'business_name'        => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'business_description' => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'category'             => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
							'required'          => false,
						),
					),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/template-keywords/',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'get_template_keywords' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'business_name'        => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'business_description' => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'business_category'    => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
							'required'          => false,
						),
					),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/categories/',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_categories' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/site-features/',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_site_features' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/site-languages/',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_site_languages' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/get-credits/',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_user_credits' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/import-status/',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_import_status' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/restore-credit/',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'restore_credit' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/migration-status/',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_migration_status' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/templates/',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'get_templates' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'business_name' => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'keywords'      => array(
							'type'     => 'array',
							'required' => false,
							'items'    => array(
								'type' => 'string',
							),
						),
						'page_builder'  => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
							'required'          => false,
						),
					),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/all-templates/',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'get_all_templates' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'business_name' => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'per_page'      => array(
							'type'     => 'integer',
							'required' => false,
						),
						'page'          => array(
							'type'     => 'integer',
							'required' => false,
						),
						'page_builder'  => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
							'required'          => false,
						),
						'keyword'       => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'sort'          => array(
							'type'              => 'object',
							'required'          => false,
							'validate_callback' => static function ( $value ) {
								if ( ! is_array( $value ) ) {
									return new \WP_Error( 'invalid_sort', __( 'Invalid sort parameter.', 'astra-sites' ) );
								}
								$allowed_by    = array( 'newest', 'premium' );
								$allowed_order = array( 'asc', 'desc' );
								if ( isset( $value['by'] ) && ! in_array( $value['by'], $allowed_by, true ) ) {
									return new \WP_Error( 'invalid_sort_by', __( 'Invalid sort.by value.', 'astra-sites' ) );
								}
								if ( isset( $value['order'] ) && ! in_array( $value['order'], $allowed_order, true ) ) {
									return new \WP_Error( 'invalid_sort_order', __( 'Invalid sort.order value.', 'astra-sites' ) );
								}
								return true;
							},
						),
					),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/user-details/',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'save_user_details' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'business_description' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'business_name'        => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'business_addeess'     => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'business_phone'       => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'business_email'       => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'social_profiles'      => array(
							'type'     => 'array',
							'required' => false,
						),
						'business_category'    => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
							'required'          => true,
						),
						'site_language'        => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
							'required'          => true,
						),
						'keywords'             => array(
							'type'     => 'array',
							'required' => true,
						),
						'images'               => array(
							'type'     => 'array',
							'required' => true,
						),
					),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/site/',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_site' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'template' => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/wxr/',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'prepare_xml' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'template'             => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'business_name'        => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'business_description' => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'language'             => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/ai-site/',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'get_demo' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'template'      => array(
							'type'              => 'string',
							'required'          => true,
							'sanitize_callback' => 'sanitize_text_field',
						),
						'business_name' => array(
							'type'              => 'string',
							'required'          => false,
							'sanitize_callback' => 'sanitize_text_field',
						),
					),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/zip-plan/',
			array(
				'methods'             => \WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'get_zip_plan_details' ),
				'permission_callback' => array( $this, 'get_item_permissions_check' ),
				'args'                => array(),
			)
		);

		register_rest_route(
			$namespace,
			'/search-category/',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'search_business_category' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'keyword' => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_text_field',
							'required'          => true,
						),
					),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/import-error-log/',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_error_log' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/set-step-data/',
			array(
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'set_step_data' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'business_details' => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/set-plan-promo-dismiss-time/',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'set_plan_promo_dismiss_time' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
				),
			)
		);

		register_rest_route(
			$namespace,
			'/get-plan-promo-dismiss-time/',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_plan_promo_dismiss_time' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
				),
			)
		);
	}

	/**
	 * Update onboarding data.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 *
	 * @since 1.2.3
	 */
	public function set_step_data( $request ) {

		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$business_details     = isset( $request['business_details'] ) ? json_decode( $request['business_details'], true ) : array();
		$old_business_details = get_option( 'zipwp_user_business_details', array() );

		if ( ! is_array( $old_business_details ) ) {
			$old_business_details = array();
		}

		// Canonical business-detail keys; intersecting against the stored option would wipe first writes.
		$allowed_keys = array(
			'business_name'          => true,
			'business_address'       => true,
			'business_phone'         => true,
			'business_email'         => true,
			'business_category'      => true,
			'business_category_name' => true,
			'business_description'   => true,
			'templates'              => true,
			'language'               => true,
			'images'                 => true,
			'image_keyword'          => true,
			'social_profiles'        => true,
		);

		if ( is_array( $business_details ) && ! empty( $business_details ) ) {
			// Failed-site step_data stores the description under business_desc.
			if ( isset( $business_details['business_desc'] ) && ! isset( $business_details['business_description'] ) ) {
				$business_details['business_description'] = $business_details['business_desc'];
			}
			$business_details = array_merge( $old_business_details, array_intersect_key( $business_details, $allowed_keys ) );
		}
		update_option( 'zipwp_user_business_details', $business_details );
		delete_option( 'ast_sites_downloaded_images' );

		wp_send_json_success(
			array(
				'status' => true,
			)
		);
	}

	/**
	 * Get the error log details
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 *
	 * @since 1.0.36
	 */
	public function get_error_log( $request ) {

		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		wp_send_json_success(
			array(
				'data'   => get_option( 'ai_import_logger', array() ),
				'status' => true,
			)
		);
	}

	/**
	 * Get the zip plan details
	 *
	 * @return \WP_REST_Response
	 *
	 * @since 4.0.0
	 */
	public function get_zip_plan_details() {
		$zip_plan = $this->get_zip_plans();

		$response = new \WP_REST_Response(
			array(
				'success' => $zip_plan['status'],
				'data'    => $zip_plan['data'],
			)
		);
		$response->set_status( 200 );
		return $response;
	}

	/**
	 * Get ZIP Plans.
	 *
	 * @return array<string, mixed>
	 */
	public function get_zip_plans() {
		$api_endpoint = $this->get_api_domain( false ) . '/plan/current-plan';

		$request_args = array(
			'headers' => $this->get_api_headers(),
			'timeout' => 100,
		);
		$response     = wp_safe_remote_get( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			return array(
				/* translators: %s is the error message */
				'data'   => sprintf( __( 'Failed %s', 'astra-sites' ), $response->get_error_message() ),
				'status' => false,
			);
		}

		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );

		if ( 200 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			if ( $response_data ) {
				return array(
					'data'   => $response_data,
					'status' => true,
				);
			}

			return array(
				'error_code' => 'invalid_response',
				'data'       => $response_data,
				'status'     => false,
			);
		}

		// Handle Team Not Found response.
		if ( 404 === $response_code ) {
			return array(
				'error_code' => 'team_not_found',
				'data'       => __( 'Your ZipWP team was not found. Please reconnect your account to continue.', 'astra-sites' ),
				'status'     => false,
			);
		}

		// Handle Unauthenticated response.
		if ( 401 === $response_code ) {
			/**
			 * Filter the unauthenticated message for ZipWP plan.
			 *
			 * @param string $unauthenticated_message The unauthenticated message.
			 * @since 1.2.67
			 */
			$unauthenticated_message = apply_filters(
				'ai_builder_zipwp_plan_unauthenticated_message',
				__( "We couldn't verify an active plan for your account. Please check your ZipWP subscription.", 'astra-sites' )
			);

			return array(
				'error_code' => 'unauthenticated',
				'data'       => $unauthenticated_message,
				'status'     => false,
			);
		}

		return array(
			'error_code' => 'failed',
			'data'       => 'Failed',
			'status'     => false,
		);
	}

	/**
	 * Create site.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function create_site( $request ) {

		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$api_endpoint = $this->get_api_domain( false ) . '/starter-templates/site/';

		$post_data = array(
			'template'               => isset( $request['template'] ) ? sanitize_text_field( $request['template'] ) : '',
			'business_email'         => isset( $request['business_email'] ) ? $request['business_email'] : '',
			'email'                  => $this->get_zip_user_email(),
			'business_desc'          => isset( $request['business_description'] ) ? $request['business_description'] : '',
			'business_name'          => isset( $request['business_name'] ) ? $request['business_name'] : '',
			'title'                  => isset( $request['business_name'] ) ? $request['business_name'] : '',
			'business_phone'         => isset( $request['business_phone'] ) ? $request['business_phone'] : '',
			'business_address'       => isset( $request['business_address'] ) ? $request['business_address'] : '',
			'business_category'      => isset( $request['business_category'] ) ? $request['business_category'] : '',
			'business_category_name' => isset( $request['business_category'] ) ? $request['business_category'] : '',
			'image_keyword'          => isset( $request['image_keyword'] ) ? $request['image_keyword'] : '',
			'social_profiles'        => isset( $request['social_profiles'] ) ? $request['social_profiles'] : [],
			'images'                 => isset( $request['images'] ) ? $request['images'] : '',
			'language'               => isset( $request['language'] ) ? $request['language'] : 'en',
			'site_type'              => 'ai',
			'site_source'            => self::get_site_source(),
			'site_features'          => isset( $request['site_features'] ) ? $request['site_features'] : [],
			'site_features_data'     => isset( $request['site_features_data'] ) ? $request['site_features_data'] : [],
		);

		if ( empty( $post_data['images'] ) ) {
			$post_data['images'] = Helper::get_image_placeholders();
		}

		$body = wp_json_encode( $post_data );

		$request_args = array(
			'body'    => is_string( $body ) ? $body : '',
			'headers' => $this->get_api_headers(),
			'timeout' => 1000,
		);
		$response     = wp_safe_remote_post( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,
				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		$response_data = json_decode( $response_body, true );

		if ( 201 === $response_code || 200 === $response_code ) {

			$site_data = is_array( $response_data ) ? $response_data['site'] : array();
			if ( is_array( $site_data ) ) {
				$site_data['step_data'] = $post_data;
			}
			update_option( 'zipwp_import_site_details', $site_data );

			if ( is_array( $response_data ) && isset( $response_data['affiliate_ids'] ) ) {
				self::set_partner_affiliate_ids( $response_data['affiliate_ids'] );
			}

			wp_send_json_success(
				array(
					'http_status_code' => $response_code,
					'data'             => $response_data,
				)
			);
		} else {
			wp_send_json_error(
				array(
					'http_status_code' => $response_code,
					'data'             => $response_data,
				)
			);
		}
	}

	/**
	 * Prepare site XML.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function prepare_xml( $request ) {

		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$api_endpoint = $this->get_api_domain( false ) . '/starter-templates/wxr/';

		$post_data    = array(
			'template'      => isset( $request['template'] ) ? sanitize_text_field( $request['template'] ) : '',
			'business_name' => isset( $request['business_name'] ) ? $request['business_name'] : '',
		);
		$body         = wp_json_encode( $post_data );
		$request_args = array(
			'body'    => is_string( $body ) ? $body : '',
			'headers' => $this->get_api_headers(),
			'timeout' => 1000,
		);
		$response     = wp_safe_remote_post( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,
				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		if ( 201 === $response_code || 200 === $response_code ) {
			if ( $response_body ) {
				// Get the WordPress upload directory.
				$upload_dir = wp_upload_dir();

				// Define the file path where the attachment will be saved.
				$file_path = $upload_dir['path'] . '/wxr.xml';

				// Save the XML content to a file.
				file_put_contents( $file_path, $response_body ); //phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
				require_once ABSPATH . 'wp-admin/includes/image.php';
				// Prepare the attachment data.
				$attachment = array(
					'post_title'     => 'Response XML',
					'post_mime_type' => 'application/xml',
					'post_content'   => '',
					'post_status'    => 'inherit',
				);

				Ai_builder_Importer_Log::add( (string) wp_json_encode( $attachment ) );
				Ai_builder_Importer_Log::add( (string) wp_json_encode( $file_path ) );

				// Insert the attachment into the media library.
				$attachment_id = wp_insert_attachment( $attachment, $file_path );

				Ai_builder_Importer_Log::add( (string) wp_json_encode( $attachment_id ) );

				if ( empty( $attachment_id ) ) {
					wp_send_json_error( __( 'There was an error downloading the XML file.', 'astra-sites' ) );
				} else {

					update_option( 'astra_sites_imported_wxr_id', $attachment_id, false );
					$attachment_metadata = wp_generate_attachment_metadata( $attachment_id, $file_path );
					wp_update_attachment_metadata( $attachment_id, $attachment_metadata );

					if ( class_exists( 'STImporter\Importer\WXR_Importer\ST_WXR_Importer' ) ) {
						$data        = ST_WXR_Importer::get_xml_data( $file_path, $attachment_id );
						$data['xml'] = $file_path;
						wp_send_json_success( $data );
					} else {
						wp_send_json_error( __( 'Required class not found.', 'astra-sites' ) );
					}
				}
			} else {
				wp_send_json_error(
					array(
						'data'   => 'Failed ' . $response_body,
						'status' => false,

					)
				);
			}
		} else {
			wp_send_json_error(
				array(
					'data'   => 'Failed - ' . $response_body,
					'status' => false,

				)
			);
		}
	}

	/**
	 * Get AI demo site.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function get_demo( $request ) {

		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$api_endpoint = $this->get_api_domain( false ) . '/starter-templates/export/' . sanitize_text_field( $request['uuid'] );

		$post_data    = array(
			'template'      => isset( $request['template'] ) ? sanitize_text_field( $request['template'] ) : '',
			'business_name' => isset( $request['business_name'] ) ? $request['business_name'] : '',
		);
		$body         = wp_json_encode( $post_data );
		$request_args = array(
			'body'    => is_string( $body ) ? $body : '',
			'headers' => $this->get_api_headers(),
			'timeout' => 1000,
		);
		$response     = wp_safe_remote_post( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,
				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );

		/*
		 * Transient upstream states while the async site-build job is still
		 * writing its export data. A fetch that lands before that job commits
		 * returns one of these; the frontend retries them instead of failing
		 * the import. 202 = build accepted/pending, 404 = export data not
		 * persisted yet.
		 */
		$retryable_codes = array( 202, 404 );
		$is_retryable    = in_array( (int) $response_code, $retryable_codes, true );

		if ( 201 === $response_code || 200 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			if ( is_array( $response_data ) ) {
				$exported_data = $response_data['data'] ?? null;

				// An empty export means the build job has not committed its data yet. Saving it
				// would make every import step fail with empty data, so let the frontend retry.
				if ( empty( $exported_data ) || ! is_array( $exported_data ) ) {
					wp_send_json_error(
						array(
							'data'      => __( 'Website data is not ready yet. Please try again.', 'astra-sites' ),
							'status'    => false,
							'code'      => $response_code,
							'retryable' => true,
						)
					);
				}

				$exported_data['astra-site-url'] = $exported_data['host'] ?? '';

				if ( class_exists( 'STImporter\Importer\ST_Importer_File_System' ) ) {
					ST_Importer_File_System::get_instance()->update_demo_data( $exported_data );
				}

				update_option( 'astra_sites_current_import_template_type', 'ai' );
				update_option( 'astra_sites_batch_process_complete', 'no' );
				$host_url = $exported_data['host'] ?? '';
				update_option( 'ast_ai_import_current_url', $host_url );
				wp_cache_flush();
				wp_send_json_success(
					array(
						'data'   => $exported_data,
						'status' => true,
					)
				);
			} else {
				wp_send_json_error(
					array(
						'data'      => 'Failed - ' . $response_body,
						'status'    => false,
						'code'      => $response_code,
						'retryable' => $is_retryable,
					)
				);
			}
		} else {
			wp_send_json_error(
				array(
					'data'      => 'Failed - ' . $response_body,
					'status'    => false,
					'code'      => $response_code,
					'retryable' => $is_retryable,
				)
			);
		}
	}

	/**
	 * Save user details.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function save_user_details( $request ) {

		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$email = $this->get_zip_user_email();

		$api_endpoint = $this->get_api_domain() . '/sites/generate-cache/';

		$business_details = array(
			'business_description'   => isset( $request['business_description'] ) ? sanitize_text_field( $request['business_description'] ) : '',
			'business_name'          => isset( $request['business_name'] ) ? sanitize_text_field( $request['business_name'] ) : '',
			'business_email'         => isset( $request['business_email'] ) ? sanitize_text_field( $request['business_email'] ) : '',
			'business_address'       => isset( $request['business_address'] ) ? sanitize_text_field( $request['business_address'] ) : '',
			'business_phone'         => isset( $request['business_phone'] ) ? sanitize_text_field( $request['business_phone'] ) : '',
			'business_category'      => isset( $request['business_category'] ) ? sanitize_text_field( $request['business_category'] ) : '',
			'business_category_name' => isset( $request['business_category'] ) ? sanitize_text_field( $request['business_category'] ) : '',
			'image_keyword'          => isset( $request['keywords'] ) ? $request['keywords'] : [],
			'images'                 => isset( $request['images'] ) ? $request['images'] : [],
			'social_profiles'        => isset( $request['social_profiles'] ) ? $request['social_profiles'] : [],
			'language'               => isset( $request['site_language'] ) ? sanitize_text_field( $request['site_language'] ) : 'en',
			'templates'              => get_option( 'zipwp_selection_templates', array() ),
		);

		update_option(
			'zipwp_user_business_details',
			$business_details
		);

		if ( empty( $business_details['images'] ) ) {
			$business_details['images'] = Helper::get_image_placeholders();
		}

		$post_data              = array_merge( $business_details, [ 'email' => $email ] );
		$post_data['templates'] = [];

		$body = wp_json_encode( $post_data );

		$request_args = array(
			'body'    => is_string( $body ) ? $body : '',
			'headers' => $this->get_api_headers(),
			'timeout' => 100,
		);
		$response     = wp_safe_remote_post( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,

				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		if ( 200 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			wp_send_json_success(
				array(
					'data'   => $response_data,
					'status' => true,
				)
			);

		} else {
			wp_send_json_error(
				array(
					'data'   => 'Failed - ' . $response_body,
					'status' => false,

				)
			);
		}
	}

	/**
	 * Get AI based description.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function get_description( $request ) {

		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$api_endpoint = $this->get_api_domain() . '/sites/suggest-description/';

		$post_data = array(
			'business_name'     => isset( $request['business_name'] ) ? sanitize_text_field( $request['business_name'] ) : '',
			'business_desc'     => isset( $request['business_description'] ) ? sanitize_text_field( $request['business_description'] ) : '',
			'business_category' => isset( $request['category'] ) ? sanitize_text_field( $request['category'] ) : '',
			'language'          => isset( $request['language'] ) ? sanitize_text_field( $request['language'] ) : 'en',
		);

		$body = wp_json_encode( $post_data );

		$request_args = array(
			'body'    => is_string( $body ) ? $body : '',
			'headers' => $this->get_api_headers(),
			'timeout' => 100,
		);
		$response     = wp_safe_remote_post( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,

				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		if ( 200 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			if ( is_array( $response_data ) && $response_data['description'] ) {
				wp_send_json_success(
					array(
						'data'   => $response_data['description'],
						'status' => true,
					)
				);
			} else {
				wp_send_json_error(
					array(
						'data'   => 'Failed ' . $response_data,
						'status' => false,

					)
				);
			}
		} else {
			wp_send_json_error(
				array(
					'data'   => 'Failed',
					'status' => false,

				)
			);
		}
	}

	/**
	 * Get Images.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function get_images( $request ) {

		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$api_endpoint = $this->get_api_domain() . '/sites/images/';

		$post_data = array(
			'keywords'    => isset( $request['keywords'] ) ? [ $request['keywords'] ] : [],
			'per_page'    => isset( $request['per_page'] ) ? $request['per_page'] : 20,
			'page'        => isset( $request['page'] ) ? $request['page'] : 1,
			'orientation' => isset( $request['orientation'] ) ? sanitize_text_field( $request['orientation'] ) : '',
			'engine'      => isset( $request['engine'] ) ? sanitize_text_field( $request['engine'] ) : '',
		);

		$body = wp_json_encode( $post_data );

		$request_args = array(
			'body'    => is_string( $body ) ? $body : '',
			'headers' => $this->get_api_headers(),
			'timeout' => 100,
		);
		$response     = wp_safe_remote_post( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,

				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		if ( 200 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			wp_send_json_success(
				array(
					'data'   => is_array( $response_data ) ? $response_data['images'] : '',
					'status' => true,
				)
			);

		} else {
			wp_send_json_error(
				array(
					'data'   => 'Failed',
					'status' => false,

				)
			);
		}
	}

	/**
	 * Get Keywords for image search.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function get_keywords( $request ) {

		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$api_endpoint = $this->get_api_domain() . '/sites/images/keywords/';

		$post_data = array(
			'business_desc' => isset( $request['business_description'] ) ? sanitize_text_field( $request['business_description'] ) : '',
		);

		$body = wp_json_encode( $post_data );

		$request_args = array(
			'body'    => is_string( $body ) ? $body : '',
			'headers' => $this->get_api_headers(),
			'timeout' => 100,
		);
		$response     = wp_safe_remote_post( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,

				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		if ( 200 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			if ( is_array( $response_data ) ) {
				wp_send_json_success(
					array(
						'data'   => $response_data['keywords'],
						'status' => true,
					)
				);
			} else {
				wp_send_json_error(
					array(
						'data'   => 'Failed ' . $response_data,
						'status' => false,

					)
				);
			}
		} else {
			wp_send_json_error(
				array(
					'data'   => 'Failed',
					'status' => false,

				)
			);
		}
	}

	/**
	 * Get Template Keywords for image search.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function get_template_keywords( $request ) {

		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$api_endpoint = $this->get_api_domain() . '/sites/templates/keywords';

		$post_data = array(
			'business_desc'          => isset( $request['business_description'] ) ? sanitize_text_field( $request['business_description'] ) : '',
			'business_cat'           => isset( $request['business_category'] ) ? sanitize_text_field( $request['business_category'] ) : '',
			'business_category_name' => isset( $request['business_category'] ) ? sanitize_text_field( $request['business_category'] ) : '',
			'business_name'          => isset( $request['business_name'] ) ? sanitize_text_field( $request['business_name'] ) : '',
			'language'               => 'en',
		);

		$body = wp_json_encode( $post_data );

		$request_args = array(
			'body'    => is_string( $body ) ? $body : '',
			'headers' => $this->get_api_headers(),
			'timeout' => 100,
		);
		$response     = wp_safe_remote_post( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,

				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		if ( 200 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			if ( is_array( $response_data ) ) {
				wp_send_json_success(
					array(
						'data'   => $response_data['keywords'],
						'status' => true,
					)
				);
			} else {
				wp_send_json_error(
					array(
						'data'   => 'Failed ' . $response_data,
						'status' => false,

					)
				);
			}
		} else {
			wp_send_json_error(
				array(
					'data'   => 'Failed',
					'status' => false,

				)
			);
		}
	}

	/**
	 * Get Keywords for image search.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function get_templates( $request ) {

		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$keywords = isset( $request['keywords'] ) && is_array( $request['keywords'] )
			? array_map( 'sanitize_text_field', $request['keywords'] )
			: array( 'multipurpose' );
		$keyword  = implode(
			',',
			array_map(
				'rawurlencode',
				array_filter(
					$keywords,
					static function ( $item ) {
						return '' !== $item;
					}
				)
			)
		);

		if ( '' === $keyword ) {
			$keyword = 'multipurpose';
		}

		$api_endpoint = add_query_arg( 'query', $keyword, $this->get_api_domain() . '/sites/templates/search' );

		$post_data = array(
			'business_name' => isset( $request['business_name'] ) ? sanitize_text_field( $request['business_name'] ) : '',
			'page_builder'  => isset( $request['page_builder'] ) ? sanitize_text_field( $request['page_builder'] ) : 'spectra',
			'email'         => $this->get_zip_user_email(),
		);

		$body = wp_json_encode( $post_data );

		$request_args = array(
			'body'    => is_string( $body ) ? $body : '',
			'headers' => $this->get_api_headers(),
			'timeout' => 100,
		);
		$response     = wp_safe_remote_post( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,

				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		if ( 200 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			if ( $response_data ) {
				update_option( 'zipwp_selection_templates', $response_data );
				wp_send_json_success(
					array(
						'data'   => $response_data,
						'status' => true,
					)
				);
			} else {
				wp_send_json_error(
					array(
						'data'   => $response_data,
						'status' => false,

					)
				);
			}
		} else {
			wp_send_json_error(
				array(
					'data'   => 'Failed',
					'status' => false,

				)
			);
		}
	}

	/**
	 * Get templates by page.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function get_all_templates( $request ) {

		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$per_page = isset( $request['per_page'] ) ? intval( $request['per_page'] ) : 9;
		$page     = isset( $request['page'] ) ? intval( $request['page'] ) : 1;
		$keyword  = isset( $request['keyword'] ) ? sanitize_text_field( $request['keyword'] ) : '';
		$sort     = isset( $request['sort'] ) ? $request['sort'] : null;

		$api_endpoint = $this->get_api_domain() . '/sites/templates/all';

		if ( ! empty( $keyword ) ) {
			$api_endpoint .= '?query=' . rawurlencode( $keyword );
		}

		$post_data = array(
			'business_name' => isset( $request['business_name'] ) ? sanitize_text_field( $request['business_name'] ) : '',
			'page_builder'  => isset( $request['page_builder'] ) ? sanitize_text_field( $request['page_builder'] ) : 'spectra',
			'email'         => $this->get_zip_user_email(),
			'per_page'      => $per_page,
			'page'          => $page,
		);

		if ( ! empty( $sort ) && ! empty( $sort['by'] ) ) {
			$post_data['sort'] = array(
				'by'    => sanitize_text_field( $sort['by'] ),
				'order' => sanitize_text_field( $sort['order'] ?? 'desc' ),
			);
		}

		$body = wp_json_encode( $post_data );

		$request_args = array(
			'body'    => is_string( $body ) ? $body : '',
			'headers' => $this->get_api_headers(),
			'timeout' => 100,
		);
		$response     = wp_safe_remote_post( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,

				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		if ( 200 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			if ( $response_data ) {
				update_option( 'zipwp_selection_templates', $response_data );
				wp_send_json_success(
					array(
						'data'   => $response_data,
						'status' => true,
					)
				);
			} else {
				wp_send_json_error(
					array(
						'data'   => $response_data,
						'status' => false,

					)
				);
			}
		} else {
			wp_send_json_error(
				array(
					'data'   => 'Failed',
					'status' => false,

				)
			);
		}
	}

	/**
	 * Get Categories.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function get_categories( $request ) {
		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$api_endpoint = $this->get_api_domain() . '/all-parent-categories/';
		$request_args = array(
			'headers' => $this->get_api_headers(),
			'timeout' => 100,
		);
		$response     = wp_safe_remote_get( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,

				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		if ( 200 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			if ( is_array( $response_data ) ) {
				wp_send_json_success(
					array(
						'data'   => $response_data['categories'],
						'status' => true,
					)
				);
			} else {
				wp_send_json_error(
					array(
						'data'   => 'Failed ' . $response_data,
						'status' => false,

					)
				);
			}
		} elseif ( 401 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			wp_send_json_error(
				array(
					'data'   => is_array( $response_data ) ? $response_data['message'] : '',
					'status' => false,

				)
			);
		} else {
			wp_send_json_error(
				array(
					'data'   => 'Failed',
					'status' => false,

				)
			);
		}
	}

	/**
	 * Get ZipWP Features list.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function get_site_features( $request ) {
		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$api_endpoint = $this->get_api_domain() . '/sites/features/';
		$request_args = array(
			'headers' => $this->get_api_headers( true ),
			'timeout' => 100,
		);
		$response     = wp_safe_remote_get( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,

				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		if ( 200 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			if ( is_array( $response_data ) ) {
				wp_send_json_success(
					array(
						'data'   => $response_data['data'],
						'status' => true,
					)
				);
			}
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response_data,
					'status' => false,

				)
			);
		}
		wp_send_json_error(
			array(
				'data'   => 'Failed ' . $response_body,
				'status' => false,

			)
		);
	}

	/**
	 * Get ZipWP Languages list.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function get_site_languages( $request ) {
		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$api_endpoint = $this->get_api_domain() . '/sites/languages/';
		$request_args = array(
			'headers' => $this->get_api_headers(),
			'timeout' => 100,
		);
		$response     = wp_safe_remote_get( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,

				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		if ( 200 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			if ( is_array( $response_data ) ) {
				wp_send_json_success(
					array(
						'data'   => $response_data['data'],
						'status' => true,
					)
				);
			}
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response_data,
					'status' => false,

				)
			);
		}
		wp_send_json_error(
			array(
				'data'   => 'Failed ' . $response_body,
				'status' => false,

			)
		);
	}

	/**
	 * Get User Credits.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function get_user_credits( $request ) {
		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$api_endpoint = $this->get_api_domain() . '/scs-usage/';
		$request_args = array(
			'headers' => $this->get_api_headers(),
			'timeout' => 100,
		);
		$response     = wp_safe_remote_post( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,

				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );

		if ( 200 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			if ( is_array( $response_data ) ) {
				$credit_details               = array();
				$credit_details['used']       = ! empty( $response_data['total_used_credits'] ) ? $response_data['total_used_credits'] : 0;
				$credit_details['total']      = $response_data['total_credits'];
				$credit_details['percentage'] = intval( $credit_details['used'] / $credit_details['total'] * 100 );
				$credit_details['free_user']  = $response_data['free_user'];
				wp_send_json_success(
					array(
						'data'   => $credit_details,
						'status' => true,
					)
				);
			}
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response_data,
					'status' => false,

				)
			);
		}
		wp_send_json_error(
			array(
				'data'   => 'Failed ' . $response_body,
				'status' => false,

			)
		);
	}

	/**
	 * Get Import Status.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function get_import_status( $request ) {
		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$site = get_option( 'zipwp_import_site_details', array() );
		$uuid = is_array( $site ) && ! empty( $site['uuid'] ) ? $site['uuid'] : '';

		if ( empty( $uuid ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Site not found.', 'astra-sites' ),
					'status' => false,
				)
			);
		}

		$api_endpoint = $this->get_api_domain( false ) . '/sites/import-status/' . $uuid . '/';
		$request_args = array(
			'headers' => $this->get_api_headers(),
			'timeout' => 100,
		);
		$response     = wp_safe_remote_get( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,
				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		if ( 200 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			if ( $response_data ) {
				wp_send_json_success(
					array(
						'data'   => $response_data,
						'status' => true,
					)
				);
			} else {
				wp_send_json_error(
					array(
						'data'   => $response_data,
						'status' => false,
					)
				);
			}
		} else {
			wp_send_json_error(
				array(
					'data'   => $response_code,
					'status' => false,
				)
			);
		}
	}

	/**
	 * Restore the AI credit consumed by a failed site generation.
	 *
	 * Proxies to the ZipWP manual restore endpoint. The response mirrors the
	 * backend contract: a `status` of `not_eligible`, `already_restored` or
	 * `restored_now` plus a user-facing `message`. Idempotent on the backend.
	 *
	 * @since 1.2.83
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function restore_credit( $request ) {
		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,
				)
			);
		}

		$site = get_option( 'zipwp_import_site_details', array() );
		$uuid = is_array( $site ) && ! empty( $site['uuid'] ) ? $site['uuid'] : '';

		if ( empty( $uuid ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Site not found.', 'astra-sites' ),
					'status' => false,
				)
			);
		}

		$api_endpoint = $this->get_api_domain( false ) . '/sites/' . $uuid . '/restore-credit/';
		$request_args = array(
			'headers' => $this->get_api_headers(),
			'timeout' => 100,
		);
		$response     = wp_safe_remote_post( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,
				)
			);
		}

		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		$response_data = json_decode( $response_body, true );

		if ( 200 === $response_code && $response_data ) {
			wp_send_json_success(
				array(
					'data'   => $response_data,
					'status' => true,
				)
			);
		} else {
			wp_send_json_error(
				array(
					'data'   => $response_data,
					'status' => false,
				)
			);
		}
	}

	/**
	 * Get Migration Status.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function get_migration_status( $request ) {
		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}
		wp_send_json_success(
			array(
				'data'   => get_option( 'astra_sites_batch_process_complete', 'no' ),
				'status' => true,
			)
		);
	}

	/**
	 * Search business category.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function search_business_category( $request ) {

		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				array(
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,

				)
			);
		}

		$keyword      = $request['keyword'];
		$api_endpoint = $this->get_api_domain() . '/sites/business/search?q=' . $keyword;
		$request_args = array(
			'headers' => $this->get_api_headers( true ),
			'timeout' => 100,
		);
		$response     = wp_safe_remote_get( $api_endpoint, $request_args );
		if ( is_wp_error( $response ) ) {
			// There was an error in the request.
			wp_send_json_error(
				array(
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,

				)
			);
		}
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );
		if ( 200 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			wp_send_json_success(
				array(
					'data'   => is_array( $response_data ) ? $response_data['results'] : '',
					'status' => true,
				)
			);

		} else {
			wp_send_json_error(
				array(
					'data'   => 'Failed - ' . $response_body,
					'status' => false,

				)
			);
		}
	}

	/**
	 * Get Saved ZipWP user email.
	 *
	 * @since 4.0.0
	 * @return string
	 */
	public static function get_zip_user_email() {
		$token_details = get_option(
			'zip_ai_settings',
			array(
				'auth_token' => '',
				'zip_token'  => '',
				'email'      => '',
			)
		);
		return is_array( $token_details ) && isset( $token_details['email'] ) ? $token_details['email'] : '';
	}

	/**
	 * Get the site source sent with ZipWP requests.
	 *
	 * @since 1.2.85
	 * @return string
	 */
	public static function get_site_source() {
		/**
		 * Filter the site source sent with ZipWP requests.
		 *
		 * @param string $source The site source. Default 'starter-templates'.
		 * @since 1.2.85
		 */
		return apply_filters( 'ai_builder_site_source', 'starter-templates' );
	}

	/**
	 * Store the partner affiliate IDs returned by the ZipWP site creation response.
	 *
	 * An option that already holds a value is never overwritten, so IDs set by the
	 * white-label onboarding plugin or manually by the partner always win.
	 *
	 * @param mixed $affiliate_ids Affiliate IDs keyed by programme.
	 * @since 1.2.93
	 * @return void
	 */
	public static function set_partner_affiliate_ids( $affiliate_ids ) {
		if ( ! is_array( $affiliate_ids ) ) {
			return;
		}

		$option_map = array(
			'astra_affiliate_id'    => 'astra_partner_url_param',
			'spectra_affiliate_id'  => 'spectra_partner_url_param',
			'zipwp_ai_affiliate_id' => 'zipwp_partner_url_param',
		);

		foreach ( $option_map as $response_key => $option_name ) {
			if ( empty( $affiliate_ids[ $response_key ] ) || ! is_scalar( $affiliate_ids[ $response_key ] ) ) {
				continue;
			}

			$value = sanitize_text_field( (string) $affiliate_ids[ $response_key ] );

			if ( '' !== $value && ! get_option( $option_name ) ) {
				update_option( $option_name, $value );
			}
		}
	}

	/**
	 * Record step.
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return mixed
	 */
	public function record_step( $request ) {
		$nonce = (string) $request->get_header( 'X-WP-Nonce' );
		// Verify the nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( $nonce ), 'wp_rest' ) ) {
			wp_send_json_error(
				[
					'data'   => __( 'Nonce verification failed.', 'astra-sites' ),
					'status' => false,
				]
			);
		}

		$api_endpoint = $this->get_api_domain() . '/sites/ai/step';

		$post_data = [
			'action'            => isset( $request['action'] ) ? sanitize_text_field( $request['action'] ) : '',
			'current_step'      => isset( $request['current_step'] ) ? absint( $request['current_step'] ) : 0,
			'current_step_name' => isset( $request['current_step_name'] ) ? sanitize_text_field( $request['current_step_name'] ) : '',
			'email'             => $this->get_zip_user_email(),
			'source'            => self::get_site_source(),
		];

		// UUID generated once per wizard session so ZipWP can count each build as its own attempt.
		// The ZipWP endpoint validates it as nullable|uuid, so only forward a well-formed UUID.
		$funnel_session_id = isset( $request['funnel_session_id'] ) ? strtolower( sanitize_text_field( $request['funnel_session_id'] ) ) : '';
		if ( wp_is_uuid( $funnel_session_id ) ) {
			$post_data['funnel_session_id'] = $funnel_session_id;
		}

		$body = wp_json_encode( $post_data );

		$request_args = [
			'body'    => is_string( $body ) ? $body : '',
			'headers' => $this->get_api_headers(),
			'timeout' => 100,
		];
		$response     = wp_safe_remote_post( $api_endpoint, $request_args );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error(
				[
					'data'   => 'Failed ' . $response->get_error_message(),
					'status' => false,
				]
			);
		}

		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );

		if ( 200 === $response_code || 201 === $response_code ) {
			$response_data = json_decode( $response_body, true );
			wp_send_json_success(
				[
					'data'   => $response_data,
					'status' => true,
				]
			);
		} else {
			wp_send_json_error(
				[
					'data'   => 'Failed - ' . $response_body,
					'status' => false,
				]
			);
		}
	}
}

Ai_Builder_ZipWP_Api::Instance();
