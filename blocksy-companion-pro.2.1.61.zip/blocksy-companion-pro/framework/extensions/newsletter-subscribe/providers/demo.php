<?php

namespace Blocksy\Extensions\NewsletterSubscribe;

class DemoProvider extends Provider {
	public function __construct() {
	}

	public function fetch_lists($api_key, $api_url = '') {
		if (! $api_key) {
			return 'api_key_invalid';
		}

		return [
			[
				'name' => __('Demo List', 'blocksy-companion'),
				'id' => 'demolist'
			]
		];
	}

	public function subscribe_form($args = []) {
		$args = wp_parse_args($args, [
			'email' => '',
			'name' => '',
			'group' => ''
		]);

		return [
			// 'response' => $response,
			'result' => 'yes',
			'message' => NewsletterMessages::subscribed_successfully()
		];
	}
}
