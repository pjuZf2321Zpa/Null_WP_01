<?php
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound, VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable -- view scope, variables come from blocksy_companion_render_view()

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * About me widget
 *
 * @copyright 2019-present Creative Themes
 * @license   http://www.gnu.org/copyleft/gpl.html GNU General Public License
 * @package Blocksy
 */

$about_source = blocksy_companion_akg( 'about_source', $atts, 'from_wp' );
$alignment    = blocksy_companion_akg( 'about_alignment', $atts, 'center' );
$avatar_size  = blocksy_companion_akg( 'about_avatar_size', $atts, 'small' );
$avatar_shape = blocksy_companion_akg( 'avatar_shape', $atts, 'rounded' );
$class_name   = blocksy_companion_akg( 'className', $atts, '' );

$sizes = array(
	'small'  => 90,
	'medium' => 140,
	'large'  => 200,
);

$user_id = blocksy_companion_akg( 'wp_user', $atts, null );

$image_output = blocksy_media(
	array(
		'attachment_id' => blocksy_companion_akg(
			'about_avatar/attachment_id',
			$atts,
			null
		),
		'ratio'         => '1/1',
		'tag_name'      => 'figure',
		'size'          => 'small' === $avatar_size ? 'thumb' : 'medium',
		'html_atts'     => array(
			'data-size'  => $avatar_size,
			'data-shape' => $avatar_shape,
		),
	)
);

$about_name = blocksy_companion_akg( 'about_name', $atts, 'John Doe' );
$about_text = do_shortcode(
	blocksy_companion_sanitize_html_for_display(
		blocksy_companion_akg(
			'about_text',
			$atts,
			'Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua tincidunt tortor aliquam.'
		)
	)
);

if ( 'from_wp' === $about_source ) {
	$public_authors = get_users(
		array(
			'include'             => array( absint( $user_id ) ),
			'has_published_posts' => true,
			'fields'              => 'ID',
		)
	);

	if ( empty( $public_authors ) && blocksy_companion_theme_functions()->blocksy_manager() !== \Blocksy\ThemeFunctions::NON_EXISTING_FUNCTION ) {
		$default_user_id = blocksy_companion_theme_functions()->blocksy_manager()
			->entity_id_picker
			->get_default_value(
				array(
					'entity' => 'users',
				)
			);

		$public_authors = get_users(
			array(
				'include'             => array( absint( $default_user_id ) ),
				'has_published_posts' => true,
				'fields'              => 'ID',
			)
		);
	}

	if ( empty( $public_authors ) ) {
		return;
	}

	$user_id = (int) $public_authors[0];

	$image_output = blocksy_simple_image(
		blocksy_get_avatar_url(
			array(
				'size'          => $sizes[ $avatar_size ] * 2,
				'avatar_entity' => $user_id,
			)
		),
		array(
			'tag_name'  => 'figure',
			'ratio'     => '1/1',
			'html_atts' => array(
				'data-size'  => $avatar_size,
				'data-shape' => $avatar_shape,
			),
		)
	);

	$about_name = blocksy_get_the_author_meta( 'display_name', $user_id );
	$about_text = blocksy_companion_sanitize_html_for_display(
		blocksy_get_the_author_meta( 'description', $user_id )
	);
}

$link_rel = '';

$link_target = blocksy_companion_akg( 'link_target', $atts, 'no' );

if ( 'yes' === $link_target ) {
	$link_target = '_blank';
	$link_rel    = 'noopener noreferrer';
} else {
	$link_target = false;
}

$link_nofollow = blocksy_companion_akg( 'link_nofollow', $atts, 'no' );

if ( 'yes' === $link_nofollow ) {
	$link_rel .= ' nofollow';
}

$size = blocksy_companion_akg( 'about_social_icons_size', $atts, 'small' );
$type = blocksy_companion_akg( 'about_social_type', $atts, 'rounded' );
$fill = blocksy_companion_akg( 'about_social_icons_fill', $atts, 'outline' );

$colors = array(
	'--theme-block-text-color' => blocksy_companion_akg( 'customTextColor', $atts, '' ),
	'--theme-link-hover-color' => blocksy_companion_akg( 'customTextHoverColor', $atts, '' ),
	'--theme-icon-color'       => blocksy_companion_akg( 'customIconsColor', $atts, '' ),
	'--theme-icon-hover-color' => blocksy_companion_akg( 'customIconsHoverColor', $atts, '' ),
);

if ( 'simple' !== $type ) {
	$base_color  = blocksy_companion_akg( 'customBorderColor', $atts, 'rgba(218, 222, 228, 0.5)' );
	$hover_color = blocksy_companion_akg( 'customBorderHoverColor', $atts, 'rgba(218, 222, 228, 0.7)' );

	if ( isset( $atts['borderColor'] ) ) {
		$var        = $atts['borderColor'];
		$base_color = "var(--wp--preset--color--$var)";
	}

	if ( isset( $atts['borderHoverColor'] ) ) {
		$var         = $atts['borderHoverColor'];
		$hover_color = "var(--wp--preset--color--$var)";
	}

	if ( 'solid' === $fill ) {
		$base_color  = blocksy_companion_akg( 'customBackgroundColor', $atts, 'rgba(218, 222, 228, 0.5)' );
		$hover_color = blocksy_companion_akg( 'customBackgroundHoverColor', $atts, 'rgba(218, 222, 228, 0.7)' );

		if ( isset( $atts['backgroundColor'] ) ) {
			$var        = $atts['backgroundColor'];
			$base_color = "var(--wp--preset--color--$var)";
		}

		if ( isset( $atts['backgroundHoverColor'] ) ) {
			$var         = $atts['backgroundHoverColor'];
			$hover_color = "var(--wp--preset--color--$var)";
		}
	}

	$colors = array_merge(
		$colors,
		array(
			'--background-color'       => $base_color,
			'--background-hover-color' => $hover_color,
		)
	);
}

if ( isset( $atts['textColor'] ) ) {
	$var                                = $atts['textColor'];
	$colors['--theme-block-text-color'] = "var(--wp--preset--color--$var)";
}

if ( isset( $atts['textHoverColor'] ) ) {
	$var                                = $atts['textHoverColor'];
	$colors['--theme-link-hover-color'] = "var(--wp--preset--color--$var)";
}

if ( isset( $atts['iconsColor'] ) ) {
	$var                          = $atts['iconsColor'];
	$colors['--theme-icon-color'] = "var(--wp--preset--color--$var)";
}

if ( isset( $atts['iconsHoverColor'] ) ) {
	$var                                = $atts['iconsHoverColor'];
	$colors['--theme-icon-hover-color'] = "var(--wp--preset--color--$var)";
}

$attr = array(
	'class'          => 'ct-about-me-block ' . $class_name,
	'data-alignment' => $alignment,
	'style'          => '',
);

$attr['style'] .= blocksy_companion_colors_to_css( $colors );

$icons_size = (float) blocksy_companion_akg( 'about_social_icons_size', $atts, '' );

if ( ! empty( $icons_size ) ) {
	$attr['style'] .= '--theme-icon-size:' . $icons_size . 'px;';
}

$items_spacing = (float) blocksy_companion_akg( 'about_items_spacing', $atts, '' );

if ( ! empty( $items_spacing ) ) {
	$attr['style'] .= '--items-spacing:' . $items_spacing . 'px;';
}

?>

<div <?php blocksy_companion_attr_to_html_e( $attr ); ?>>
	<?php
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $image_output;
	?>

	<div class="ct-about-me-name">
		<span><?php echo blocksy_companion_sanitize_html_for_display( $about_name ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>

		<?php if ( 'from_wp' === $about_source ) { ?>
			<a href="<?php echo esc_url( get_author_posts_url( $user_id ) ); ?>">
				<?php echo esc_html__( 'View Profile', 'blocksy-companion' ); ?>
			</a>
		<?php } ?>
	</div>

	<div class="ct-about-me-text"><?php echo $about_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>

	<?php
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo blocksy_social_icons(
			blocksy_companion_akg(
				'about_socials',
				$atts,
				array(
					array(
						'id'      => 'facebook',
						'enabled' => true,
					),

					array(
						'id'      => 'twitter',
						'enabled' => true,
					),

					array(
						'id'      => 'instagram',
						'enabled' => true,
					),
				)
			),
			array(
				'size'         => $size,
				'type'         => $type,
				'fill'         => $fill,
				'icons-color'  => blocksy_companion_akg( 'about_social_icons_color', $atts, 'default' ),
				'links_target' => $link_target,
				'links_rel'    => $link_rel,
			)
		);
		?>
</div>
