<?php

namespace Blocksy\Extensions\WoocommerceExtra;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ShippingProgress {
	public function get_dynamic_styles_data( $args ) { // phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable -- filter callback signature
		return array(
			'path' => __DIR__ . '/dynamic-styles.php',
		);
	}

	public function __construct() {
		add_action(
			'wp_enqueue_scripts',
			function () {
				if (
					is_admin()
					||
					(
						is_cart()
						&&
						blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_shipping_progress_in_cart', 'no' ) === 'no'
					)
					||
					(
						is_checkout()
						&&
						blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_shipping_progress_in_checkout', 'no' ) === 'no'
					)
					||
					(
						is_singular( 'product' )
						&&
						! blocksy_companion_theme_functions()->blocksy_has_product_specific_layer( 'free_shipping' )
					)
					||
					(
						! is_cart()
						&&
						! is_checkout()
						&&
						! is_singular( 'product' )
					)
				) {
					return;
				}

				wp_enqueue_style(
					'blocksy-ext-woocommerce-extra-shipping-progress-styles',
					BLOCKSY_URL .
						'framework/premium/extensions/woocommerce-extra/static/bundle/shipping-progress.min.css',
					array( 'blocksy-ext-woocommerce-extra-styles' ),
					blocksy_companion_get_version()
				);
			},
			50
		);

		add_filter(
			'blocksy:general:ct-scripts-localizations',
			function ( $data ) {
				if ( ! class_exists( 'Blocksy_Header_Builder_Render' ) ) {
					return $data;
				}

				$render = new \Blocksy_Header_Builder_Render();

				if (
				$render->contains_item( 'cart' )
				&&
				blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_shipping_progress_in_mini_cart', 'no' ) !== 'no'
				) {
					$data['dynamic_styles_selectors'][] = array(
						'selector' => '.ct-header-cart .ct-shipping-progress-mini-cart, #woo-cart-panel .ct-shipping-progress-mini-cart',
						'url'      => add_query_arg(
							'ver',
							blocksy_companion_get_version(),
							blocksy_companion_theme_functions()->blocksy_cdn_url(
								BLOCKSY_URL .
								'framework/premium/extensions/woocommerce-extra/static/bundle/shipping-progress.min.css'
							)
						),
					);
				}

				return $data;
			}
		);

		add_action(
			'wp',
			function () {
				if ( blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_shipping_progress_in_cart', 'no' ) === 'yes' ) {
					add_action(
						'blocksy:woo:cart:cart-totals',
						array(
							$this,
							'cart_page_render',
						)
					);
				}

				if ( blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_shipping_progress_in_checkout', 'no' ) === 'yes' ) {
					add_action(
						'blocksy:woo:checkout:order-review',
						array(
							$this,
							'checkout_page_render',
						),
						25
					);
				}

				if ( blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_shipping_progress_in_mini_cart', 'no' ) === 'yes' ) {
					add_action(
						'woocommerce_widget_shopping_cart_before_buttons',
						array(
							$this,
							'minicart_render',
						)
					);
				}
			}
		);

		add_filter(
			'blocksy:woocommerce:cart-fragments',
			array(
				$this,
				'blocksy_header_cart_item_fragment',
			)
		);

		add_filter(
			'blocksy_customizer_options:woocommerce:general:end',
			function ( $opts ) {
				$opts['has_free_shipping_panel'] = blocksy_companion_get_options(
					__DIR__ . '/options.php',
					array(),
					false
				);

				return $opts;
			},
			55
		);

		add_filter(
			'blocksy_woo_single_options_layers:defaults',
			array(
				$this,
				'add_layer_to_default_layout',
			)
		);

		add_filter(
			'blocksy_woo_single_options_layers:extra',
			array(
				$this,
				'add_layer_options',
			)
		);

		add_action(
			'blocksy:woocommerce:product:custom:layer',
			array(
				$this,
				'render_shipping_layer',
			)
		);

		add_shortcode(
			'blocksy_shipping_progress',
			array(
				$this,
				'shortcode_render',
			)
		);
	}

	public function render_wrapper( $additional_classes = '', $content = '' ) {
		return blocksy_companion_html_tag(
			'div',
			array(
				'class' => 'ct-shipping-progress' . $additional_classes,
			),
			$content
		);
	}

	public function shortcode_render() {
		return $this->render_wrapper(
			'-shortcode',
			$this->render_shipping_progress_bar()
		);
	}

	public function cart_page_render() {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $this->render_wrapper(
			'-cart-page',
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$this->render_shipping_progress_bar()
		);
	}

	public function checkout_page_render() {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $this->render_wrapper(
			'-checkout-page',
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$this->render_shipping_progress_bar()
		);
	}

	public function minicart_render() {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $this->render_wrapper(
			'-mini-cart',
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			$this->render_shipping_progress_bar()
		);
	}

	public function add_layer_options( $opt ) {
		$opt = array_merge(
			$opt,
			array(
				'free_shipping' => array(
					'label'   => __( 'Free Shipping Bar', 'blocksy-companion' ),
					'options' => array(
						'show_if_cart_is_empty' => array(
							'label'   => __( 'Show if cart is empty', 'blocksy-companion' ),
							'type'    => 'ct-switch',
							'value'   => 'yes',
							'divider' => 'top',
						),

						'spacing'               => array(
							'label'      => __( 'Bottom Spacing', 'blocksy-companion' ),
							'type'       => 'ct-slider',
							'min'        => 0,
							'max'        => 100,
							'value'      => 10,
							'responsive' => true,
							'sync'       => array(
								'id' => 'woo_card_layout_skip',
							),
						),
					),
				),
			)
		);

		return $opt;
	}

	public function add_layer_to_default_layout( $opt ) {
		$opt = array_merge(
			$opt,
			array(
				array(
					'id'      => 'free_shipping',
					'enabled' => false,
				),
			)
		);

		return $opt;
	}

	private function get_cart() {
		if (
			! function_exists( 'WC' )
			||
			! is_object( WC() )
			||
			! property_exists( WC(), 'cart' )
			||
			! is_object( WC()->cart )
		) {
			return null;
		}

		return WC()->cart;
	}

	public function render_shipping_layer( $layer ) {
		if ( 'free_shipping' !== $layer['id'] ) {
			return;
		}

		$cart          = $this->get_cart();
		$cart_is_empty = (
			! $cart
			||
			! method_exists( $cart, 'is_empty' )
			||
			$cart->is_empty()
		);

		$show_if_cart_is_empty = blocksy_companion_akg(
			'show_if_cart_is_empty',
			$layer,
			'yes'
		) !== 'no';

		if (
			! $show_if_cart_is_empty
			&&
			$cart_is_empty
		) {
			return;
		}

		$shipping_progress_content = $this->render_shipping_progress_bar(
			'',
			array(
				'force_output' => $show_if_cart_is_empty && $cart_is_empty,
			)
		);

		$shipping_progress_wrapper = $this->render_wrapper(
			'-single' . ( $show_if_cart_is_empty ? ' ct-show-if-cart-empty' : '' ),
			$shipping_progress_content
		);

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $shipping_progress_wrapper;
	}

	private function has_paid_shipping_item() {
		/**
		 * Filters the product categories that hide the free shipping progress bar.
		 *
		 * @since 2.0.1
		 *
		 * @param array $exclude_categories Product categories that hide the progress bar. Default empty array.
		 */
		$exclude_categories = apply_filters(
			'blocksy:pro:woocommerce-extra:shipping-progress:exclude-categories',
			array()
		);

		$hide_shipping_bar = false;

		if ( empty( $exclude_categories ) ) {
			return $hide_shipping_bar;
		}

		$cart = $this->get_cart();

		if (
			! $cart
			||
			! method_exists( $cart, 'get_cart' )
		) {
			return $hide_shipping_bar;
		}

		foreach ( $cart->get_cart() as $cart_item ) {
			if (
				has_term( $exclude_categories, 'product_cat', $cart_item['product_id'] )
			) {
				$hide_shipping_bar = true;
				break;
			}
		}

		return $hide_shipping_bar;
	}

	private function has_items_requiring_shipping( $all_cart_items ) {
		foreach ( $all_cart_items as $cart_item ) {
			if (
				isset( $cart_item['data'] )
				&&
				is_object( $cart_item['data'] )
				&&
				method_exists( $cart_item['data'], 'needs_shipping' )
				&&
				$cart_item['data']->needs_shipping()
			) {
				return true;
			}
		}

		return false;
	}

	public function render_shipping_progress_bar( $return_html = '', $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'force_output' => false,
			)
		);

		$calculation   = blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_count_method', 'custom' );
		$percent       = 100;
		$limit         = 0;
		$free_shipping = false;

		$cart = $this->get_cart();

		if (
			! $cart
			||
			! method_exists( $cart, 'get_cart' )
		) {
			return;
		}

		$all_cart_items               = $cart->get_cart();
		$has_items_requiring_shipping = $this->has_items_requiring_shipping( $all_cart_items );
		$force_empty_cart_output      = $args['force_output'] && empty( $all_cart_items );

		if ( ! $has_items_requiring_shipping && ! $force_empty_cart_output ) {
			return;
		}

		if ( ! method_exists( $cart, 'get_displayed_subtotal' ) ) {
			$total       = 0;
			$calculation = 'custom';
		} else {
			$total = $cart->get_displayed_subtotal();

			if ( method_exists( $cart, 'get_fee_total' ) ) {
				$total += $cart->get_fee_total();
			}
		}

		$is_custom_by_items = 'custom' === $calculation && blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_custom_count_criteria', 'price' ) === 'items';

		if ( 'woo' === $calculation ) {
			$packages = $cart->get_shipping_packages();
			$package  = reset( $packages );
			$zone     = wc_get_shipping_zone( $package );

			foreach ( $zone->get_shipping_methods( true ) as $method ) {
				if (
					'free_shipping' === $method->id
					&&
					$method->get_option( 'min_amount' )
				) {
					$limit = (float) $method->get_option( 'min_amount' );
				}
			}
		} elseif ( 'custom' === $calculation ) {
			$limit = (float) blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_count_progress_amount', 100 );
		}

		if ( class_exists( 'woocommerce_wpml' ) ) {
			global $woocommerce_wpml;

			$multi_currency = $woocommerce_wpml->get_multi_currency();

			if (
				! empty( $multi_currency->prices )
				&&
				method_exists( $multi_currency->prices, 'convert_price_amount' )
			) {
				if ( wcml_get_woocommerce_currency_option() === $multi_currency->get_client_currency() ) {
					$limit = (float) $multi_currency->prices->convert_price_amount( $limit );
				}
			}
		}

		if ( $is_custom_by_items ) {
			$total = $cart->get_cart_contents_count();
			$limit = (float) blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_count_progress_items', 2 );
		}

		$woo_shipping_count_non_physical = blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_shipping_count_non_physical', 'yes' );

		if (
			$total
			&&
			'no' === $woo_shipping_count_non_physical
		) {
			$all_cart_items               = $cart->get_cart();
			$has_items_requiring_shipping = $this->has_items_requiring_shipping( $all_cart_items );

			if ( ! $has_items_requiring_shipping ) {
				foreach ( $all_cart_items as $cart_item ) {
					if (
						$cart_item['data']->is_virtual()
						||
						$cart_item['data']->is_downloadable()
					) {
						if ( ! $is_custom_by_items ) {
							$total -= $cart_item['line_total'];

							if (
								isset( $cart_item['line_tax'] )
								&&
								$cart_item['line_tax']
							) {
								$total -= $cart_item['line_tax'];
							}
						} else {
							$total -= $cart_item['quantity'];
						}
					}
				}
			}
		}

		if (
			$total
			&&
			$cart->get_coupons()
			&&
			blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woo_count_with_discount', 'yes' ) === 'yes'
		) {
			foreach ( $cart->get_coupons() as $coupon ) {
				$total -= $cart->get_coupon_discount_amount(
					$coupon->get_code(),
					$cart->display_cart_ex_tax
				);

				if ( $coupon->get_free_shipping() ) {
					$free_shipping = true;
					break;
				}
			}
		}

		if (
			$total < $limit
			&&
			! $free_shipping
		) {
			$percent = floor( ( $total / $limit ) * 100 );
			$message = str_replace(
				'{price}',
				wc_price( $limit - $total ),
				blocksy_companion_sanitize_html_for_display(
					blocksy_companion_theme_functions()->blocksy_get_theme_mod(
						'free_not_enought_message',
						__(
							'Add {price} more to get free shipping!',
							'blocksy-companion'
						)
					)
				)
			);

			if ( $is_custom_by_items ) {
				$message = str_replace(
					'{items}',
					$limit - $total,
					blocksy_companion_sanitize_html_for_display(
						blocksy_companion_theme_functions()->blocksy_get_theme_mod(
							'free_not_enought_items_message',
							__(
								'Add {items} more items to get free shipping!',
								'blocksy-companion'
							)
						)
					)
				);
			}
		} else {
			$message = blocksy_companion_sanitize_html_for_display(
				blocksy_companion_theme_functions()->blocksy_get_theme_mod(
					'free_enought_message',
					__(
						'Congratulations! You got free shipping 🎉',
						'blocksy-companion'
					)
				)
			);
		}

		if ( ! $limit ) {
			return;
		}

		if ( $this->has_paid_shipping_item() ) {
			return;
		}

		$message_html = blocksy_companion_html_tag(
			'div',
			array(
				'class' => 'ct-message',
			),
			$message
		);

		$bar_html = blocksy_companion_html_tag(
			'div',
			array(
				'class' => 'ct-progress-bar',
			),
			blocksy_companion_html_tag(
				'span',
				array(
					'style' => 'width: ' . $percent . '%',
				),
				''
			)
		);

		if ( 'message' === $return_html ) {
			return $message_html;
		}

		if ( 'bar' === $return_html ) {
			return $bar_html;
		}

		return implode( '', array( $message_html, $bar_html ) );
	}

	public function blocksy_header_cart_item_fragment( $fragments ) {
		$fragments['[class*="ct-shipping-progress"]:not(.ct-show-if-cart-empty) .ct-message']      = $this->render_shipping_progress_bar(
			'message'
		);
		$fragments['[class*="ct-shipping-progress"]:not(.ct-show-if-cart-empty) .ct-progress-bar'] = $this->render_shipping_progress_bar(
			'bar'
		);
		$fragments['.ct-shipping-progress-single.ct-show-if-cart-empty']                           = $this->render_wrapper(
			'-single ct-show-if-cart-empty',
			$this->render_shipping_progress_bar(
				'',
				array(
					'force_output' => true,
				)
			)
		);

		return $fragments;
	}
}
