<?php
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound, VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable -- view scope, variables come from blocksy_companion_render_view()

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$compare_list = blocksy_companion_get_ext( 'woocommerce-extra' )
	->get_compare()
	->get_current_compare_list();

$content = '';

$visiblity_class = blocksy_visibility_classes(
	blocksy_companion_theme_functions()->blocksy_get_theme_mod(
		'product_compare_bar_visibility',
		array(
			'desktop' => true,
			'tablet'  => true,
			'mobile'  => true,
		)
	)
);

if ( count( $compare_list ) > 0 ) {
	$products = array();

	$class = 'ct-button';

	if ( ! function_exists( 'wc_get_endpoint_url' ) ) {
		return;
	}

	$icon = blocksy_companion_get_icon(
		array(
			'icon_descriptor' => blocksy_companion_theme_functions()->blocksy_get_theme_mod(
				'product_compare_bar_button_icon',
				array(
					'icon' => 'blc blc-compare',
				)
			),
			'icon_container'  => false,
		)
	);

	$url = '#ct-compare-modal';

	$maybe_page_id = blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'woocommerce_compare_page' );

	if ( ! empty( $maybe_page_id ) ) {
		$maybe_permalink = get_permalink( $maybe_page_id );

		if ( $maybe_permalink ) {
			$url = $maybe_permalink;
		}
	}

	$compare_label = blocksy_companion_sanitize_html_for_display(
		blocksy_companion_theme_functions()->blocksy_get_theme_mod(
			'product_compare_bar_button_label',
			__( 'Compare', 'blocksy-companion' )
		)
	);

	$button = '';

	if ( function_exists( 'blocksy_action_button' ) ) {
		$button = blocksy_action_button(
			array(
				'button_html_attributes' => array(
					'href'           => $url,
					'class'          => $class,
					'aria-label'     => $compare_label,
					'data-behaviour' => blocksy_companion_theme_functions()->blocksy_get_theme_mod( 'compare_table_placement', 'modal' ),
				),
				'icon'                   => $icon,
				'content'                => blocksy_companion_html_tag(
					'span',
					array(
						'class' => 'ct-hidden-md ct-hidden-sm',
					),
					$compare_label
				),
			)
		);
	}

	foreach ( $compare_list as $single_product ) {
		$product = wc_get_product( $single_product['id'] );

		if ( ! $product ) {
			continue;
		}

		$thumbnail = $product->get_image();
		if ( get_post_thumbnail_id( $product->get_id() ) ) {
			$maybe_thumbnail = blocksy_media(
				array(
					'attachment_id' => get_post_thumbnail_id( $product->get_id() ),
					'post_id'       => $product->get_id(),
					'ratio'         => '1',
					'size'          => 'thumbnail',
					'tag_name'      => 'figure',
				)
			);

			if ( $maybe_thumbnail ) {
				$thumbnail = $maybe_thumbnail;
			}
		}

		$remove = blocksy_companion_html_tag(
			'a',
			array(
				'href'            => '#',
				'class'           => 'ct-compare-remove',
				'data-product_id' => $product->get_id(),
				'title'           => __( 'Remove Product', 'blocksy-companion' ),
			),
			'<svg width="10" height="10" viewBox="0 0 15 15" fill="currentColor"><path d="M8.5,7.5l4.5,4.5l-1,1L7.5,8.5L3,13l-1-1l4.5-4.5L2,3l1-1l4.5,4.5L12,2l1,1L8.5,7.5z"></path></svg>'
		);

		$products[] = blocksy_companion_html_tag(
			'li',
			array(),
			blocksy_companion_html_tag(
				'span',
				array(
					'class' => 'ct-tooltip',
				),
				blocksy_companion_get_ext(
					'woocommerce-extra'
				)->utils->get_formatted_title( $product->get_id() )
			) .
			$remove .
			$thumbnail
		);
	}

	$content = blocksy_companion_html_tag(
		'div',
		array(
			'class' => 'ct-container',
		),
		blocksy_companion_html_tag(
			'ul',
			array(),
			implode( '', $products )
		) . $button
	);
}

$attr = array(
	'class' => trim( 'ct-compare-bar' . ' ' . $visiblity_class ),
);

if ( is_customize_preview() ) {
	$attr['data-shortcut']          = 'border:outside';
	$attr['data-shortcut-location'] = 'woocommerce_general:has_compare_panel';
}

blocksy_companion_html_tag_e( 'div', $attr, $content );
