<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BlocksyExtensionWhiteLabel {
	private $option_name = 'blocksy_ext_white_label_settings';

	public function __construct() {
		$settings = $this->get_settings();

		if (
			$settings
			&&
			isset( $settings['hide_billing_account'] )
			&&
			$settings['hide_billing_account']
			&&
			function_exists( 'blocksy_companion_fs' )
		) {
			remove_action(
				'admin_init',
				array( blocksy_companion_fs(), '_hook_action_links_and_register_account_hooks' )
			);
		}

		add_filter(
			'fs_plugin_title_blocksy-companion',
			function ( $title ) {
				$settings = $this->get_settings();

				if ( ! empty( $settings['plugin']['name'] ) ) {
					return $settings['plugin']['name'];
				}

				return $title;
			}
		);

		$this->sync_freemius_plugin_name();

		add_action(
			'blocksy_companion_fs_loaded',
			function () {
				$this->sync_freemius_plugin_name();
			}
		);

		add_filter(
			'blocksy:editor:options:icon',
			function ( $icon ) {
				$settings = $this->get_settings();

				if ( ! is_admin() ) {
					return $icon;
				}

				if ( ! empty( $settings['theme']['gutenberg_icon'] ) ) {
					$maybe_attachment_id = attachment_url_to_postid(
						$settings['theme']['gutenberg_icon']
					);

					if (
						$maybe_attachment_id
						&&
						get_post_mime_type( $maybe_attachment_id ) === 'image/svg+xml'
					) {
						$svg_file = \Blocksy\SvgHandling::sanitize_inline_svg(
							array(
								'file' => get_attached_file( $maybe_attachment_id ),
							)
						);

						if ( ! empty( $svg_file ) ) {
								return $svg_file;
						}
					}
				}

				return $icon;
			}
		);

		add_filter(
			// Avoid plugin-check false positive.
			implode(
				'_',
				array(
					'site',
					'transient',
					'update',
					'plugins',
				)
			),
			function ( $value ) {
				$settings = $this->get_settings();

				if ( empty( $settings['plugin']['thumbnail'] ) ) {
					return $value;
				}

				if ( ! isset( $value->response ) ) {
					return $value;
				}

				foreach ( $value->response as $plugin_key => $plugin_value ) {
					if ( strpos( $plugin_key, 'blocksy-companion' ) === false ) {
						continue;
					}

					foreach ( $plugin_value->icons as $icon_key => $icon_value ) {
						$value->response[ $plugin_key ]->icons[ $icon_key ] = $settings['plugin']['thumbnail'];
					}
				}

				return $value;
			}
		);

		add_filter(
			'blocksy:dashboard:icon-url',
			function ( $url ) {
				$settings = $this->get_settings();

				if ( ! is_admin() ) {
					return $url;
				}

				if ( ! empty( $settings['theme']['icon'] ) ) {
					return $settings['theme']['icon'];
				}

				return $url;
			}
		);

		add_filter(
			'plugins_api_result',
			function ( $result ) {
				if ( ! isset( $result->slug ) ) {
					return $result;
				}

				if ( 'blocksy-companion' !== $result->slug ) {
					return $result;
				}

				$settings = $this->get_settings();

				if ( ! empty( $settings['plugin']['name'] ) ) {
					$result->name = $settings['plugin']['name'];
				}

				if ( ! empty( $settings['plugin']['description'] ) ) {
					$result->sections['description'] = $settings['plugin']['description'];
				}

				if ( ! empty( $settings['author']['name'] ) ) {
					$result->author = $settings['author']['name'];
				}

				return $result;
			},
			10,
			1
		);

		add_action(
			'customize_register',
			function ( $wp_customize ) {
				if ( ! $wp_customize ) {
					return;
				}

				$reflection = new \ReflectionClass( $wp_customize );
				$property   = $reflection->getProperty( 'theme' );

				if ( version_compare( PHP_VERSION, '8.1.0', '<' ) ) {
					$property->setAccessible( true );
				}

				$property->setValue( $wp_customize, blocksy_companion_theme_functions()->blocksy_get_wp_theme() );
			}
		);

		add_filter(
			'blocksy_get_wp_theme',
			function ( $wp_theme ) {
				$settings = $this->get_settings();

				if ( ! is_admin() || (
				empty( $settings['theme']['name'] )
				&&
				empty( $settings['theme']['description'] )
				) ) {
					return $wp_theme;
				}

				$reflection = new \ReflectionClass( $wp_theme );
				$property   = $reflection->getProperty( 'headers' );

				if ( version_compare( PHP_VERSION, '8.1.0', '<' ) ) {
					$property->setAccessible( true );
				}

				$headers = $property->getValue( $wp_theme );

				if ( ! empty( $settings['theme']['name'] ) ) {
					$headers['Name'] = $settings['theme']['name'];
				}
				$headers['CustomDescription'] = $settings['theme']['description'];

				$property->setValue( $wp_theme, $headers );

				return $wp_theme;
			}
		);

		add_action(
			'wp_ajax_blocksy_update_white_label_settings',
			function () {
				if ( ! current_user_can( 'manage_options' ) ) {
					wp_send_json_error();
				}

				if ( ! check_ajax_referer( 'ct-dashboard', 'nonce', false ) ) {
					wp_send_json_error();
				}

				$data = blocksy_companion_get_json_request_body();

				if ( ! is_array( $data ) ) {
					wp_send_json_error();
				}

				$this->set_settings( $data );

				wp_send_json_success(
					array(
						'settings' => $this->get_settings(),
					)
				);
			}
		);

		add_filter(
			'all_plugins',
			function ( $plugins ) {
				$key = BLOCKSY_PLUGIN_BASE;

				if ( ! isset( $plugins[ $key ] ) ) {
					return $plugins;
				}

				$settings = $this->get_settings();

				if ( ! empty( $settings['plugin']['name'] ) ) {
					$plugins[ $key ]['Name'] = $settings['plugin']['name'];
				}

				if ( ! empty( $settings['plugin']['description'] ) ) {
					$plugins[ $key ]['Description'] = $settings['plugin']['description'];
				}

				if ( ! empty( $settings['author']['name'] ) ) {
					$plugins[ $key ]['Author']     = $settings['author']['name'];
					$plugins[ $key ]['AuthorName'] = $settings['author']['name'];
				}

				if ( ! empty( $settings['author']['url'] ) ) {
					$plugins[ $key ]['AuthorURI'] = $settings['author']['url'];
				}

				return $plugins;
			}
		);

		add_filter(
			'update_right_now_text',
			function ( $content ) {
				$settings = $this->get_settings();

				if (
				is_admin()
				&&
				'Blocksy' === (string) wp_get_theme()
				&&
				! empty( $settings['theme']['name'] )
				) {
					return blocksy_companion_safe_sprintf(
						$content,
						get_bloginfo( 'version', 'display' ),
						'<a href="themes.php">' . $settings['theme']['name'] . '</a>'
					);
				}

				return $content;
			}
		);

		add_filter(
			'gettext',
			function ( $text, $original ) {
				if ( is_network_admin() ) {
					return $original;
				}

				if ( 'Blocksy' === $original ) {
					$settings = $this->get_settings();

					if ( ! empty( $settings['theme']['name'] ) ) {
						return $settings['theme']['name'];
					}
				}

				if ( 'Blocksy Companion' === $original ) {
					$settings = $this->get_settings();
					if ( ! empty( $settings['plugin']['name'] ) ) {
						return $settings['plugin']['name'];
					}
				}

				if ( 'Blocksy Companion (Premium)' === $original ) {
					$settings = $this->get_settings();

					if ( ! empty( $settings['plugin']['name'] ) ) {
						return $settings['plugin']['name'];
					}
				}

				return $text;
			},
			20,
			2
		);

		add_filter(
			'wp_prepare_themes_for_js',
			function ( $themes ) {
				$blocksy_key = 'blocksy';

				if ( ! isset( $themes[ $blocksy_key ] ) ) {
					return $themes;
				}

				$settings = $this->get_settings();

				if ( ! empty( $settings['theme']['name'] ) ) {
					$themes[ $blocksy_key ]['name'] = $settings['theme']['name'];

					foreach ( $themes as $key => $theme ) {
						if (
						isset( $theme['parent'] )
						&&
						'Blocksy' === $theme['parent']
						) {
							$themes[ $key ]['parent'] = $settings['theme']['name'];
						}
					}
				}

				if ( ! empty( $settings['theme']['description'] ) ) {
					$themes[ $blocksy_key ]['description'] = $settings['theme']['description'];
				}

				if ( ! empty( $settings['theme']['screenshot'] ) ) {
					$themes[ $blocksy_key ]['screenshot'] = array(
						$settings['theme']['screenshot'],
					);
				}

				if ( ! empty( $settings['author']['name'] ) ) {
					$themes[ $blocksy_key ]['author'] = $settings['author']['name'];
				}

				if ( ! empty( $settings['author']['url'] ) ) {
					$themes[ $blocksy_key ]['author'] = $settings['author']['name'];

					$themes[ $blocksy_key ]['authorAndUri'] = '<a href="' . esc_url( $settings['author']['url'] ) . '">' .
					$themes[ $blocksy_key ]['author'] .
					'</a>';
				}

				if (
				isset( $themes[ $blocksy_key ]['update'] )
				&&
				! empty( $settings['theme']['name'] )
				) {
					$themes[ $blocksy_key ]['update'] = str_replace(
						'Blocksy',
						$settings['theme']['name'],
						$themes[ $blocksy_key ]['update']
					);

					if ( ! empty( $settings['author']['url'] ) ) {
						$themes[ $blocksy_key ]['update'] = str_replace(
							'https://wordpress.org/themes/blocksy/?TB_iframe=true&#038;width=1024&#038;height=800',
							add_query_arg(
								array(
									'TB_iframe' => true,
									'width'     => '1024',
									'hight'     => '800',
								),
								$settings['author']['url']
							),
							$themes[ $blocksy_key ]['update']
						);
					}
				}

				return $themes;
			}
		);

		add_filter(
			'all_themes',
			function ( $themes ) {
				$blocksy_key = 'blocksy';

				if ( is_network_admin() ) {
					return $themes;
				}

				if ( ! isset( $themes[ $blocksy_key ] ) ) {
					return $themes;
				}

				$themes[ $blocksy_key ] = blocksy_companion_theme_functions()->blocksy_get_wp_theme();

				return $themes;
			}
		);

		add_filter(
			'blocksy_dashboard_has_heading',
			function ( $value ) {
				$settings = $this->get_settings();

				if ( ! empty( $settings['theme']['name'] ) ) {
					return 'no';
				}

				return $value;
			}
		);

		add_filter(
			'blocksy_ext_demo_install_enabled',
			function ( $value ) {
				$settings = $this->get_settings();

				if ( isset( $settings['hide_demos'] ) && $settings['hide_demos'] ) {
					return 'no';
				}

				return $value;
			}
		);

		add_filter(
			'blocksy_dashboard_localizations',
			function ( $d ) {
				$settings = $this->get_settings();

				if (
					isset( $settings['hide_plugins_tab'] )
					&&
					$settings['hide_plugins_tab']
				) {
					$d['hide_plugins_tab'] = true;
				}

				if (
					isset( $settings['hide_changelogs_tab'] )
					&&
					$settings['hide_changelogs_tab']
				) {
					$d['hide_changelogs_tab'] = true;
				}

				if (
					isset( $settings['hide_support_section'] )
					&&
					$settings['hide_support_section']
				) {
					$d['hide_support_section'] = true;
				}

				if (
					isset( $settings['hide_docs_section'] )
					&&
					$settings['hide_docs_section']
				) {
					$d['hide_docs_section'] = true;
				}

				if (
					isset( $settings['hide_video_section'] )
					&&
					$settings['hide_video_section']
				) {
					$d['hide_video_section'] = true;
				}

				if (
					isset( $settings['hide_support_docs_section'] )
					&&
					$settings['hide_support_docs_section']
				) {
					$d['hide_support_docs_section'] = true;
				}

				if (
					isset( $settings['hide_support_video_section'] )
					&&
					$settings['hide_support_video_section']
				) {
					$d['hide_support_video_section'] = true;
				}

				if (
					isset( $settings['hide_support_facebook_section'] )
					&&
					$settings['hide_support_facebook_section']
				) {
					$d['hide_support_facebook_section'] = true;
				}

				// Pass custom section data
				if ( ! empty( $settings['facebook'] ) ) {
					$d['facebook'] = $settings['facebook'];
				}

				if ( ! empty( $settings['video_tutorials'] ) ) {
					$d['video_tutorials'] = $settings['video_tutorials'];
				}

				if ( ! empty( $settings['knowledge_base'] ) ) {
					$d['knowledge_base'] = $settings['knowledge_base'];
				}

				if ( ! empty( $settings['support'] ) ) {
					$d['support'] = $settings['support'];
				}

				return $d;
			}
		);

		add_filter(
			'blocksy_dashboard_support_url',
			function ( $url ) {
				$settings = $this->get_settings();

				if ( ! empty( $settings['author']['support'] ) ) {
					return $settings['author']['support'];
				}

				return $url;
			}
		);

		add_action(
			'admin_enqueue_scripts',
			function () {
				global $pagenow;

				if ( 'update-core.php' !== $pagenow ) {
					return;
				}

				$settings = $this->get_settings();

				$branded_screenshot = $settings['theme']['screenshot'];

				$branded_name = $settings['theme']['name'];

				if ( ! empty( $branded_screenshot ) ) {
					wp_add_inline_script(
						'updates',
						"
					document.querySelectorAll(
						'#update-themes-table .plugin-title .updates-table-screenshot[src*=\"blocksy/screenshot\"]'
					).forEach(function(theme) {
						theme.src = '$branded_screenshot';
					});"
					);
				}

				if ( ! empty( $branded_name ) ) {
					wp_add_inline_script(
						'updates',
						"
					document.querySelectorAll('#update-themes-table .plugin-title strong')
					.forEach(function(plugin) {
						if (plugin.innerText === 'Blocksy') {
							plugin.innerText = '$branded_name';
						}
					});"
					);
				}
			}
		);
	}

	public function get_settings() {
		$defaults = array(
			'locked'                        => false,
			'hide_demos'                    => false,
			'hide_billing_account'          => false,

			'hide_plugins_tab'              => false,
			'hide_changelogs_tab'           => false,
			'hide_support_section'          => false,
			'hide_docs_section'             => false,
			'hide_video_section'            => false,
			'hide_support_docs_section'     => false,
			'hide_support_video_section'    => false,
			'hide_support_facebook_section' => false,

			'author'                        => array(
				'name'    => '',
				'url'     => '',
				'support' => '',
			),

			'theme'                         => array(
				'name'           => '',
				'description'    => '',
				'screenshot'     => '',
				'icon'           => '',
				'gutenberg_icon' => '',
			),

			'plugin'                        => array(
				'name'        => '',
				'description' => '',
				'thumbnail'   => '',
			),

			'facebook'                      => array(
				'title'       => '',
				'description' => '',
				'buttonText'  => '',
				'link'        => '',
			),

			'video_tutorials'               => array(
				'title'       => '',
				'description' => '',
				'buttonText'  => '',
				'link'        => '',
			),

			'knowledge_base'                => array(
				'title'       => '',
				'description' => '',
				'buttonText'  => '',
				'link'        => '',
			),

			'support'                       => array(
				'title'       => '',
				'description' => '',
				'buttonText'  => '',
				'link'        => '',
			),
		);

		/**
		 * Filters the White Label extension settings.
		 *
		 * Allows the white label configuration to be supplied from code instead of the
		 * dashboard.
		 *
		 * @since 1.7.18
		 *
		 * @param array $settings White Label settings as stored in the database, or the
		 *                        defaults when nothing was saved yet.
		 */
		$settings = apply_filters(
			'blocksy:ext:white-label:settings',
			get_option( $this->option_name, $defaults )
		);

		if ( ! is_array( $settings ) ) {
			$settings = $defaults;
		}

		$settings['theme']['name'] = htmlentities( $settings['theme']['name'] );

		return $settings;
	}

	private function sync_freemius_plugin_name() {
		if ( ! function_exists( 'blocksy_companion_fs' ) ) {
			return;
		}

		$settings = $this->get_settings();

		if ( empty( $settings['plugin']['name'] ) ) {
			return;
		}

		$plugin = blocksy_companion_fs()->get_plugin();

		if ( ! is_object( $plugin ) ) {
			return;
		}

		$plugin->title = $settings['plugin']['name'];
	}

	public function set_settings( $value ) {
		update_option( $this->option_name, $value );
	}
}
